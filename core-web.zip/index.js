var rule_engine_1 = require('./view/components/rule-engine/rule-engine');
rule_engine_1.RuleEngineApp.main().then(function () {
    console.log("Loaded rule-engine component.");
});
console.log("Loading rule-engine component.");
//# sourceMappingURL=index.js.map