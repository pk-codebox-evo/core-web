var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") return Reflect.decorate(decorators, target, key, desc);
    switch (arguments.length) {
        case 2: return decorators.reduceRight(function(o, d) { return (d && d(o)) || o; }, target);
        case 3: return decorators.reduceRight(function(o, d) { return (d && d(target, key)), void 0; }, void 0);
        case 4: return decorators.reduceRight(function(o, d) { return (d && d(target, key, o)) || o; }, desc);
    }
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
var __param = (this && this.__param) || function (paramIndex, decorator) {
    return function (target, key) { decorator(target, key, paramIndex); }
};
var angular2_1 = require('angular2/angular2');
var ApiRoot_1 = require("../../persistence/ApiRoot");
var I18NCountryProvider = (function () {
    function I18NCountryProvider(apiRoot) {
        this.byIsoCode = {};
        this.byName = {};
        this.names = [];
        this.userLocale = apiRoot.authUser.locale; //i.e. 'en-US'
        this.countryRef = apiRoot.resourceRef.child(this.userLocale + '/system/locale/country'); //i.e.'en-US/system/locale/country'
        this.init();
    }
    I18NCountryProvider.prototype.init = function () {
        var _this = this;
        this.promise = new Promise(function (resolve, reject) {
            _this.countryRef.once('value', function (snap) {
                _this.byIsoCode = snap.val();
                Object.keys(_this.byIsoCode).forEach(function (key) {
                    var country = _this.byIsoCode[key];
                    _this.names.push(country.name);
                    _this.byName[country.name] = key;
                });
                _this.names.sort();
                resolve(_this);
            });
        });
    };
    I18NCountryProvider = __decorate([
        __param(0, angular2_1.Inject(ApiRoot_1.ApiRoot)), 
        __metadata('design:paramtypes', [Object])
    ], I18NCountryProvider);
    return I18NCountryProvider;
})();
exports.I18NCountryProvider = I18NCountryProvider;
//# sourceMappingURL=I18NCountryProvider.js.map