var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") return Reflect.decorate(decorators, target, key, desc);
    switch (arguments.length) {
        case 2: return decorators.reduceRight(function(o, d) { return (d && d(o)) || o; }, target);
        case 3: return decorators.reduceRight(function(o, d) { return (d && d(target, key)), void 0; }, void 0);
        case 4: return decorators.reduceRight(function(o, d) { return (d && d(target, key, o)) || o; }, desc);
    }
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
var __param = (this && this.__param) || function (paramIndex, decorator) {
    return function (target, key) { decorator(target, key, paramIndex); }
};
var angular2_1 = require('angular2/angular2');
var ApiRoot_1 = require("../../persistence/ApiRoot");
var noop = function () {
    var arg = [];
    for (var _i = 0; _i < arguments.length; _i++) {
        arg[_i - 0] = arguments[_i];
    }
};
var I18nResourceModel = (function () {
    function I18nResourceModel(locale, key, messaegs) {
        if (key === void 0) { key = null; }
        if (messaegs === void 0) { messaegs = {}; }
        this._locale = locale;
        this._key = key;
        this._messages = messaegs;
    }
    Object.defineProperty(I18nResourceModel.prototype, "locale", {
        get: function () {
            return this._locale;
        },
        enumerable: true,
        configurable: true
    });
    Object.defineProperty(I18nResourceModel.prototype, "key", {
        get: function () {
            return this._key;
        },
        enumerable: true,
        configurable: true
    });
    Object.defineProperty(I18nResourceModel.prototype, "messages", {
        get: function () {
            return this._messages;
        },
        enumerable: true,
        configurable: true
    });
    I18nResourceModel.prototype.getMessage = function (key) {
        var parts = key.split(".");
        var val = this._messages;
        var result = null;
        if (parts && parts.length > 0) {
            for (var i = 0, L = parts.length; i < L; ++i) {
                val = val[parts[i]];
                if (!val) {
                    break;
                }
            }
            result = val;
        }
        return result;
    };
    return I18nResourceModel;
})();
exports.I18nResourceModel = I18nResourceModel;
var I18nService = (function () {
    function I18nService(apiRoot) {
        this.ref = apiRoot.root.child('system/i18n');
    }
    I18nService.fromSnapshot = function (locale, key, snapshot) {
        return new I18nResourceModel(locale, key, snapshot.val());
    };
    I18nService.prototype.get = function (locale, key, cb) {
        if (cb === void 0) { cb = noop; }
        key = key.replace(/\./g, '/');
        this.ref.child(locale).child(key).once('value', function (snap) {
            var rsrcModel = I18nService.fromSnapshot(locale, key, snap);
            cb(rsrcModel);
        }, function (e) {
            throw e;
        });
    };
    I18nService = __decorate([
        __param(0, angular2_1.Inject(ApiRoot_1.ApiRoot)), 
        __metadata('design:paramtypes', [ApiRoot_1.ApiRoot])
    ], I18nService);
    return I18nService;
})();
exports.I18nService = I18nService;
//# sourceMappingURL=I18n.js.map