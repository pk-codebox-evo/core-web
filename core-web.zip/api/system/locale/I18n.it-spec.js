var angular2_1 = require('angular2/angular2');
var DataStore_1 = require('../../../api/persistence/DataStore');
var RestDataStore_1 = require('../../../api/persistence/RestDataStore');
var UserModel_1 = require('../../../api/auth/UserModel');
var ApiRoot_1 = require('../../../api/persistence/ApiRoot');
var I18n_1 = require("./I18n");
var injector = angular2_1.Injector.resolveAndCreate([
    UserModel_1.UserModel,
    ApiRoot_1.ApiRoot,
    I18n_1.I18nService,
    new angular2_1.Provider(DataStore_1.DataStore, { useClass: RestDataStore_1.RestDataStore })
]);
describe('Integration.api.system.locale.I18n', function () {
    var rsrcService;
    beforeEach(function () {
        rsrcService = injector.get(I18n_1.I18nService);
    });
    it("Can get a specific message.", function (done) {
        rsrcService.get('en-US', 'message.comment.success', function (rsrc) {
            expect(rsrc.messages).toBe("Your comment has been saved");
            rsrcService.get('de', 'message.comment.success', function (rsrc) {
                expect(rsrc.messages).toBe("Ihr Kommentar wurde gespeichert");
                done();
            });
        });
    });
    it("Can get all message under a particular path.", function (done) {
        rsrcService.get('en-US', 'message.comment', function (rsrc) {
            expect(rsrc.messages.delete).toBe("Your comment has been delete");
            expect(rsrc.messages.failure).toBe("Your comment couldn't be created");
            expect(rsrc.messages.success).toBe("Your comment has been saved");
            rsrcService.get('de', 'message.comment', function (rsrc) {
                expect(rsrc.messages.delete).toBe("Ihr Kommentar wurde gelöscht");
                expect(rsrc.messages.failure).toBe("Ihr Kommentar konnte nicht erstellt werden");
                expect(rsrc.messages.success).toBe("Ihr Kommentar wurde gespeichert");
                done();
            });
        });
    });
});
//# sourceMappingURL=I18n.it-spec.js.map