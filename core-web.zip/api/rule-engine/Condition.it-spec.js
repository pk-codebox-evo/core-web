var Rule_1 = require('../../api/rule-engine/Rule');
var Condition_1 = require('../../api/rule-engine/Condition');
var angular2_1 = require('angular2/angular2');
var DataStore_1 = require('../../api/persistence/DataStore');
var RestDataStore_1 = require('../../api/persistence/RestDataStore');
var ApiRoot_1 = require('../../api/persistence/ApiRoot');
var UserModel_1 = require('../../api/auth/UserModel');
var ConditionType_1 = require('../../api/rule-engine/ConditionType');
var Action_1 = require('../../api/rule-engine/Action');
var ConditionGroup_1 = require('../../api/rule-engine/ConditionGroup');
var ActionType_1 = require("./ActionType");
var I18n_1 = require("../system/locale/I18n");
var injector = angular2_1.Injector.resolveAndCreate([ApiRoot_1.ApiRoot,
    I18n_1.I18nService,
    UserModel_1.UserModel,
    Rule_1.RuleService,
    Action_1.ActionService,
    ActionType_1.ActionTypeService,
    ConditionType_1.ConditionTypeService,
    Condition_1.ConditionService,
    ConditionGroup_1.ConditionGroupService,
    new angular2_1.Provider(DataStore_1.DataStore, { useClass: RestDataStore_1.RestDataStore })
]);
describe('Integration.api.rule-engine.ConditionService', function () {
    var ruleService;
    var ruleOnAddSub;
    var conditionGroupService;
    var conditionService;
    var ruleUnderTest;
    var groupUnderTest;
    beforeEach(function (done) {
        ruleUnderTest = null;
        groupUnderTest = null;
        ruleService = injector.get(Rule_1.RuleService);
        conditionGroupService = injector.get(ConditionGroup_1.ConditionGroupService);
        conditionService = injector.get(Condition_1.ConditionService);
        ruleOnAddSub = ruleService.onAdd.subscribe(function (rule) {
            if (!ruleUnderTest) {
                ruleUnderTest = rule;
                groupUnderTest = new ConditionGroup_1.ConditionGroupModel();
                groupUnderTest.operator = "OR";
                groupUnderTest.owningRule = ruleUnderTest;
                conditionGroupService.add(groupUnderTest, done);
            }
        }, function (err) {
            expect(err).toBeUndefined("error was thrown.");
            done();
        });
        Tools.createRule(ruleService);
    });
    afterEach(function () {
        ruleService.remove(ruleUnderTest);
        ruleUnderTest = null;
        ruleOnAddSub.unsubscribe();
    });
    it("Has a rule and group that we can add conditions to", function () {
        expect(ruleUnderTest.isPersisted()).toBe(true);
        expect(groupUnderTest.isPersisted()).toBe(true);
    });
    it("Can add a new Condition", function (done) {
        var aCondition = new Condition_1.ConditionModel();
        aCondition.name = "pointless_name-" + new Date().getTime();
        aCondition.conditionType = new ConditionType_1.ConditionTypeModel("UsersCountryConditionlet");
        aCondition.owningGroup = groupUnderTest;
        aCondition.setParameter("sessionKey", "foo");
        aCondition.setParameter("sessionValue", "bar");
        var sub = conditionService.onAdd.subscribe(function (condition) {
            sub.unsubscribe();
            //noinspection TypeScriptUnresolvedFunction
            expect(condition.isPersisted()).toBe(true, "Condition is not persisted!");
            done();
        }, function (err) {
            expect(err).toBeUndefined("error was thrown.");
            done();
        });
        conditionService.add(aCondition);
    });
    it("Is added to the owning rule's list of conditions.", function (done) {
        var aCondition = new Condition_1.ConditionModel();
        aCondition.name = "pointless_name-" + new Date().getTime();
        aCondition.conditionType = new ConditionType_1.ConditionTypeModel("UsersCountryConditionlet");
        aCondition.owningGroup = groupUnderTest;
        aCondition.setParameter("comparatorValue", "is");
        aCondition.setParameter("isoCode", "US");
        var sub = conditionService.onAdd.subscribe(function (condition) {
            sub.unsubscribe();
            expect(groupUnderTest.conditions[condition.key]).toBe(true, "Check the ConditionService.onAdd listener in the RuleService.");
            done();
        }, function (err) {
            expect(err).toBeUndefined("error was thrown.");
            done();
        });
        conditionService.add(aCondition);
    });
    it("Condition being added to the owning group is persisted to server.", function (done) {
        var aCondition = new Condition_1.ConditionModel();
        aCondition.name = "pointless_name-" + new Date().getTime();
        aCondition.conditionType = new ConditionType_1.ConditionTypeModel("UsersCountryConditionlet");
        aCondition.owningGroup = groupUnderTest;
        aCondition.setParameter("comparatorValue", "is");
        aCondition.setParameter("isoCode", "US");
        var firstPass = conditionService.onAdd.subscribe(function (condition) {
            //noinspection TypeScriptUnresolvedFunction
            firstPass.unsubscribe(); // don't want to run THIS watcher twice.
            expect(groupUnderTest.conditions[condition.key]).toBe(true, "Check the ConditionService.onAdd listener in the RuleService.");
            // condition was persisted to server and is present on the Rule.
            ruleService.save(ruleUnderTest, function () {
                ruleService.get(ruleUnderTest.key, function (rule) {
                    var rehydratedGroup = rule.groups[groupUnderTest.key];
                    expect(rehydratedGroup).toBeDefined("The condition group should still exist");
                    expect(rehydratedGroup.conditions[condition.key]).toBeDefined("The condition should still exist as a child of the group.");
                    done();
                });
            });
        }, function (err) {
            expect(err).toBeUndefined("error was thrown!");
            done();
        });
        // save the condition to the group:
        conditionService.add(aCondition);
    });
    it("Will add a new condition parameters to an existing condition.", function (done) {
        var clientCondition = new Condition_1.ConditionModel();
        clientCondition.conditionType = new ConditionType_1.ConditionTypeModel("UserBrowserHeaderConditionlet");
        clientCondition.owningGroup = groupUnderTest;
        clientCondition.setParameter("headerKey", "foo");
        clientCondition.setParameter("headerValue", "bar");
        var key = "aParamKey";
        var value = "aParamValue";
        conditionService.add(clientCondition, function (resultCondition) {
            // serverCondition is the same instance as resultCondition
            expect(clientCondition.isPersisted()).toBe(true, "Condition is not persisted!");
            clientCondition.clearParameters();
            clientCondition.setParameter(key, value);
            conditionService.save(clientCondition, function (savedCondition) {
                // savedCondition is also the same instance as resultCondition
                conditionService.get(clientCondition.owningGroup, clientCondition.key, function (updatedCondition) {
                    // updatedCondition and clientCondition SHOULD NOT be the same instance object.
                    updatedCondition['abc123'] = 100;
                    expect(clientCondition['abc123']).toBeUndefined();
                    expect(clientCondition.getParameter(key)).toBe(value, "ClientCondition param value should still be set.");
                    expect(updatedCondition.getParameter(key)).toBe(value, "Condition refreshed from server should have the correct param value.");
                    expect(Object.keys(updatedCondition.parameters).length).toEqual(1, "The old keys should have been removed.");
                    done();
                });
            });
        });
    });
    it("Can update condition parameter values on existing condition.", function (done) {
        var param1 = { key: 'sessionKey', v1: 'value1', v2: 'value2' };
        var param2 = { key: 'sessionValue', v1: 'abc123', v2: 'def456' };
        var clientCondition = new Condition_1.ConditionModel();
        clientCondition.conditionType = new ConditionType_1.ConditionTypeModel("SetSessionAttributeConditionlet");
        clientCondition.owningGroup = groupUnderTest;
        clientCondition.setParameter(param1.key, param1.v1);
        clientCondition.setParameter(param2.key, param2.v1);
        conditionService.add(clientCondition, function (resultCondition) {
            clientCondition.setParameter(param1.key, param1.v2);
            conditionService.save(clientCondition, function (savedCondition) {
                conditionService.get(clientCondition.owningGroup, clientCondition.key, function (updatedCondition) {
                    expect(updatedCondition.getParameter(param1.key)).toBe(param1.v2, "Condition refreshed from server should have the correct param value.");
                    expect(updatedCondition.getParameter(param2.key)).toBe(param2.v1, "Condition refreshed from server should have the correct param value.");
                    expect(Object.keys(updatedCondition.parameters).length).toEqual(2);
                    done();
                });
            });
        });
    });
});
var Tools = (function () {
    function Tools() {
    }
    Tools.createRule = function (ruleService, cb) {
        if (cb === void 0) { cb = null; }
        console.log('Attempting to create rule.');
        var rule = new Rule_1.RuleModel();
        rule.enabled = true;
        rule.name = "TestRule-" + new Date().getTime();
        ruleService.add(rule, cb);
    };
    return Tools;
})();
//# sourceMappingURL=Condition.it-spec.js.map