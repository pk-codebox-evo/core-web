var Rule_1 = require('../../api/rule-engine/Rule');
var Condition_1 = require('../../api/rule-engine/Condition');
var angular2_1 = require('angular2/angular2');
var DataStore_1 = require('../../api/persistence/DataStore');
var RestDataStore_1 = require('../../api/persistence/RestDataStore');
var ApiRoot_1 = require('../../api/persistence/ApiRoot');
var UserModel_1 = require('../../api/auth/UserModel');
var ConditionType_1 = require('../../api/rule-engine/ConditionType');
var Action_1 = require('../../api/rule-engine/Action');
var ConditionGroup_1 = require('../../api/rule-engine/ConditionGroup');
var ActionType_1 = require("./ActionType");
var I18n_1 = require("../system/locale/I18n");
var injector = angular2_1.Injector.resolveAndCreate([ApiRoot_1.ApiRoot,
    I18n_1.I18nService,
    UserModel_1.UserModel,
    Rule_1.RuleService,
    Action_1.ActionService,
    ActionType_1.ActionTypeService,
    ConditionType_1.ConditionTypeService,
    Condition_1.ConditionService,
    ConditionGroup_1.ConditionGroupService,
    new angular2_1.Provider(DataStore_1.DataStore, { useClass: RestDataStore_1.RestDataStore })
]);
describe('Integration.api.rule-engine.ConditionGroupService', function () {
    var ruleService;
    var onAddSub;
    var conditionGroupService;
    var ruleUnderTest;
    beforeEach(function (done) {
        ruleService = injector.get(Rule_1.RuleService);
        conditionGroupService = injector.get(ConditionGroup_1.ConditionGroupService);
        onAddSub = ruleService.onAdd.subscribe(function (rule) {
            ruleUnderTest = rule;
            done();
        }, function (err) {
            expect(err).toBeUndefined("error was thrown.");
            done();
        });
        Gen.createRules(ruleService);
    });
    afterEach(function () {
        ruleService.remove(ruleUnderTest);
        ruleUnderTest = null;
        onAddSub.unsubscribe();
    });
    it("Has rules that we can add conditionGroups to", function () {
        expect(ruleUnderTest.isPersisted()).toBe(true);
    });
    it("Can add a new ConditionGroup", function (done) {
        var aConditionGroup = new ConditionGroup_1.ConditionGroupModel();
        aConditionGroup.owningRule = ruleUnderTest;
        aConditionGroup.operator = "OR";
        var subscriber = conditionGroupService.onAdd.subscribe(function (conditionGroup) {
            //noinspection TypeScriptUnresolvedFunction
            expect(conditionGroup.isPersisted()).toBe(true, "ConditionGroup is not persisted!");
            done();
        }, function (err) {
            expect(err).toBeUndefined("error was thrown.");
            done();
        });
        conditionGroupService.add(aConditionGroup);
    });
    it("Is added to the owning rule's list of conditionGroups.", function (done) {
        var aConditionGroup = new ConditionGroup_1.ConditionGroupModel();
        aConditionGroup.owningRule = ruleUnderTest;
        aConditionGroup.operator = "OR";
        conditionGroupService.onAdd.subscribe(function (conditionGroup) {
            expect(ruleUnderTest.groups[conditionGroup.key]).toBeDefined();
            done();
        }, function (err) {
            expect(err).toBeUndefined("error was thrown.");
            done();
        });
        conditionGroupService.add(aConditionGroup);
    });
    it("ConditionGroup being added to the owning rule is persisted to server.", function (done) {
        var aConditionGroup = new ConditionGroup_1.ConditionGroupModel();
        aConditionGroup.owningRule = ruleUnderTest;
        aConditionGroup.operator = "OR";
        aConditionGroup.priority = 99;
        var firstPass = conditionGroupService.onAdd.subscribe(function (conditionGroup) {
            firstPass.unsubscribe(); // don't want to run THIS watcher twice.
            expect(ruleUnderTest.groups[conditionGroup.key]).toBeDefined("Expected group to be on the rule.");
            ruleService.save(ruleUnderTest, function () {
                ruleService.get(ruleUnderTest.key, function (rule) {
                    expect(rule.groups[conditionGroup.key]).toBeDefined("Well that's odd");
                    expect(rule.groups[conditionGroup.key].operator).toEqual("OR");
                    // @todo ggranum: Defect=Cannot set priority at creation time.
                    //expect(rule.groups[conditionGroup.key].priority).toEqual(99)
                    /* Now read the ConditionGroups off the rule we just got back. Add listener first, then trigger call. */
                    conditionGroupService.onAdd.subscribe(function (conditionGroup) {
                        expect(conditionGroup.operator).toEqual("OR");
                        // @todo ggranum: Defect=Cannot set priority at creation time.
                        //expect(conditionGroup.priority).toEqual(99)
                        done();
                    });
                    conditionGroupService.list(rule);
                });
            });
        }, function (err) {
            expect(err).toBeUndefined("error was thrown!");
            done();
        });
        conditionGroupService.add(aConditionGroup);
    });
});
var Gen = (function () {
    function Gen() {
    }
    Gen.createRules = function (ruleService) {
        console.log('Attempting to create rule.');
        var rule = new Rule_1.RuleModel();
        rule.enabled = true;
        rule.name = "TestRule-" + new Date().getTime();
        ruleService.add(rule);
    };
    return Gen;
})();
//# sourceMappingURL=ConditionGroup.it-spec.js.map