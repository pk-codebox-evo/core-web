var __extends = (this && this.__extends) || function (d, b) {
    for (var p in b) if (b.hasOwnProperty(p)) d[p] = b[p];
    function __() { this.constructor = d; }
    d.prototype = b === null ? Object.create(b) : (__.prototype = b.prototype, new __());
};
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") return Reflect.decorate(decorators, target, key, desc);
    switch (arguments.length) {
        case 2: return decorators.reduceRight(function(o, d) { return (d && d(o)) || o; }, target);
        case 3: return decorators.reduceRight(function(o, d) { return (d && d(target, key)), void 0; }, void 0);
        case 4: return decorators.reduceRight(function(o, d) { return (d && d(target, key, o)) || o; }, desc);
    }
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
var __param = (this && this.__param) || function (paramIndex, decorator) {
    return function (target, key) { decorator(target, key, paramIndex); }
};
var angular2_1 = require('angular2/angular2');
//import * as Rx from '../../../node_modules/angular2/node_modules/@reactivex/rxjs/src/Rx.KitchenSink'
var ApiRoot_1 = require("../persistence/ApiRoot");
var CwModel_1 = require("../util/CwModel");
var noop = function () {
    var arg = [];
    for (var _i = 0; _i < arguments.length; _i++) {
        arg[_i - 0] = arguments[_i];
    }
};
var ConditionTypeModel = (function (_super) {
    __extends(ConditionTypeModel, _super);
    function ConditionTypeModel(key, i18nKey, comparisons) {
        if (key === void 0) { key = 'NoSelection'; }
        if (i18nKey === void 0) { i18nKey = null; }
        if (comparisons === void 0) { comparisons = []; }
        _super.call(this, key ? key : 'NoSelection');
        this.i18nKey = i18nKey ? i18nKey : key;
        this.comparisons = comparisons || [];
    }
    ConditionTypeModel.prototype.isValid = function () {
        return this.isPersisted() && !!this.i18nKey && this.comparisons && this.comparisons.length > 0;
    };
    return ConditionTypeModel;
})(CwModel_1.CwModel);
exports.ConditionTypeModel = ConditionTypeModel;
// @todo ggranum: Remove this and code that defers to it once we either add an 'enabled' field to conditionlet types,
// or we have implemented all the conditionlet types we intend to release with.
var DISABLED_CONDITION_TYPE_IDS = {
    //UsersCountryConditionlet: false,
    //UsersBrowserHeaderConditionlet: false,
    //UsersContinentConditionlet: true, // comment out to prove we don't need to know its name.
    UsersIpAddressConditionlet: true,
    UsersVisitedUrlConditionlet: true,
    UsersCityConditionlet: true,
    UsersTimeConditionlet: true,
    UsersLandingPageUrlConditionlet: true,
    UsersPlatformConditionlet: true,
    UsersLanguageConditionlet: true,
    UsersPageVisitsConditionlet: true,
    MockTrueConditionlet: true,
    UsersUrlParameterConditionlet: true,
    UsersReferringUrlConditionlet: true,
    UsersCurrentUrlConditionlet: true,
    UsersHostConditionlet: true,
    UsersStateConditionlet: true,
    UsersSiteVisitsConditionlet: true,
    UsersDateTimeConditionlet: true,
    UsersOperatingSystemConditionlet: true,
    UsersLogInConditionlet: true,
    UsersBrowserConditionlet: true
};
var ConditionTypeService = (function () {
    function ConditionTypeService(apiRoot) {
        this._ref = apiRoot.root.child('system/ruleengine/conditionlets');
        this._apiRoot = apiRoot;
        this._added = new angular2_1.EventEmitter();
        this._refreshed = new angular2_1.EventEmitter();
        this.onAdd = Rx.Observable.from(this._added.toRx()).publishReplay();
        this.onRefresh = Rx.Observable.from(this._refreshed.toRx()).share();
        this._map = {};
        this.onAdd.connect();
    }
    ConditionTypeService.fromSnapshot = function (snapshot) {
        var val = snapshot.val();
        return new ConditionTypeModel(snapshot.key(), val.i18nKey, val.comparisons);
    };
    ConditionTypeService.prototype._entryReceived = function (entry) {
        var isRefresh = this._map[entry.key] != null;
        this._map[entry.key] = entry;
        if (isRefresh) {
            this._refreshed.next(entry);
        }
        else {
            this._added.next(entry);
        }
    };
    ConditionTypeService.prototype.list = function (cb) {
        var _this = this;
        if (cb === void 0) { cb = noop; }
        this._ref.once('value', function (snap) {
            var types = snap.val();
            var result = [];
            Object.keys(types).forEach(function (key) {
                if (DISABLED_CONDITION_TYPE_IDS[key] !== true) {
                    var conditionType = snap.child(key);
                    var typeModel = ConditionTypeService.fromSnapshot(conditionType);
                    _this._entryReceived(typeModel);
                    result.push(typeModel);
                }
            });
            cb(result);
        }, function (e) {
            throw e;
        });
        return this.onAdd;
    };
    ConditionTypeService.prototype.get = function (key, cb) {
        if (cb === void 0) { cb = noop; }
        var cachedValue = this._map[key];
        if (cachedValue) {
            cb(cachedValue);
        }
        else {
            /* There is no direct endpoint to get conditions by key. So we'll fake it a bit, and just wait for a call to
            'list' to trigger the observer. */
            var sub = this.onAdd.subscribe(function (type) {
                if (type.key == key) {
                    cb(type);
                    sub.unsubscribe();
                }
            });
        }
    };
    ConditionTypeService = __decorate([
        __param(0, angular2_1.Inject(ApiRoot_1.ApiRoot)), 
        __metadata('design:paramtypes', [Object])
    ], ConditionTypeService);
    return ConditionTypeService;
})();
exports.ConditionTypeService = ConditionTypeService;
//# sourceMappingURL=ConditionType.js.map