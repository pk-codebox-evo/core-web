var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") return Reflect.decorate(decorators, target, key, desc);
    switch (arguments.length) {
        case 2: return decorators.reduceRight(function(o, d) { return (d && d(o)) || o; }, target);
        case 3: return decorators.reduceRight(function(o, d) { return (d && d(target, key)), void 0; }, void 0);
        case 4: return decorators.reduceRight(function(o, d) { return (d && d(target, key, o)) || o; }, desc);
    }
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
var __param = (this && this.__param) || function (paramIndex, decorator) {
    return function (target, key) { decorator(target, key, paramIndex); }
};
var angular2_1 = require('angular2/angular2');
var ApiRoot_1 = require("../persistence/ApiRoot");
// @todo ggranum: Remove this and code that defers to it once we either add an 'enabled' field to conditionlet types,
// or we have implemented all the conditionlet types we intend to release with.
var ENABLED_CONDITION_TYPE_IDS = {
    UsersBrowserHeaderConditionlet: true,
    UsersCountryConditionlet: true
};
var ConditionTypeModel = (function () {
    function ConditionTypeModel(id, i18nKey, type) {
        var _this = this;
        if (id === void 0) { id = 'NoSelection'; }
        if (i18nKey === void 0) { i18nKey = null; }
        if (type === void 0) { type = null; }
        this._id = id;
        this.i18nKey = i18nKey;
        this.comparisons = [];
        if (type && type.comparisons) {
            Object.keys(type.comparisons).forEach(function (key) {
                _this.comparisons.push(type.comparisons[key]._id);
            });
        }
    }
    Object.defineProperty(ConditionTypeModel.prototype, "id", {
        get: function () {
            return this._id;
        },
        set: function (value) {
            this._id = (value && value.length) ? value : 'NoSelection';
        },
        enumerable: true,
        configurable: true
    });
    ConditionTypeModel.prototype.rhsValues = function (parameters) {
        var map = {};
        if (parameters) {
            Object.keys(parameters).forEach(function (key) {
                map[parameters[key].key] = parameters[key].value;
            });
        }
        return map;
    };
    return ConditionTypeModel;
})();
exports.ConditionTypeModel = ConditionTypeModel;
var ConditionTypesProvider = (function () {
    function ConditionTypesProvider(apiRoot) {
        this.typeModels = new Map();
        this.map = new Map();
        this.ary = [];
        this.ref = apiRoot.root.child('system/ruleengine/conditionlets');
        this.init();
    }
    ConditionTypesProvider.prototype.init = function () {
        var _this = this;
        this.promise = new Promise(function (resolve, reject) {
            _this.ref.once('value', function (snap) {
                var types = snap['val']();
                Object.keys(types).forEach(function (key) {
                    if (ENABLED_CONDITION_TYPE_IDS[key]) {
                        var conditionType = types[key];
                        var typeModel = new ConditionTypeModel(key, types[key]);
                        Object.assign(typeModel, conditionType);
                        _this.map.set(key, typeModel);
                        _this.ary.push(types[key]);
                    }
                });
                resolve(_this);
            });
        });
    };
    ConditionTypesProvider.prototype.getType = function (id) {
        return this.map.get(id);
    };
    ConditionTypesProvider = __decorate([
        __param(0, angular2_1.Inject(ApiRoot_1.ApiRoot)), 
        __metadata('design:paramtypes', [Object])
    ], ConditionTypesProvider);
    return ConditionTypesProvider;
})();
exports.ConditionTypesProvider = ConditionTypesProvider;
//# sourceMappingURL=ConditionTypes.js.map