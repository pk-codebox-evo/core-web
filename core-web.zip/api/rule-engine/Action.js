var __extends = (this && this.__extends) || function (d, b) {
    for (var p in b) if (b.hasOwnProperty(p)) d[p] = b[p];
    function __() { this.constructor = d; }
    d.prototype = b === null ? Object.create(b) : (__.prototype = b.prototype, new __());
};
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") return Reflect.decorate(decorators, target, key, desc);
    switch (arguments.length) {
        case 2: return decorators.reduceRight(function(o, d) { return (d && d(o)) || o; }, target);
        case 3: return decorators.reduceRight(function(o, d) { return (d && d(target, key)), void 0; }, void 0);
        case 4: return decorators.reduceRight(function(o, d) { return (d && d(target, key, o)) || o; }, desc);
    }
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
var __param = (this && this.__param) || function (paramIndex, decorator) {
    return function (target, key) { decorator(target, key, paramIndex); }
};
var angular2_1 = require('angular2/angular2');
//import * as Rx from '../../../node_modules/angular2/node_modules/@reactivex/rxjs/src/Rx.KitchenSink'
var ApiRoot_1 = require("../persistence/ApiRoot");
var CwModel_1 = require("../util/CwModel");
var ActionType_1 = require("./ActionType");
var ActionType_2 = require("./ActionType");
var noop = function () {
    var arg = [];
    for (var _i = 0; _i < arguments.length; _i++) {
        arg[_i - 0] = arguments[_i];
    }
};
var ActionModel = (function (_super) {
    __extends(ActionModel, _super);
    function ActionModel(key) {
        if (key === void 0) { key = null; }
        _super.call(this, key);
        this._actionType = new ActionType_1.ActionTypeModel('NoSelection', '');
        this.parameters = {};
    }
    ActionModel.prototype.setParameter = function (key, value) {
        var existing = this.parameters[key];
        this.parameters[key] = { key: key, value: value };
        this._changed('parameters');
    };
    ActionModel.prototype.getParameter = function (key) {
        var v = '';
        if (this.parameters[key]) {
            v = this.parameters[key].value;
        }
        return v;
    };
    ActionModel.prototype.clearParameters = function () {
        this.parameters = {};
        this._changed('parameters');
    };
    Object.defineProperty(ActionModel.prototype, "actionType", {
        get: function () {
            return this._actionType;
        },
        set: function (value) {
            var _this = this;
            if (value !== this._actionType) {
                this._actionType = value;
                Object.keys(this._actionType.parameters).forEach(function (key) {
                    if (_this.getParameter(key) === undefined) {
                        _this.setParameter(key, "");
                    }
                });
                this._changed('actionType');
            }
        },
        enumerable: true,
        configurable: true
    });
    Object.defineProperty(ActionModel.prototype, "owningRule", {
        get: function () {
            return this._owningRule;
        },
        set: function (value) {
            this._owningRule = value;
            this._changed('owningRule');
        },
        enumerable: true,
        configurable: true
    });
    Object.defineProperty(ActionModel.prototype, "name", {
        get: function () {
            return this._name;
        },
        set: function (value) {
            this._name = value;
            this._changed('name');
        },
        enumerable: true,
        configurable: true
    });
    ActionModel.prototype.isValid = function () {
        var valid = !!this._owningRule;
        valid = valid && this._owningRule.isValid();
        valid = valid && this._actionType && this._actionType.key && this._actionType.key != 'NoSelection';
        return valid;
    };
    return ActionModel;
})(CwModel_1.CwModel);
exports.ActionModel = ActionModel;
var ActionService = (function () {
    function ActionService(apiRoot, typeService) {
        this._typeService = typeService;
        this.ref = apiRoot.defaultSite.child('ruleengine/actions');
        this.apiRoot = apiRoot;
        this._added = new angular2_1.EventEmitter();
        this._removed = new angular2_1.EventEmitter();
        var onAdd = Rx.Observable.from(this._added.toRx());
        var onRemove = Rx.Observable.from(this._removed.toRx());
        this.onAdd = onAdd.share();
        this.onRemove = onRemove.share();
    }
    ActionService.prototype._fromSnapshot = function (rule, snapshot) {
        var val = snapshot.val();
        var ra = new ActionModel(snapshot.key());
        ra.name = val.name;
        ra.owningRule = rule;
        ra.actionType = new ActionType_1.ActionTypeModel(val.actionlet);
        Object.keys(val.parameters).forEach(function (key) {
            var param = val.parameters[key];
            ra.setParameter(key, param.value);
        });
        this._typeService.get(val.actionlet, function (type) {
            ra.actionType = type;
        });
        return ra;
    };
    ActionService.prototype._toJson = function (action) {
        var json = {};
        json.name = action.name || "fake_name_" + new Date().getTime() + '_' + Math.random();
        json.owningRule = action.owningRule.key;
        json.actionlet = action.actionType.key;
        json.priority = action.priority;
        json.parameters = action.parameters;
        return json;
    };
    ActionService.prototype.list = function (rule) {
        if (rule.isPersisted()) {
            this.addActionsFromRule(rule);
        }
        return this.onAdd;
    };
    ActionService.prototype.addActionsFromRule = function (rule) {
        var _this = this;
        Object.keys(rule.actions).forEach(function (actionId) {
            _this.get(rule, actionId);
        });
    };
    ActionService.prototype.get = function (rule, key, cb) {
        var _this = this;
        if (cb === void 0) { cb = noop; }
        this.ref.child(key).once('value', function (actionSnap) {
            var model = _this._fromSnapshot(rule, actionSnap);
            _this._added.next(model);
            cb(model);
        }, function (e) {
            throw e;
        });
    };
    ActionService.prototype.add = function (model, cb) {
        var _this = this;
        if (cb === void 0) { cb = noop; }
        console.log("api.rule-engine.ActionService", "add", model);
        var json = this._toJson(model);
        this.ref.push(json, function (e, result) {
            if (e) {
                cb(model, e);
            }
            else {
                model.key = result.key();
                _this._added.next(model);
                cb(model);
            }
        });
    };
    ActionService.prototype.save = function (model, cb) {
        if (cb === void 0) { cb = noop; }
        console.log("api.rule-engine.ActionService", "save", model);
        if (!model.isValid()) {
            throw new Error("This should be thrown from a checkValid function on model, and should provide the info needed to make the user aware of the fix.");
        }
        if (!model.isPersisted()) {
            this.add(model, cb);
        }
        else {
            var json = this._toJson(model);
            this.ref.child(model.key).set(json, function (e, result) {
                if (e) {
                    throw e;
                }
                cb(model);
            });
        }
    };
    ActionService.prototype.remove = function (model, cb) {
        var _this = this;
        if (cb === void 0) { cb = noop; }
        console.log("api.rule-engine.ActionService", "remove", model);
        this.ref.child(model.key).remove(function () {
            _this._removed.next(model);
            cb(model);
        });
    };
    ActionService = __decorate([
        __param(0, angular2_1.Inject(ApiRoot_1.ApiRoot)),
        __param(1, angular2_1.Inject(ActionType_2.ActionTypeService)), 
        __metadata('design:paramtypes', [ApiRoot_1.ApiRoot, ActionType_2.ActionTypeService])
    ], ActionService);
    return ActionService;
})();
exports.ActionService = ActionService;
//# sourceMappingURL=Action.js.map