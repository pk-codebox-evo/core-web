var Rule_1 = require('api/rule-engine/Rule');
describe('Unit.api.rule-engine.Rule', function () {
    beforeEach(function () {
    });
    it("Isn't valid when new.", function () {
        var foo = new Rule_1.RuleModel();
        expect(foo.valid).toEqual(false);
    });
});
//# sourceMappingURL=Rule.spec.js.map