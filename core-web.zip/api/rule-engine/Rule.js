var __extends = (this && this.__extends) || function (d, b) {
    for (var p in b) if (b.hasOwnProperty(p)) d[p] = b[p];
    function __() { this.constructor = d; }
    d.prototype = b === null ? Object.create(b) : (__.prototype = b.prototype, new __());
};
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") return Reflect.decorate(decorators, target, key, desc);
    switch (arguments.length) {
        case 2: return decorators.reduceRight(function(o, d) { return (d && d(o)) || o; }, target);
        case 3: return decorators.reduceRight(function(o, d) { return (d && d(target, key)), void 0; }, void 0);
        case 4: return decorators.reduceRight(function(o, d) { return (d && d(target, key, o)) || o; }, desc);
    }
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
var __param = (this && this.__param) || function (paramIndex, decorator) {
    return function (target, key) { decorator(target, key, paramIndex); }
};
var angular2_1 = require('angular2/angular2');
//import * as Rx from '../../../node_modules/angular2/node_modules/@reactivex/rxjs/src/Rx.KitchenSink'
var ConditionGroup_1 = require("./ConditionGroup");
var CwModel_1 = require("../util/CwModel");
var ApiRoot_1 = require("../persistence/ApiRoot");
var Action_1 = require("./Action");
var RuleModel = (function (_super) {
    __extends(RuleModel, _super);
    function RuleModel(key) {
        if (key === void 0) { key = null; }
        _super.call(this, key);
        this.name = '';
        this._fireOn = 'EVERY_PAGE';
        this._enabled = false;
        this.valid = this.isValid();
        this.actions = {};
        this._groups = {};
    }
    Object.defineProperty(RuleModel.prototype, "fireOn", {
        get: function () {
            return this._fireOn;
        },
        set: function (value) {
            this._fireOn = value;
            this._changed('fireOn');
        },
        enumerable: true,
        configurable: true
    });
    Object.defineProperty(RuleModel.prototype, "enabled", {
        get: function () {
            return this._enabled;
        },
        set: function (value) {
            this._enabled = value === true;
            this._changed('enabled');
        },
        enumerable: true,
        configurable: true
    });
    Object.defineProperty(RuleModel.prototype, "name", {
        get: function () {
            return this._name;
        },
        set: function (value) {
            this._name = value;
            this._changed('name');
        },
        enumerable: true,
        configurable: true
    });
    RuleModel.prototype.addGroup = function (group) {
        this._groups[group.key] = group;
        this._changed('addGroup');
    };
    RuleModel.prototype.removeGroup = function (group) {
        delete this._groups[group.key];
        this._changed('removeGroup');
    };
    Object.defineProperty(RuleModel.prototype, "groups", {
        get: function () {
            // @todo clone this object.
            return this._groups;
        },
        enumerable: true,
        configurable: true
    });
    RuleModel.prototype.isValid = function () {
        var valid = !!this.name;
        valid = valid && this.name.trim().length > 0;
        return valid;
    };
    return RuleModel;
})(CwModel_1.CwModel);
exports.RuleModel = RuleModel;
var RuleService = (function () {
    function RuleService(apiRoot, actionService, conditionGroupService) {
        var _this = this;
        this.ref = apiRoot.defaultSite.child('ruleengine/rules');
        this._added = new angular2_1.EventEmitter();
        this._removed = new angular2_1.EventEmitter();
        var onAdd = Rx.Observable.from(this._added.toRx());
        var onRemove = Rx.Observable.from(this._removed.toRx());
        this.onAdd = onAdd.share();
        this.onRemove = onRemove.share();
        actionService.onAdd.subscribe(function (actionModel) {
            if (!actionModel.owningRule.actions[actionModel.key]) {
                actionModel.owningRule.actions[actionModel.key] = true;
                _this.save(actionModel.owningRule);
            }
        });
        actionService.onRemove.subscribe(function (actionModel) {
            if (actionModel.owningRule.actions[actionModel.key]) {
                delete actionModel.owningRule.actions[actionModel.key];
                _this.save(actionModel.owningRule);
            }
        });
        conditionGroupService.onAdd.subscribe(function (groupModel) {
            if (!groupModel.owningRule.groups[groupModel.key]) {
                groupModel.owningRule.groups[groupModel.key] = groupModel;
            }
        });
        conditionGroupService.onRemove.subscribe(function (groupModel) {
            if (!groupModel.owningRule.groups[groupModel.key]) {
                delete groupModel.owningRule.groups[groupModel.key];
            }
        });
    }
    RuleService.toJson = function (rule) {
        var json = {};
        json.key = rule.key;
        json.enabled = rule.enabled;
        json.fireOn = rule.fireOn;
        json.name = rule.name;
        json.priority = rule.priority;
        json.conditionGroups = ConditionGroup_1.ConditionGroupService.toJsonList(rule.groups);
        json.ruleActions = rule.actions;
        return json;
    };
    RuleService.fromSnapshot = function (key, snapshot) {
        var rule = new RuleModel(key);
        var val = snapshot.val();
        rule.snapshot = snapshot;
        rule.enabled = val.enabled;
        rule.fireOn = val.fireOn;
        rule.name = val.name;
        rule.priority = val.priority;
        rule.actions = val.ruleActions;
        var groups = snapshot.child('conditionGroups');
        if (groups.exists()) {
            groups.forEach(function (groupSnap) {
                rule.addGroup(ConditionGroup_1.ConditionGroupService._fromSnapshot(rule, groupSnap));
            });
        }
        return rule;
    };
    RuleService.prototype.get = function (key, cb) {
        this.ref.child(key).once('value', function (snap) {
            var rule = RuleService.fromSnapshot(key, snap);
            cb(rule);
        });
    };
    RuleService.prototype.list = function () {
        var _this = this;
        this.ref.once('value', function (snap) {
            var rules = snap['val']();
            Object.keys(rules).forEach(function (key) {
                var rule = RuleService.fromSnapshot(key, snap.child(key));
                _this._added.next(rule);
            });
        });
        return this.onAdd;
    };
    RuleService.prototype.add = function (rule, cb) {
        var _this = this;
        if (cb === void 0) { cb = null; }
        this.ref.push(RuleService.toJson(rule), function (resultSnapshot) {
            rule.snapshot = resultSnapshot;
            rule.key = resultSnapshot.key();
            _this._added.next(rule);
            if (cb) {
                cb(rule);
            }
        }).catch(function (e) {
            console.log("Error pushing new rule: ", e);
            throw e;
        });
    };
    RuleService.prototype.save = function (rule, cb) {
        if (cb === void 0) { cb = null; }
        if (!rule.isValid()) {
            throw new Error("Rule is not valid, cannot save.");
        }
        if (!rule.isPersisted()) {
            this.add(rule, cb);
        }
        else {
            this.ref.child(rule.key).set(RuleService.toJson(rule), function () {
                if (cb) {
                    cb(rule);
                }
            });
        }
    };
    RuleService.prototype.remove = function (rule) {
        var _this = this;
        if (rule.isPersisted()) {
            rule.snapshot.ref().remove(function (key) {
                _this._removed.next(rule);
            }).catch(function (e) {
                console.log("Error removing rule", e);
                throw e;
            });
        }
    };
    RuleService = __decorate([
        __param(0, angular2_1.Inject(ApiRoot_1.ApiRoot)),
        __param(1, angular2_1.Inject(Action_1.ActionService)),
        __param(2, angular2_1.Inject(ConditionGroup_1.ConditionGroupService)), 
        __metadata('design:paramtypes', [ApiRoot_1.ApiRoot, Action_1.ActionService, ConditionGroup_1.ConditionGroupService])
    ], RuleService);
    return RuleService;
})();
exports.RuleService = RuleService;
//# sourceMappingURL=Rule.js.map