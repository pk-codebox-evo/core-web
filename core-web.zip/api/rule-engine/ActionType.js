var __extends = (this && this.__extends) || function (d, b) {
    for (var p in b) if (b.hasOwnProperty(p)) d[p] = b[p];
    function __() { this.constructor = d; }
    d.prototype = b === null ? Object.create(b) : (__.prototype = b.prototype, new __());
};
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") return Reflect.decorate(decorators, target, key, desc);
    switch (arguments.length) {
        case 2: return decorators.reduceRight(function(o, d) { return (d && d(o)) || o; }, target);
        case 3: return decorators.reduceRight(function(o, d) { return (d && d(target, key)), void 0; }, void 0);
        case 4: return decorators.reduceRight(function(o, d) { return (d && d(target, key, o)) || o; }, desc);
    }
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
var __param = (this && this.__param) || function (paramIndex, decorator) {
    return function (target, key) { decorator(target, key, paramIndex); }
};
var angular2_1 = require('angular2/angular2');
var ApiRoot_1 = require("../persistence/ApiRoot");
var ActionTypeModel = (function () {
    function ActionTypeModel(id, i18nKey) {
        if (id === void 0) { id = 'NoSelection'; }
        if (i18nKey === void 0) { i18nKey = null; }
        this.id = id;
        this.i18nKey = i18nKey;
    }
    ActionTypeModel.prototype.clone = function () {
        throw new Error("Extending classes must implement their own clone method and should not call super.");
    };
    return ActionTypeModel;
})();
exports.ActionTypeModel = ActionTypeModel;
var ActionConfigModel = (function () {
    function ActionConfigModel(actionTypeId) {
        this.actionTypeId = actionTypeId;
    }
    ActionConfigModel.prototype.clone = function () {
        throw new Error("Extending classes must implement their own clone method and should not call super.");
    };
    ActionConfigModel.prototype.out = function () {
        return {};
    };
    return ActionConfigModel;
})();
exports.ActionConfigModel = ActionConfigModel;
var SetSessionValueActionModel = (function (_super) {
    __extends(SetSessionValueActionModel, _super);
    function SetSessionValueActionModel(parameters) {
        var _this = this;
        if (parameters === void 0) { parameters = {}; }
        _super.call(this, "SetSessionAttributeActionlet");
        this.sessionKey = '';
        this.sessionValue = '';
        Object.keys(parameters).forEach(function (paramId) {
            var param = parameters[paramId];
            switch (param.key) {
                case 'sessionValue':
                    {
                        _this.sessionValue = param.value || '';
                        break;
                    }
                case 'sessionKey':
                    {
                        _this.sessionKey = param.value || '';
                        break;
                    }
            }
        });
    }
    SetSessionValueActionModel.prototype.clone = function () {
        var model = new SetSessionValueActionModel();
        model.sessionKey = this.sessionKey;
        model.sessionValue = this.sessionValue;
        return model;
    };
    SetSessionValueActionModel.prototype.out = function () {
        return {
            sessionKey: {
                id: 'sessionKey',
                key: 'sessionKey',
                value: this.sessionKey
            }, sessionValue: {
                id: 'sessionValue',
                key: 'sessionValue',
                value: this.sessionValue
            }
        };
    };
    return SetSessionValueActionModel;
})(ActionConfigModel);
exports.SetSessionValueActionModel = SetSessionValueActionModel;
var ActionModelOld = (function () {
    function ActionModelOld(id, actionConfig) {
        if (id === void 0) { id = null; }
        if (actionConfig === void 0) { actionConfig = null; }
        this.id = id;
        this.actionConfig = actionConfig;
        this.priority = 0;
    }
    ActionModelOld.prototype.setActionType = function (actionType, parameters) {
        if (parameters === void 0) { parameters = {}; }
        if (actionType.id === 'SetSessionAttributeActionlet') {
            this.actionConfig = new SetSessionValueActionModel(parameters);
        }
        else {
            this.actionConfig = new ActionConfigModel(actionType.id);
        }
    };
    ActionModelOld.prototype.out = function () {
        return {
            id: this.id,
            actionlet: this.actionConfig.actionTypeId,
            priority: this.priority,
            name: this.name,
            owningRule: this.owningRuleId,
            parameters: this.actionConfig.out(),
        };
    };
    ActionModelOld.prototype.clone = function () {
        return new ActionModelOld(this.id, this.actionConfig.clone());
    };
    return ActionModelOld;
})();
exports.ActionModelOld = ActionModelOld;
var ActionTypesProvider = (function () {
    function ActionTypesProvider(apiRoot) {
        this.map = new Map();
        this.ary = [];
        this.actionsRef = apiRoot.root.child('system/ruleengine/actionlets');
        this.init();
    }
    ActionTypesProvider.prototype.init = function () {
        var _this = this;
        this.promise = new Promise(function (resolve, reject) {
            _this.actionsRef.once('value', function (snap) {
                var actionlets = snap['val']();
                var results = (Object.keys(actionlets).map(function (key) {
                    var actionType = actionlets[key];
                    _this.map.set(key, new ActionTypeModel(key, actionType.i18nKey));
                    return actionlets[key];
                }));
                Array.prototype.push.apply(_this.ary, results);
                resolve(_this);
            });
        });
    };
    ActionTypesProvider.prototype.getType = function (id) {
        return this.map.get(id);
    };
    ActionTypesProvider = __decorate([
        __param(0, angular2_1.Inject(ApiRoot_1.ApiRoot)), 
        __metadata('design:paramtypes', [Object])
    ], ActionTypesProvider);
    return ActionTypesProvider;
})();
exports.ActionTypesProvider = ActionTypesProvider;
//# sourceMappingURL=ActionType.js.map