var __extends = (this && this.__extends) || function (d, b) {
    for (var p in b) if (b.hasOwnProperty(p)) d[p] = b[p];
    function __() { this.constructor = d; }
    d.prototype = b === null ? Object.create(b) : (__.prototype = b.prototype, new __());
};
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") return Reflect.decorate(decorators, target, key, desc);
    switch (arguments.length) {
        case 2: return decorators.reduceRight(function(o, d) { return (d && d(o)) || o; }, target);
        case 3: return decorators.reduceRight(function(o, d) { return (d && d(target, key)), void 0; }, void 0);
        case 4: return decorators.reduceRight(function(o, d) { return (d && d(target, key, o)) || o; }, desc);
    }
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
var __param = (this && this.__param) || function (paramIndex, decorator) {
    return function (target, key) { decorator(target, key, paramIndex); }
};
var angular2_1 = require('angular2/angular2');
//import * as Rx from '../../../node_modules/angular2/node_modules/@reactivex/rxjs/src/Rx.KitchenSink'
var ApiRoot_1 = require("../persistence/ApiRoot");
var CwModel_1 = require("../util/CwModel");
var I18n_1 = require("../system/locale/I18n");
var noop = function () {
    var arg = [];
    for (var _i = 0; _i < arguments.length; _i++) {
        arg[_i - 0] = arguments[_i];
    }
};
var ActionTypeModel = (function (_super) {
    __extends(ActionTypeModel, _super);
    function ActionTypeModel(key, i18nKey, parameters) {
        if (key === void 0) { key = 'NoSelection'; }
        if (i18nKey === void 0) { i18nKey = null; }
        if (parameters === void 0) { parameters = {}; }
        _super.call(this, key ? key : 'NoSelection');
        this.i18nKey = i18nKey ? i18nKey : key;
        this.parameters = parameters ? parameters : {};
        this.rsrc = {
            name: this.i18nKey
        };
    }
    ActionTypeModel.prototype.getMessage = function (key) {
        return this._i18n ? this._i18n.getMessage(key) : this[key];
    };
    Object.defineProperty(ActionTypeModel.prototype, "i18n", {
        get: function () {
            return this._i18n;
        },
        set: function (value) {
            this._i18n = value;
            this._changed('i18n');
        },
        enumerable: true,
        configurable: true
    });
    ActionTypeModel.prototype.isValid = function () {
        return this.isPersisted() && !!this.i18nKey;
    };
    return ActionTypeModel;
})(CwModel_1.CwModel);
exports.ActionTypeModel = ActionTypeModel;
var DISABLED_ACTION_TYPE_IDS = {
    TestActionlet: true,
    CountRequestsActionlet: true
};
var ActionTypeService = (function () {
    function ActionTypeService(apiRoot, rsrcService) {
        this._ref = apiRoot.root.child('system/ruleengine/actionlets');
        this._apiRoot = apiRoot;
        this._rsrcService = rsrcService;
        this._added = new angular2_1.EventEmitter();
        this._refreshed = new angular2_1.EventEmitter();
        this.onAdd = Rx.Observable.from(this._added.toRx()).publishReplay();
        this.onRefresh = Rx.Observable.from(this._refreshed.toRx()).share();
        this._map = {};
        this.onAdd.connect();
    }
    ActionTypeService.prototype.fromSnapshot = function (snapshot) {
        var val = snapshot.val();
        var model = new ActionTypeModel(snapshot.key(), val.i18nKey, val.parameters);
        return model;
    };
    ActionTypeService.prototype._entryReceived = function (entry) {
        var isRefresh = this._map[entry.key] != null;
        this._map[entry.key] = entry;
        if (isRefresh) {
            this._refreshed.next(entry);
        }
        else {
            this._added.next(entry);
        }
    };
    ActionTypeService.prototype.list = function (cb) {
        var _this = this;
        if (cb === void 0) { cb = noop; }
        this._ref.once('value', function (snap) {
            var types = snap.val();
            var actionTypes = [];
            Object.keys(types).forEach(function (key) {
                if (DISABLED_ACTION_TYPE_IDS[key] !== true) {
                    var actionType = snap.child(key);
                    var model = _this.fromSnapshot(actionType);
                    _this._rsrcService.get(_this._apiRoot.authUser.locale, model.i18nKey, function (rsrcResult) {
                        if (rsrcResult && rsrcResult.getMessage('name')) {
                            model.i18n = rsrcResult;
                            model.rsrc.name = rsrcResult.getMessage('name');
                        }
                        else {
                            model.rsrc.name = model.i18nKey;
                        }
                        _this._entryReceived(model);
                        actionTypes.push(model);
                    });
                }
            });
            cb(actionTypes);
        }, function (e) {
            throw e;
        });
        return this.onAdd;
    };
    ActionTypeService.prototype.get = function (key, cb) {
        if (cb === void 0) { cb = noop; }
        var cachedValue = this._map[key];
        if (cachedValue) {
            cb(cachedValue);
        }
        else {
            /* There is no direct endpoint to get conditions by key. So we'll fake it a bit, and just wait for a call to
             'list' to trigger the observer. */
            var sub = this.onAdd.subscribe(function (type) {
                if (type.key == key) {
                    cb(type);
                    sub.unsubscribe();
                }
            });
        }
    };
    ActionTypeService = __decorate([
        __param(0, angular2_1.Inject(ApiRoot_1.ApiRoot)),
        __param(1, angular2_1.Inject(I18n_1.I18nService)), 
        __metadata('design:paramtypes', [Object, I18n_1.I18nService])
    ], ActionTypeService);
    return ActionTypeService;
})();
exports.ActionTypeService = ActionTypeService;
//# sourceMappingURL=ActionType.js.map