var angular2_1 = require('angular2/angular2');
var DataStore_1 = require('../../api/persistence/DataStore');
var RestDataStore_1 = require('../../api/persistence/RestDataStore');
var ApiRoot_1 = require('../../api/persistence/ApiRoot');
var UserModel_1 = require('../../api/auth/UserModel');
var ConditionType_1 = require('../../api/rule-engine/ConditionType');
var injector = angular2_1.Injector.resolveAndCreate([ApiRoot_1.ApiRoot,
    UserModel_1.UserModel,
    ConditionType_1.ConditionTypeService,
    new angular2_1.Provider(DataStore_1.DataStore, { useClass: RestDataStore_1.RestDataStore })
]);
describe('Integration.api.rule-engine.RuleService', function () {
    var typeService;
    var subscriptions;
    beforeEach(function () {
        subscriptions = [];
        typeService = injector.get(ConditionType_1.ConditionTypeService);
    });
    afterEach(function () {
        subscriptions.forEach(function (sub) {
            sub.unsubscribe();
        });
    });
    it("Can list condition types, and they are all persisted and valid.", function (done) {
        var count = 0;
        var subscription = typeService.onAdd.subscribe(function (conditionType) {
            count++;
        }, function (err) {
            expect(err).toBeUndefined("error was thrown creating Rule.");
            done();
        });
        subscriptions.push(subscription); // for cleanup.
        typeService.list(function (types) {
            expect(count).toEqual(types.length, "onAdd subscriber notification count should be same as number of types provided to callback.");
            types.forEach(function (type) {
                expect(type.isPersisted()).toBe(true, "Condition types are readonly and should always be persisted.");
                expect(type.isValid()).toBe(true, "Condition types are readonly and should always be valid.");
            });
            done();
        });
    });
    it("There are three active condition types.", function (done) {
        typeService.list(function (types) {
            expect(types.length).toEqual(3, "We have only enabled three condition types. Please update name of test when you update this expectation.");
            done();
        });
    });
});
//# sourceMappingURL=ConditionType.it-spec.js.map