var Rule_1 = require('../../api/rule-engine/Rule');
var Condition_1 = require('../../api/rule-engine/Condition');
var angular2_1 = require('angular2/angular2');
var DataStore_1 = require('../../api/persistence/DataStore');
var RestDataStore_1 = require('../../api/persistence/RestDataStore');
var ApiRoot_1 = require('../../api/persistence/ApiRoot');
var UserModel_1 = require('../../api/auth/UserModel');
var Action_1 = require('../../api/rule-engine/Action');
var ConditionGroup_1 = require('../../api/rule-engine/ConditionGroup');
var injector = angular2_1.Injector.resolveAndCreate([ApiRoot_1.ApiRoot,
    //ActionTypesProvider,
    //ConditionTypesProvider,
    UserModel_1.UserModel,
    //I18NCountryProvider,
    Rule_1.RuleService,
    Action_1.ActionService,
    Condition_1.ConditionService,
    ConditionGroup_1.ConditionGroupService,
    new angular2_1.Provider(DataStore_1.DataStore, { useClass: RestDataStore_1.RestDataStore })
]);
describe('Integration.api.rule-engine.RuleService', function () {
    var ruleService;
    var rulesToRemove;
    beforeEach(function () {
        ruleService = injector.get(Rule_1.RuleService);
        rulesToRemove = [];
    });
    afterEach(function () {
        rulesToRemove.forEach(function (rule) {
            ruleService.remove(rule);
        });
    });
    it("Can create a simple rule.", function (done) {
        var clientRule;
        clientRule = new Rule_1.RuleModel();
        clientRule.enabled = true;
        clientRule.name = "TestRule-" + new Date().getTime();
        var ruleOnAddSub = ruleService.onAdd.subscribe(function (serverRule) {
            rulesToRemove.push(serverRule);
            expect(serverRule.isPersisted()).toBe(true);
            expect(serverRule.enabled).toBe(true);
            expect(serverRule.name).toBe(clientRule.name);
            var randomKey = 'abc_' + Math.round(Math.random() * 1000);
            serverRule[randomKey] = "The object provided by the observer is the same instance as the one added.";
            expect(clientRule[randomKey]).toBe(serverRule[randomKey]);
            done();
        }, function (err) {
            expect(err).toBeUndefined("error was thrown creating Rule.");
            done();
        });
        ruleService.add(clientRule); // will trigger callback to subscription.
    });
});
