var __extends = (this && this.__extends) || function (d, b) {
    for (var p in b) if (b.hasOwnProperty(p)) d[p] = b[p];
    function __() { this.constructor = d; }
    d.prototype = b === null ? Object.create(b) : (__.prototype = b.prototype, new __());
};
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") return Reflect.decorate(decorators, target, key, desc);
    switch (arguments.length) {
        case 2: return decorators.reduceRight(function(o, d) { return (d && d(o)) || o; }, target);
        case 3: return decorators.reduceRight(function(o, d) { return (d && d(target, key)), void 0; }, void 0);
        case 4: return decorators.reduceRight(function(o, d) { return (d && d(target, key, o)) || o; }, desc);
    }
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
var __param = (this && this.__param) || function (paramIndex, decorator) {
    return function (target, key) { decorator(target, key, paramIndex); }
};
var angular2_1 = require('angular2/angular2');
var ConditionType_1 = require("./ConditionType");
var CwModel_1 = require("../util/CwModel");
var ApiRoot_1 = require("../persistence/ApiRoot");
var ConditionType_2 = require("./ConditionType");
var noop = function () {
    var arg = [];
    for (var _i = 0; _i < arguments.length; _i++) {
        arg[_i - 0] = arguments[_i];
    }
};
var ConditionModel = (function (_super) {
    __extends(ConditionModel, _super);
    function ConditionModel(key) {
        if (key === void 0) { key = null; }
        _super.call(this, key);
        this._conditionType = new ConditionType_1.ConditionTypeModel('', '');
        this.comparison = 'is';
        this.operator = 'AND';
        this.priority = 1;
        this._parameters = {};
    }
    ConditionModel.prototype.setParameter = function (key, value, priority) {
        if (priority === void 0) { priority = 1; }
        var existing = this._parameters[key];
        this._parameters[key] = { key: key, value: value, priority: priority };
        this._changed('parameters');
    };
    ConditionModel.prototype.getParameter = function (key) {
        var v = '';
        if (this.parameters[key] !== undefined) {
            v = this.parameters[key].value;
        }
        return v;
    };
    ConditionModel.prototype.clearParameters = function () {
        this._parameters = {};
        this._changed('parameters');
    };
    Object.defineProperty(ConditionModel.prototype, "parameters", {
        get: function () {
            return this._parameters;
        },
        enumerable: true,
        configurable: true
    });
    Object.defineProperty(ConditionModel.prototype, "conditionType", {
        get: function () {
            return this._conditionType;
        },
        set: function (value) {
            this._conditionType = value;
            this._changed('conditionType');
        },
        enumerable: true,
        configurable: true
    });
    Object.defineProperty(ConditionModel.prototype, "owningGroup", {
        get: function () {
            return this._owningGroup;
        },
        set: function (value) {
            this._owningGroup = value;
            this._changed('owningGroup');
        },
        enumerable: true,
        configurable: true
    });
    Object.defineProperty(ConditionModel.prototype, "name", {
        get: function () {
            return this._name;
        },
        set: function (value) {
            this._name = value;
            this._changed('name');
        },
        enumerable: true,
        configurable: true
    });
    Object.defineProperty(ConditionModel.prototype, "comparison", {
        get: function () {
            return this._comparison;
        },
        set: function (value) {
            this._comparison = value;
            this._changed('comparison');
        },
        enumerable: true,
        configurable: true
    });
    Object.defineProperty(ConditionModel.prototype, "operator", {
        get: function () {
            return this._operator;
        },
        set: function (value) {
            this._operator = value;
        },
        enumerable: true,
        configurable: true
    });
    ConditionModel.prototype._changed = function (key) {
        console.log("api.rule-engine.ConditionModel", "_changed", key);
        _super.prototype._changed.call(this, key);
    };
    ConditionModel.prototype.isValid = function () {
        var valid = !!this._owningGroup;
        valid = valid && this._owningGroup.isValid();
        valid = valid && this._conditionType && this._conditionType.key && this._conditionType.key != 'NoSelection';
        return valid;
    };
    return ConditionModel;
})(CwModel_1.CwModel);
exports.ConditionModel = ConditionModel;
var ConditionService = (function () {
    function ConditionService(apiRoot, conditionTypeService) {
        this._apiRoot = apiRoot;
        this._conditionTypeService = conditionTypeService;
        this._ref = apiRoot.defaultSite.child('ruleengine/conditions');
        this._added = new angular2_1.EventEmitter();
        this._removed = new angular2_1.EventEmitter();
        var onAdd = Rx.Observable.from(this._added.toRx());
        var onRemove = Rx.Observable.from(this._removed.toRx());
        this.onAdd = onAdd.share();
        this.onRemove = onRemove.share();
    }
    ConditionService.prototype.fromSnapshot = function (group, snapshot) {
        var val = snapshot.val();
        var ra = new ConditionModel(snapshot.key());
        ra.name = val.name;
        ra.owningGroup = group;
        ra.comparison = val.comparison;
        ra.priority = val.priority;
        ra.operator = val.operator;
        Object.keys(val.values).forEach(function (key) {
            var x = val.values[key];
            ra.setParameter(key, x.value, x.priority);
        });
        this._conditionTypeService.get(val.conditionlet, function (type) {
            console.log('yay:', type);
            ra.conditionType = type;
        });
        return ra;
    };
    ConditionService.toJson = function (condition) {
        var json = {};
        json.id = condition.key;
        json.name = condition.name || "fake_name_" + new Date().getTime() + '_' + Math.random();
        json.owningGroup = condition.owningGroup.key;
        json.conditionlet = condition.conditionType.key;
        json.comparison = condition.comparison;
        json.priority = condition.priority;
        json.operator = condition.operator;
        json.values = condition.parameters;
        return json;
    };
    ConditionService.prototype.addConditionsFromRule = function (rule) {
        var _this = this;
        Object.keys(rule.groups).forEach(function (groupId) {
            var group = rule.groups[groupId];
            _this.addConditionsFromConditionGroup(group);
        });
    };
    ConditionService.prototype.addConditionsFromConditionGroup = function (group) {
        var _this = this;
        Object.keys(group.conditions).forEach(function (conditionId) {
            var cRef = _this._ref.child(conditionId);
            cRef.once('value', function (conditionSnap) {
                _this._added.next(_this.fromSnapshot(group, conditionSnap));
            });
        });
    };
    ConditionService.prototype.listForRule = function (rule) {
        var _this = this;
        if (rule.isPersisted()) {
            this.addConditionsFromRule(rule);
        }
        else {
            rule.onChange.subscribe(function (event) {
                if (event.type == 'key') {
                    _this.addConditionsFromRule(event.target);
                }
            });
        }
        return this.onAdd;
    };
    ConditionService.prototype.listForGroup = function (group) {
        this.addConditionsFromConditionGroup(group);
    };
    ConditionService.prototype.get = function (group, key, cb) {
        var _this = this;
        if (cb === void 0) { cb = null; }
        this._ref.child(key).once('value', function (conditionSnap) {
            var model = _this.fromSnapshot(group, conditionSnap);
            _this._added.next(model);
            cb(model);
        });
    };
    ConditionService.prototype.add = function (model, cb) {
        var _this = this;
        if (cb === void 0) { cb = noop; }
        console.log("api.rule-engine.ConditionService", "add", model);
        if (!model.isValid()) {
            throw new Error("This should be thrown from a checkValid function on the model, and should provide the info needed to make the user aware of the fix.");
        }
        var json = ConditionService.toJson(model);
        this._ref.push(json, function (result) {
            model.key = result.key();
            _this._added.next(model);
            cb(model);
        });
    };
    ConditionService.prototype.save = function (model, cb) {
        if (cb === void 0) { cb = noop; }
        console.log("api.rule-engine.ConditionService", "save", model);
        if (!model.isValid()) {
            throw new Error("This should be thrown from a checkValid function on the model, and should provide the info needed to make the user aware of the fix.");
        }
        if (!model.isPersisted()) {
            this.add(model, cb);
        }
        else {
            var json = ConditionService.toJson(model);
            this._ref.child(model.key).set(json, function (result) {
                cb(model);
            });
        }
    };
    ConditionService.prototype.remove = function (model, cb) {
        var _this = this;
        if (cb === void 0) { cb = noop; }
        console.log("api.rule-engine.ConditionService", "remove", model);
        this._ref.child(model.key).remove(function () {
            _this._removed.next(model);
            cb(model);
        });
    };
    ConditionService = __decorate([
        __param(0, angular2_1.Inject(ApiRoot_1.ApiRoot)),
        __param(1, angular2_1.Inject(ConditionType_2.ConditionTypeService)), 
        __metadata('design:paramtypes', [Object, ConditionType_2.ConditionTypeService])
    ], ConditionService);
    return ConditionService;
})();
exports.ConditionService = ConditionService;
//# sourceMappingURL=Condition.js.map