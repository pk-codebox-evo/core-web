var Action_1 = require('api/rule-engine/Action');
describe('Unit.api.rule-engine.Action', function () {
    beforeEach(function () {
    });
    it("Isn't valid when new.", function () {
        var foo = new Action_1.ActionModel();
        expect(foo.valid).toEqual(false);
    });
});
//# sourceMappingURL=Action.spec.js.map