var Rule_1 = require('../../api/rule-engine/Rule');
var angular2_1 = require('angular2/angular2');
var RestDataStore_1 = require("../../api/persistence/RestDataStore");
var DataStore_1 = require("../../api/persistence/DataStore");
var ApiRoot_1 = require('../../api/persistence/ApiRoot');
var UserModel_1 = require("../../api/auth/UserModel");
var Action_1 = require("../../api/rule-engine/Action");
var ConditionGroup_1 = require("../../api/rule-engine/ConditionGroup");
var Condition_1 = require("../../api/rule-engine/Condition");
var ActionType_1 = require("./ActionType");
var injector = angular2_1.Injector.resolveAndCreate([ApiRoot_1.ApiRoot,
    //ActionTypesProvider,
    //ConditionTypesProvider,
    UserModel_1.UserModel,
    //I18NCountryProvider,
    Rule_1.RuleService,
    Action_1.ActionService,
    Condition_1.ConditionService,
    ConditionGroup_1.ConditionGroupService,
    new angular2_1.Provider(DataStore_1.DataStore, { useClass: RestDataStore_1.RestDataStore })
]);
describe('Integration.api.rule-engine.ActionService', function () {
    var ruleService;
    var ruleOnAddSub;
    var actionService;
    var ruleUnderTest;
    beforeEach(function (done) {
        ruleService = injector.get(Rule_1.RuleService);
        actionService = injector.get(Action_1.ActionService);
        ruleOnAddSub = ruleService.onAdd.subscribe(function (rule) {
            ruleUnderTest = rule;
            done();
        }, function (err) {
            expect(err).toBeUndefined("error was thrown.");
            done();
        });
        Gen.createRules(ruleService);
    });
    afterEach(function () {
        ruleService.remove(ruleUnderTest);
        ruleUnderTest = null;
        ruleOnAddSub.unsubscribe();
    });
    it("Has rules that we can add actions to", function () {
        expect(ruleUnderTest.isPersisted()).toBe(true);
    });
    it("Can add a new Action", function (done) {
        var anAction = new Action_1.ActionModel();
        anAction.actionType = new ActionType_1.ActionTypeModel("SetSessionAttributeActionlet");
        anAction.owningRule = ruleUnderTest;
        anAction.setParameter("sessionKey", "foo");
        anAction.setParameter("sessionValue", "bar");
        var subscriber = actionService.onAdd.subscribe(function (action) {
            //noinspection TypeScriptUnresolvedFunction
            expect(action.isPersisted()).toBe(true, "Action is not persisted!");
            done();
        }, function (err) {
            expect(err).toBeUndefined("error was thrown.");
            done();
        });
        actionService.add(anAction);
    });
    it("Is added to the owning rule's list of actions.", function (done) {
        var anAction = new Action_1.ActionModel();
        anAction.actionType = new ActionType_1.ActionTypeModel("SetSessionAttributeActionlet");
        anAction.owningRule = ruleUnderTest;
        anAction.setParameter("sessionKey", "foo");
        anAction.setParameter("sessionValue", "bar");
        actionService.onAdd.subscribe(function (action) {
            expect(ruleUnderTest.actions[action.key]).toBe(true, "Check the ActionService.onAdd listener in the RuleService.");
            done();
        }, function (err) {
            expect(err).toBeUndefined("error was thrown.");
            done();
        });
        actionService.add(anAction);
    });
    it("Action being added to the owning rule is persisted to server.", function (done) {
        var anAction = new Action_1.ActionModel();
        anAction.actionType = new ActionType_1.ActionTypeModel("SetSessionAttributeActionlet");
        anAction.owningRule = ruleUnderTest;
        anAction.setParameter("sessionKey", "foo");
        anAction.setParameter("sessionValue", "bar");
        var firstPass = actionService.onAdd.subscribe(function (action) {
            //noinspection TypeScriptUnresolvedFunction
            firstPass.unsubscribe(); // don't want to run THIS watcher twice.
            expect(ruleUnderTest.actions[action.key]).toBe(true, "Check the ActionService.onAdd listener in the RuleService.");
            ruleService.save(ruleUnderTest, function () {
                ruleService.get(ruleUnderTest.key, function (rule) {
                    expect(rule.actions[action.key]).toBe(true);
                    /* Now read the Actions off the rule we just got back. Add listener first, then trigger call. */
                    var sub = actionService.onAdd.subscribe(function (action) {
                        expect(action.getParameter("sessionKey")).toEqual("foo");
                        sub.unsubscribe();
                        done();
                    });
                    actionService.list(rule);
                });
            });
        }, function (err) {
            expect(err).toBeUndefined("error was thrown!");
            done();
        });
        actionService.add(anAction);
    });
    it("Will add a new action parameters to an existing action.", function (done) {
        var clientAction = new Action_1.ActionModel();
        clientAction.actionType = new ActionType_1.ActionTypeModel("SetSessionAttributeActionlet");
        clientAction.owningRule = ruleUnderTest;
        clientAction.setParameter("sessionKey", "foo");
        clientAction.setParameter("sessionValue", "bar");
        var key = "aParamKey";
        var value = "aParamValue";
        actionService.add(clientAction, function (resultAction) {
            // serverAction is the same instance as resultAction
            expect(clientAction.isPersisted()).toBe(true, "Action is not persisted!");
            clientAction.clearParameters();
            clientAction.setParameter(key, value);
            actionService.save(clientAction, function (savedAction) {
                // savedAction is also the same instance as resultAction
                actionService.get(clientAction.owningRule, clientAction.key, function (updatedAction) {
                    // updatedAction and clientAction SHOULD NOT be the same instance object.
                    updatedAction['abc123'] = 100;
                    expect(clientAction['abc123']).toBeUndefined();
                    expect(clientAction.getParameter(key)).toBe(value, "ClientAction param value should still be set.");
                    expect(updatedAction.getParameter(key)).toBe(value, "Action refreshed from server should have the correct param value.");
                    expect(Object.keys(updatedAction.parameters).length).toEqual(1, "The old keys should have been removed.");
                    done();
                });
            });
        });
    });
    it("Can update action parameter values on existing action.", function (done) {
        var param1 = { key: 'sessionKey', v1: 'value1', v2: 'value2' };
        var param2 = { key: 'sessionValue', v1: 'abc123', v2: 'def456' };
        var clientAction = new Action_1.ActionModel();
        clientAction.actionType = new ActionType_1.ActionTypeModel("SetSessionAttributeActionlet");
        clientAction.owningRule = ruleUnderTest;
        clientAction.setParameter(param1.key, param1.v1);
        clientAction.setParameter(param2.key, param2.v1);
        actionService.add(clientAction, function (resultAction) {
            clientAction.setParameter(param1.key, param1.v2);
            actionService.save(clientAction, function (savedAction) {
                actionService.get(clientAction.owningRule, clientAction.key, function (updatedAction) {
                    expect(updatedAction.getParameter(param1.key)).toBe(param1.v2, "Action refreshed from server should have the correct param value.");
                    expect(updatedAction.getParameter(param2.key)).toBe(param2.v1, "Action refreshed from server should have the correct param value.");
                    expect(Object.keys(updatedAction.parameters).length).toEqual(2, "The old keys should have been removed.");
                    done();
                });
            });
        });
    });
});
var Gen = (function () {
    function Gen() {
    }
    Gen.createRules = function (ruleService) {
        console.log('Attempting to create rule.');
        var rule = new Rule_1.RuleModel();
        rule.enabled = true;
        rule.name = "TestRule-" + new Date().getTime();
        ruleService.add(rule);
    };
    return Gen;
})();
//# sourceMappingURL=Action.it-spec.js.map