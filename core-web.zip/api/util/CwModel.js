var angular2_1 = require('angular2/angular2');
var CwModel = (function () {
    function CwModel(key) {
        if (key === void 0) { key = null; }
        this._change = new angular2_1.EventEmitter();
        this._validityChange = new angular2_1.EventEmitter();
        this.onChange = Rx.Observable.from(this._change.toRx()).debounceTime(100).share();
        this.onValidityChange = Rx.Observable.from(this._validityChange.toRx()).debounceTime(100).share();
        this._key = key;
        this.valid = this.isValid();
    }
    Object.defineProperty(CwModel.prototype, "key", {
        get: function () {
            return this._key;
        },
        set: function (value) {
            this._key = value;
            this._changed('key');
        },
        enumerable: true,
        configurable: true
    });
    Object.defineProperty(CwModel.prototype, "priority", {
        get: function () {
            return this._priority;
        },
        set: function (value) {
            this._priority = value;
            this._changed('priority');
        },
        enumerable: true,
        configurable: true
    });
    CwModel.prototype.isPersisted = function () {
        return !!this.key;
    };
    CwModel.prototype._changed = function (type) {
        this._checkValid();
        this._change.next({ type: type, target: this });
    };
    CwModel.prototype._checkValid = function () {
        var valid = this.valid;
        this.valid = this.isValid();
        if (valid !== this.valid) {
            this._validityChange.next({ key: 'valid', target: this, valid: this.valid });
        }
    };
    /**
     * Override me.
     * @returns {boolean}
     */
    CwModel.prototype.isValid = function () {
        return true;
    };
    return CwModel;
})();
exports.CwModel = CwModel;
//# sourceMappingURL=CwModel.js.map