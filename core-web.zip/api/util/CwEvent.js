var CwChangeEvent = (function () {
    function CwChangeEvent() {
    }
    return CwChangeEvent;
})();
exports.CwChangeEvent = CwChangeEvent;
//# sourceMappingURL=CwEvent.js.map