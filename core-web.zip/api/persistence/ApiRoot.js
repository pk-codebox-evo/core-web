var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") return Reflect.decorate(decorators, target, key, desc);
    switch (arguments.length) {
        case 2: return decorators.reduceRight(function(o, d) { return (d && d(o)) || o; }, target);
        case 3: return decorators.reduceRight(function(o, d) { return (d && d(target, key)), void 0; }, void 0);
        case 4: return decorators.reduceRight(function(o, d) { return (d && d(target, key, o)) || o; }, desc);
    }
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
var __param = (this && this.__param) || function (paramIndex, decorator) {
    return function (target, key) { decorator(target, key, paramIndex); }
};
var angular2_1 = require('angular2/angular2');
var EntityBase_1 = require("./EntityBase");
var DataStore_1 = require("./DataStore");
var UserModel_1 = require("../auth/UserModel");
var instanceOfApiRoot = null;
var ApiRoot = (function () {
    function ApiRoot(authUser, dataStore) {
        this.baseUrl = "http://localhost:8080/";
        this.defaultSiteId = '48190c8c-42c4-46af-8d1a-0cd5db894797';
        this.authUser = authUser;
        this.dataStore = dataStore;
        dataStore.setAuth(authUser.username, authUser.password);
        try {
            var query = document.location.search.substring(1);
            var siteId = ApiRoot.parseQueryParam(query, "realmId");
            if (siteId) {
                this.defaultSiteId = siteId;
                console.log('Site Id set to ', this.defaultSiteId);
            }
            var baseUrl = ApiRoot.parseQueryParam(query, 'baseUrl');
            console.log('Proxy server Base URL set to ', baseUrl);
            this.setBaseUrl(baseUrl); // if null, just uses the base of the current URL
            this.resourceRef = this.root.child('system/i18n');
        }
        catch (e) {
            console.log("Could not set baseUrl automatically.");
        }
        instanceOfApiRoot = this;
    }
    ApiRoot.parseQueryParam = function (query, token) {
        var idx = -1;
        var result = null;
        token = token + '=';
        if (query && query.length) {
            idx = query.indexOf(token);
        }
        if (idx >= 0) {
            var end = query.indexOf('&', idx);
            end = end != -1 ? end : query.length;
            result = query.substring(idx + token.length, end);
        }
        return result;
    };
    ;
    ApiRoot.prototype.setBaseUrl = function (url) {
        if (url === void 0) { url = null; }
        if (url === null) {
            // set to same as current request
            var loc = document.location;
            this.baseUrl = loc.protocol + '//' + loc.host + '/';
        }
        else if (url && (url.startsWith('http://' || url.startsWith('https://')))) {
            this.baseUrl = url.endsWith('/') ? url : url + '/';
        }
        else {
            throw new Error("Invalid proxy server base url: '" + url + "'");
        }
        this.root = new EntityBase_1.EntityMeta(this.baseUrl + 'api/v1');
        this.defaultSite = this.root.child('sites/' + this.defaultSiteId);
    };
    ApiRoot.prototype.getRoot = function () {
        return this.root;
    };
    ApiRoot.instance = function () {
        return instanceOfApiRoot;
    };
    ApiRoot = __decorate([
        __param(0, angular2_1.Inject(UserModel_1.UserModel)),
        __param(1, angular2_1.Inject(DataStore_1.DataStore)), 
        __metadata('design:paramtypes', [UserModel_1.UserModel, DataStore_1.DataStore])
    ], ApiRoot);
    return ApiRoot;
})();
exports.ApiRoot = ApiRoot;
//# sourceMappingURL=ApiRoot.js.map