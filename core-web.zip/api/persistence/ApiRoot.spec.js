var angular2_1 = require('angular2/angular2');
var UserModel_1 = require("../../api/auth/UserModel");
var ApiRoot_1 = require('../../api/persistence/ApiRoot');
var DataStore_1 = require('api/persistence/DataStore');
var LocalDataStore_1 = require("api/persistence/LocalDataStore");
var injector = angular2_1.Injector.resolveAndCreate([
    UserModel_1.UserModel,
    ApiRoot_1.ApiRoot,
    new angular2_1.Provider(DataStore_1.DataStore, { useClass: LocalDataStore_1.LocalDataStore })
]);
describe('Unit.api.persistence.ApiRoot', function () {
    var apiRoot;
    beforeEach(function () {
        apiRoot = injector.get(ApiRoot_1.ApiRoot);
    });
    it("The ApiRoot is injected.", function () {
        expect(apiRoot).not.toBeNull();
    });
    it("Parses a query param correctly when it's the last query parameter.", function () {
        var siteId = '48190c8c-42c4-46af-8d1a-0cd5db894797';
        expect(ApiRoot_1.ApiRoot.parseQueryParam("foo=bar&baz=1&realmId=" + siteId, 'realmId')).toEqual(siteId);
    });
    it("Parses a query param correctly when it's the first query parameter.", function () {
        var siteId = '48190c8c-42c4-46af-8d1a-0cd5db894797';
        expect(ApiRoot_1.ApiRoot.parseQueryParam("realmId=" + siteId + "&foo=bar&baz=1", 'realmId')).toEqual(siteId);
    });
    it("Parses a query param correctly when it's the in the middle of the query.", function () {
        var siteId = '48190c8c-42c4-46af-8d1a-0cd5db894797';
        expect(ApiRoot_1.ApiRoot.parseQueryParam("blarg=99thousand&realmId=" + siteId + "&foo=bar&baz=1", 'realmId')).toEqual(siteId);
    });
});
//# sourceMappingURL=ApiRoot.spec.js.map