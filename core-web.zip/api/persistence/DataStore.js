var Check_1 = require('../validation/Check');
var DataStore = (function () {
    function DataStore() {
    }
    Object.defineProperty(DataStore.prototype, "length", {
        get: function () {
            return 0;
        },
        enumerable: true,
        configurable: true
    });
    DataStore.prototype.checkPath = function (path) {
        Check_1.Check.notEmpty(path, "Path cannot be blank.");
        Check_1.Check.isString(path, "Path must be a string.");
        if (!path.startsWith("http")) {
            throw new Error("Path must be a valid URL");
        }
        return path;
    };
    DataStore.prototype.path = function (idx) { };
    DataStore.prototype.clear = function () { };
    DataStore.prototype.setItem = function (path, value, isNew) {
        if (isNew === void 0) { isNew = false; }
    };
    DataStore.prototype.getItem = function (path) { };
    DataStore.prototype.getItems = function () {
        var paths = [];
        for (var _i = 0; _i < arguments.length; _i++) {
            paths[_i - 0] = arguments[_i];
        }
        return [];
    };
    DataStore.prototype.hasItem = function (path) { return false; };
    DataStore.prototype.removeItem = function (path) { };
    DataStore.prototype.childPaths = function (path) { return []; };
    DataStore.prototype.childKeys = function (path) { return []; };
    DataStore.prototype.childItems = function (path) { };
    DataStore.prototype.setAuth = function (x, y) {
        if (x === void 0) { x = null; }
        if (y === void 0) { y = null; }
    };
    return DataStore;
})();
exports.DataStore = DataStore;
//# sourceMappingURL=DataStore.js.map