var UserModel = (function () {
    function UserModel() {
        if (top.location.port && top.location.port >= 9000) {
            this.username = 'admin@dotcms.com';
            this.password = 'admin';
        }
        this.locale = 'en-US'; // default to 'en-US'
        try {
            var url = top.document.location.search.substring(1);
            this.locale = this.checkQueryForUrl(url);
        }
        catch (e) {
            console.log("Could not set locale from URL.");
        }
    }
    UserModel.prototype.checkQueryForUrl = function (locationQuery) {
        var locale = this.locale;
        if (locationQuery && locationQuery.length) {
            var q = locationQuery;
            var token = 'locale=';
            var idx = q.indexOf(token);
            if (idx >= 0) {
                var end = q.indexOf('&', idx);
                end = end != -1 ? end : q.indexOf('#', idx);
                end = end != -1 ? end : q.length;
                locale = q.substring(idx + token.length, end);
                console.log('Locale set to to ', locale);
            }
        }
        return locale;
    };
    return UserModel;
})();
exports.UserModel = UserModel;
//# sourceMappingURL=UserModel.js.map