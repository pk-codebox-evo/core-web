export * from './icon';

//# sourceMappingURL=index.js.map
