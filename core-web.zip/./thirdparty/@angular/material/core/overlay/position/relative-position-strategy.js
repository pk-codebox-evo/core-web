export var RelativePositionStrategy = (function () {
    function RelativePositionStrategy(_relativeTo) {
        this._relativeTo = _relativeTo;
    }
    RelativePositionStrategy.prototype.apply = function (element) {
        // Not yet implemented.
        return null;
    };
    return RelativePositionStrategy;
}());

//# sourceMappingURL=relative-position-strategy.js.map
