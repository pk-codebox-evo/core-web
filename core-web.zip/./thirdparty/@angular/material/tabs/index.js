export * from './tabs';

//# sourceMappingURL=index.js.map
