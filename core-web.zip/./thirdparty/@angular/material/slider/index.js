export * from './slider';

//# sourceMappingURL=index.js.map
