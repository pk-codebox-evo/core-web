System.register([], function(exports_1) {
    var __extends = (this && this.__extends) || function (d, b) {
        for (var p in b) if (b.hasOwnProperty(p)) d[p] = b[p];
        function __() { this.constructor = d; }
        d.prototype = b === null ? Object.create(b) : (__.prototype = b.prototype, new __());
    };
    var TestUtil, Page, TestButton, TestInputComponent, TestInputText, TestInputDropdown, TestInputToggle;
    return {
        setters:[],
        execute: function() {
            TestUtil = (function () {
                function TestUtil() {
                }
                // A Protracterized httpGet() promise [curtesy of Leo Galluci ,
                // http://stackoverflow.com/questions/25137881/how-to-use-protractor-to-get-the-response-status-code-and-response-text
                TestUtil.httpGet = function (siteUrl) {
                    //noinspection TypeScriptUnresolvedFunction
                    var http = require('http');
                    var defer = protractor.promise.defer();
                    http.get(siteUrl, function (response) {
                        var bodyString = '';
                        response.setEncoding('utf8');
                        response.on("data", function (chunk) {
                            bodyString += chunk;
                        });
                        response.on('end', function () {
                            defer.fulfill({
                                response: response,
                                statusCode: response.statusCode,
                                bodyString: bodyString
                            });
                        });
                    }).on('error', function (e) {
                        defer.reject("Got http.get error: " + e.message);
                    });
                    return defer.promise;
                };
                return TestUtil;
            })();
            exports_1("TestUtil", TestUtil);
            Page = (function () {
                function Page(url, title) {
                    this.url = url;
                    this.title = title;
                }
                Page.prototype.navigateTo = function () {
                    browser.get(this.url);
                    expect(browser.getTitle()).toEqual(this.title);
                    return this;
                };
                Page.logBrowserConsole = function () {
                    browser.manage().logs().get('browser').then(function (browserLog) {
                        //noinspection TypeScriptUnresolvedFunction
                        console.log('log: ' + require('util').inspect(browserLog));
                    });
                };
                return Page;
            })();
            exports_1("Page", Page);
            TestButton = (function () {
                function TestButton(el) {
                    this.el = el;
                }
                TestButton.prototype.click = function () {
                    this.el.click();
                };
                return TestButton;
            })();
            exports_1("TestButton", TestButton);
            TestInputComponent = (function () {
                function TestInputComponent(el) {
                    this.el = el;
                }
                return TestInputComponent;
            })();
            exports_1("TestInputComponent", TestInputComponent);
            TestInputText = (function (_super) {
                __extends(TestInputText, _super);
                function TestInputText(el) {
                    _super.call(this, el);
                    this.valueInput = this.el.element(by.tagName('INPUT'));
                    this.icon = this.el.element(by.tagName('I'));
                }
                TestInputText.prototype.focus = function () {
                    return this.valueInput.click();
                };
                TestInputText.prototype.placeholder = function () {
                    return this.valueInput.getAttribute('placeholder');
                };
                TestInputText.prototype.getValue = function () {
                    return this.valueInput.getAttribute('value');
                };
                TestInputText.prototype.setValue = function (value) {
                    return this.valueInput.sendKeys(value);
                };
                return TestInputText;
            })(TestInputComponent);
            exports_1("TestInputText", TestInputText);
            TestInputDropdown = (function (_super) {
                __extends(TestInputDropdown, _super);
                function TestInputDropdown(root) {
                    _super.call(this, root);
                    this.search = root.element(by.css('cw-input-dropdown INPUT.search'));
                    this.valueInput = root.element(by.css('cw-input-dropdown INPUT[type="hidden"]'));
                    this.valueDisplay = root.element(by.css('cw-input-dropdown DIV.text'));
                    this.menu = root.element(by.css('[class~="menu"]'));
                    this.items = this.menu.all(by.css('[class~="item"]'));
                }
                TestInputDropdown.prototype.setSearch = function (value) {
                    return this.search.sendKeys(value);
                };
                TestInputDropdown.prototype.getValueText = function () {
                    return this.valueDisplay.getText();
                };
                return TestInputDropdown;
            })(TestInputComponent);
            exports_1("TestInputDropdown", TestInputDropdown);
            TestInputToggle = (function (_super) {
                __extends(TestInputToggle, _super);
                function TestInputToggle(root) {
                    _super.call(this, root);
                    this.valueInput = root.element(by.tagName('INPUT'));
                    this.button = root.element(by.css('.ui.toggle'));
                }
                TestInputToggle.prototype.toggle = function () {
                    return this.button.click();
                };
                TestInputToggle.prototype.setValue = function (enabled) {
                    var _this = this;
                    return this.value().then(function (b) {
                        if (b !== enabled) {
                            return _this.toggle();
                        }
                    });
                };
                TestInputToggle.prototype.value = function () {
                    return this.valueInput.getAttribute('value').then(function (v) {
                        return v === 'true';
                    });
                };
                TestInputToggle.prototype.getValueText = function () {
                    return this.valueInput.getText();
                };
                return TestInputToggle;
            })(TestInputComponent);
            exports_1("TestInputToggle", TestInputToggle);
        }
    }
});
//# sourceMappingURL=CwProtractor.js.map