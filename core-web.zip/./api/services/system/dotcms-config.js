System.register(["../core-web-service", "@angular/http", "@angular/core", "rxjs/Rx", "../logger.service"], function(exports_1, context_1) {
    "use strict";
    var __moduleName = context_1 && context_1.id;
    var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
        var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
        if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
        else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
        return c > 3 && r && Object.defineProperty(target, key, r), r;
    };
    var __metadata = (this && this.__metadata) || function (k, v) {
        if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
    };
    var core_web_service_1, http_1, core_1, Rx_1, logger_service_1;
    var DEFAULT_REST_PAGE_COUNT, DOTCMS_WEBSOCKET_RECONNECT_TIME, DOTCMS_WEBSOCKET_ENDPOINTS, WEBSOCKET_SYSTEMEVENTS_ENDPOINT, DOTCMS_WEBSOCKET_BASEURL, DOTCMS_WEBSOCKET_PROTOCOL, DotcmsConfig;
    return {
        setters:[
            function (core_web_service_1_1) {
                core_web_service_1 = core_web_service_1_1;
            },
            function (http_1_1) {
                http_1 = http_1_1;
            },
            function (core_1_1) {
                core_1 = core_1_1;
            },
            function (Rx_1_1) {
                Rx_1 = Rx_1_1;
            },
            function (logger_service_1_1) {
                logger_service_1 = logger_service_1_1;
            }],
        execute: function() {
            /**
             * Created by josecastro on 7/29/16.
             *
             * Wraps the configuration properties for dotCMS in order to provide an
             * easier way to access the information.
             *
             */
            DEFAULT_REST_PAGE_COUNT = 'DEFAULT_REST_PAGE_COUNT';
            DOTCMS_WEBSOCKET_RECONNECT_TIME = 'dotcms.websocket.reconnect.time';
            DOTCMS_WEBSOCKET_ENDPOINTS = 'dotcms.websocket.endpoints';
            WEBSOCKET_SYSTEMEVENTS_ENDPOINT = 'websocket.systemevents.endpoint';
            DOTCMS_WEBSOCKET_BASEURL = 'dotcms.websocket.baseurl';
            DOTCMS_WEBSOCKET_PROTOCOL = 'dotcms.websocket.protocol';
            DotcmsConfig = (function () {
                /**
                 * Initializes this class with the dotCMS core configuration parameters.
                 *
                 * @param configParams - The configuration properties for the current instance.
                 */
                function DotcmsConfig(coreWebService, loggerService) {
                    this.coreWebService = coreWebService;
                    this.loggerService = loggerService;
                    this.waiting = [];
                    this.configUrl = 'v1/appconfiguration';
                    this.loadConfig();
                }
                DotcmsConfig.prototype.getConfig = function () {
                    var _this = this;
                    return Rx_1.Observable.create(function (obs) {
                        if (_this.configParams) {
                            obs.next(_this);
                        }
                        else {
                            _this.waiting.push(obs);
                        }
                    });
                };
                DotcmsConfig.prototype.loadConfig = function () {
                    var _this = this;
                    this.loggerService.debug("Loading configuration on: " + this.configUrl);
                    this.coreWebService.requestView({
                        method: http_1.RequestMethod.Get,
                        url: this.configUrl
                    }).pluck('entity').subscribe(function (res) {
                        _this.loggerService.debug("Configuration Loaded!");
                        _this.configParams = res;
                        _this.waiting.forEach(function (obs) { return obs.next(_this); });
                        _this.waiting = null;
                        return res;
                    });
                };
                /**
                 * Returns the specified protocol for Websocket connections. Defaults to "ws".
                 *
                 * @returns {String} The Websocket protocol.
                 */
                DotcmsConfig.prototype.getWebsocketProtocol = function () {
                    return this.configParams.config[DOTCMS_WEBSOCKET_PROTOCOL];
                };
                /**
                 * Returns the base URL (domain name) used by clients to connect to the server
                 * end-point that will receive and handle connection requests.
                 *
                 * @returns {String} The Websocket base URL.
                 */
                DotcmsConfig.prototype.getWebsocketBaseUrl = function () {
                    return this.configParams.config[DOTCMS_WEBSOCKET_BASEURL];
                };
                /**
                 * Returns the URL to the System Events end-point that clients will use to get
                 * notifications on events created by dotCMS or custom code.
                 *
                 * @returns {String} The System Events end-point URL.
                 */
                DotcmsConfig.prototype.getSystemEventsEndpoint = function () {
                    return this.configParams.config[DOTCMS_WEBSOCKET_ENDPOINTS][WEBSOCKET_SYSTEMEVENTS_ENDPOINT];
                };
                DotcmsConfig.prototype.getTimeToWaitToReconnect = function () {
                    return this.configParams.config[DOTCMS_WEBSOCKET_RECONNECT_TIME];
                };
                /**
                 * Returns the elements that make up the main navigation menu in the back-end. The
                 * items in the menu depend on the roles and permissions of the logged-in user.
                 *
                 * @returns {Array<any>} The menu items and sub-items.
                 */
                DotcmsConfig.prototype.getNavigationMenu = function () {
                    return this.configParams.menu;
                };
                /**
                 * Returns the default rest page count to display.
                 *
                 * @returns <number> The max number of sites to display after a search.
                 */
                DotcmsConfig.prototype.getDefaultRestPageCount = function () {
                    return this.configParams.config[DEFAULT_REST_PAGE_COUNT];
                };
                DotcmsConfig = __decorate([
                    core_1.Injectable(), 
                    __metadata('design:paramtypes', [core_web_service_1.CoreWebService, logger_service_1.LoggerService])
                ], DotcmsConfig);
                return DotcmsConfig;
            }());
            exports_1("DotcmsConfig", DotcmsConfig);
        }
    }
});
//# sourceMappingURL=dotcms-config.js.map