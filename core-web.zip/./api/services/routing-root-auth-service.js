System.register(['@angular/core', './dot-router-service'], function(exports_1, context_1) {
    "use strict";
    var __moduleName = context_1 && context_1.id;
    var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
        var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
        if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
        else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
        return c > 3 && r && Object.defineProperty(target, key, r), r;
    };
    var __metadata = (this && this.__metadata) || function (k, v) {
        if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
    };
    var core_1, dot_router_service_1;
    var RoutingRootAuthService;
    return {
        setters:[
            function (core_1_1) {
                core_1 = core_1_1;
            },
            function (dot_router_service_1_1) {
                dot_router_service_1 = dot_router_service_1_1;
            }],
        execute: function() {
            /**
             * TODO: This service is not used any more. Maybe should be deleted
             */
            RoutingRootAuthService = (function () {
                function RoutingRootAuthService(router) {
                    this.router = router;
                }
                RoutingRootAuthService.prototype.canActivate = function (route, state) {
                    this.router.goToRoot();
                    return true;
                };
                RoutingRootAuthService = __decorate([
                    core_1.Injectable(), 
                    __metadata('design:paramtypes', [dot_router_service_1.DotRouterService])
                ], RoutingRootAuthService);
                return RoutingRootAuthService;
            }());
            exports_1("RoutingRootAuthService", RoutingRootAuthService);
        }
    }
});
//# sourceMappingURL=routing-root-auth-service.js.map