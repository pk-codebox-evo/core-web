System.register(['./system/dotcms-config', '@angular/core', './websockets-service', './logger.service', 'rxjs/Subject'], function(exports_1, context_1) {
    "use strict";
    var __moduleName = context_1 && context_1.id;
    var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
        var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
        if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
        else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
        return c > 3 && r && Object.defineProperty(target, key, r), r;
    };
    var __metadata = (this && this.__metadata) || function (k, v) {
        if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
    };
    var dotcms_config_1, core_1, websockets_service_1, logger_service_1, Subject_1;
    var DotcmsEventsService;
    return {
        setters:[
            function (dotcms_config_1_1) {
                dotcms_config_1 = dotcms_config_1_1;
            },
            function (core_1_1) {
                core_1 = core_1_1;
            },
            function (websockets_service_1_1) {
                websockets_service_1 = websockets_service_1_1;
            },
            function (logger_service_1_1) {
                logger_service_1 = logger_service_1_1;
            },
            function (Subject_1_1) {
                Subject_1 = Subject_1_1;
            }],
        execute: function() {
            DotcmsEventsService = (function () {
                /**
                 * Initializes this service with the configuration properties that are
                 * necessary for opening the Websocket with the System Events end-point.
                 *
                 * @param dotcmsConfig - The dotCMS configuration properties that include
                 *                        the Websocket parameters.
                 */
                function DotcmsEventsService(dotcmsConfig, loggerService) {
                    var _this = this;
                    this.dotcmsConfig = dotcmsConfig;
                    this.loggerService = loggerService;
                    this.closedOnLogout = false;
                    this.subjects = [];
                    this.dotcmsConfig.getConfig().subscribe(function (dotcmsConfig) {
                        _this.protocol = dotcmsConfig.getWebsocketProtocol();
                        _this.baseUrl = dotcmsConfig.getWebsocketBaseUrl();
                        _this.endPoint = dotcmsConfig.getSystemEventsEndpoint();
                        _this.timeWaitToReconnect = dotcmsConfig.getTimeToWaitToReconnect();
                    });
                }
                /**
                 * Close the socket
                 */
                DotcmsEventsService.prototype.close = function () {
                    // On logout, meaning no authenticated user lets try to close the socket
                    if (this.ws) {
                        /*
                         We need to turn on this closedOnLogout flag in order to avoid reconnections as we explicitly
                         closed the socket
                         */
                        this.closedOnLogout = true;
                        this.ws.close(true);
                    }
                };
                /**
                 * Opens the Websocket connection with the System Events end-point.
                 */
                DotcmsEventsService.prototype.connectWithSocket = function () {
                    var _this = this;
                    if (!this.ws && this.protocol && this.baseUrl && this.endPoint) {
                        this.loggerService.debug('Creating a new Web Socket connection', this.protocol, this.baseUrl, this.endPoint);
                        this.ws = new websockets_service_1.$WebSocket(this.protocol + "://" + this.baseUrl + this.endPoint);
                        this.ws.connect();
                        this.ws.onClose(function () {
                            if (_this.closedOnLogout) {
                                // If we closed the socket for a logout we need to reset the closedOnLogout flag
                                _this.closedOnLogout = false;
                                _this.ws = null; // Cleaning up the socket as we explicitly closed the socket
                            }
                            else {
                                setTimeout(_this.reconnect.bind(_this), _this.timeWaitToReconnect);
                            }
                        });
                        this.ws.getDataStream().subscribe(function (res) {
                            var data = (JSON.parse(res.data));
                            if (!_this.subjects[data.event]) {
                                _this.subjects[data.event] = new Subject_1.Subject();
                            }
                            _this.subjects[data.event].next(data.payload);
                        }, function (e) {
                            this.loggerService.debug('Error in the System Events service: ' + e.message);
                        }, function () {
                            this.loggerService.debug('Completed');
                        });
                    }
                };
                /**
                 * This method will be called by clients that want to receive notifications
                 * regarding incoming system events. The events they will receive will be
                 * based on the type of event clients register for.
                 *
                 * @param clientEventType - The type of event clients will get. For example,
                 *                          "notification" will allow a client to receive the
                 *                          messages in the Notification section.
                 * @returns {any} The system events that a client will receive.
                 */
                DotcmsEventsService.prototype.subscribeTo = function (clientEventType) {
                    if (!this.subjects[clientEventType]) {
                        this.subjects[clientEventType] = new Subject_1.Subject();
                    }
                    return this.subjects[clientEventType].asObservable();
                };
                DotcmsEventsService.prototype.subscribeToEvents = function (clientEventTypes) {
                    var _this = this;
                    var subject = new Subject_1.Subject();
                    clientEventTypes.forEach(function (eventType) { return _this.subscribeTo(eventType).subscribe(function (data) { return subject.next({
                        data: data,
                        eventType: eventType
                    }); }); });
                    return subject.asObservable();
                };
                DotcmsEventsService.prototype.reconnect = function () {
                    this.ws = null;
                    this.connectWithSocket();
                };
                DotcmsEventsService = __decorate([
                    core_1.Injectable(), 
                    __metadata('design:paramtypes', [dotcms_config_1.DotcmsConfig, logger_service_1.LoggerService])
                ], DotcmsEventsService);
                return DotcmsEventsService;
            }());
            exports_1("DotcmsEventsService", DotcmsEventsService);
        }
    }
});
//# sourceMappingURL=dotcms-events-service.js.map