System.register(['angular2/core', '../../api/persistence/DataStore', "../../api/persistence/LocalDataStore"], function(exports_1) {
    var core_1, DataStore_1, LocalDataStore_1;
    var injector;
    return {
        setters:[
            function (core_1_1) {
                core_1 = core_1_1;
            },
            function (DataStore_1_1) {
                DataStore_1 = DataStore_1_1;
            },
            function (LocalDataStore_1_1) {
                LocalDataStore_1 = LocalDataStore_1_1;
            }],
        execute: function() {
            injector = core_1.Injector.resolveAndCreate([
                new core_1.Provider(DataStore_1.DataStore, { useClass: LocalDataStore_1.LocalDataStore })
            ]);
            describe('Unit.api.persistence.LocalDataStore', function () {
                var store;
                beforeEach(function () {
                    store = injector.get(DataStore_1.DataStore);
                });
                it("A store is injected.", function () {
                    expect(store).not.toBeNull();
                });
                it("should throw error if a path doesn't start with start with 'http'", function () {
                    expect(function () {
                        var data = {
                            a: 100,
                            b: "Hello"
                        };
                        var path = "some/path";
                        store.setItem(path, data);
                    }).toThrowError(/Path must be a valid URL/);
                });
                it("should save json object to a given url", function () {
                    var data = {
                        a: 100,
                        b: "Hello"
                    };
                    var path = "http://foo.com/some/path";
                    store.setItem(path, data);
                    var result = store.getItem(path);
                    expect(result).not.toBeNull();
                    expect(result.a).toEqual(100);
                    expect(result.b).toEqual(data.b);
                });
            });
        }
    }
});
//# sourceMappingURL=LocalDataStore.spec.js.map