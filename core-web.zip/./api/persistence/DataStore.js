System.register(['angular2/core', '../validation/Check'], function(exports_1) {
    var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
        var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
        if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
        else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
        return c > 3 && r && Object.defineProperty(target, key, r), r;
    };
    var __metadata = (this && this.__metadata) || function (k, v) {
        if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
    };
    var core_1, Check_1;
    var DataStore;
    return {
        setters:[
            function (core_1_1) {
                core_1 = core_1_1;
            },
            function (Check_1_1) {
                Check_1 = Check_1_1;
            }],
        execute: function() {
            DataStore = (function () {
                function DataStore() {
                }
                Object.defineProperty(DataStore.prototype, "length", {
                    get: function () {
                        return 0;
                    },
                    enumerable: true,
                    configurable: true
                });
                DataStore.prototype.checkPath = function (path) {
                    Check_1.Check.notEmpty(path, "Path cannot be blank.");
                    Check_1.Check.isString(path, "Path must be a string.");
                    if (!path.startsWith("http")) {
                        throw new Error("Path must be a valid URL");
                    }
                    return path;
                };
                DataStore.prototype.path = function (idx) { };
                DataStore.prototype.clear = function () { };
                DataStore.prototype.setItem = function (path, value, isNew) {
                    if (isNew === void 0) { isNew = false; }
                };
                DataStore.prototype.getItem = function (path) { };
                DataStore.prototype.getItems = function () {
                    var paths = [];
                    for (var _i = 0; _i < arguments.length; _i++) {
                        paths[_i - 0] = arguments[_i];
                    }
                    return [];
                };
                DataStore.prototype.hasItem = function (path) { return false; };
                DataStore.prototype.removeItem = function (path) { };
                DataStore.prototype.childPaths = function (path) { return []; };
                DataStore.prototype.childKeys = function (path) { return []; };
                DataStore.prototype.childItems = function (path) { };
                DataStore.prototype.setAuth = function (x, y) {
                    if (x === void 0) { x = null; }
                    if (y === void 0) { y = null; }
                };
                DataStore = __decorate([
                    core_1.Injectable(), 
                    __metadata('design:paramtypes', [])
                ], DataStore);
                return DataStore;
            })();
            exports_1("DataStore", DataStore);
        }
    }
});
//# sourceMappingURL=DataStore.js.map