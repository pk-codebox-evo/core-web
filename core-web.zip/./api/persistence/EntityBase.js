System.register(["./ApiRoot"], function(exports_1) {
    var ApiRoot_1;
    var pushSetEmptyFn, emptyFn, Dispatcher, EntitySnapshot, EntityMeta;
    return {
        setters:[
            function (ApiRoot_1_1) {
                ApiRoot_1 = ApiRoot_1_1;
            }],
        execute: function() {
            pushSetEmptyFn = function (a, b) {
                if (a === void 0) { a = null; }
                if (b === void 0) { b = null; }
            };
            emptyFn = function (a) {
                if (a === void 0) { a = null; }
            };
            Dispatcher = {
                queries: new Set(),
                paths: new Set(),
                register: function (meta) {
                    this.queries.add(meta);
                },
                deregister: function (meta) {
                    this.queries.delete(meta);
                },
                snapshotCreated: function (snap) {
                    var url = snap.ref().toString();
                    if (!this.paths.has(url)) {
                        this.notify(url, "added", snap);
                        this.paths.add(url);
                    }
                },
                notify: function (path, eventType, payload) {
                    if (payload === void 0) { payload = null; }
                    this.queries.forEach(function (query) {
                        query.notify(path, eventType, payload);
                    });
                }
            };
            EntitySnapshot = (function () {
                function EntitySnapshot(path, entity) {
                    if (entity === void 0) { entity = null; }
                    if (!path.startsWith('http')) {
                    }
                    this._path = path;
                    this._entity = entity; // @todo ggranum: this should be cloned
                    Dispatcher.snapshotCreated(this);
                }
                EntitySnapshot.prototype.val = function () {
                    return this._entity;
                };
                EntitySnapshot.prototype.key = function () {
                    if (!this._key) {
                        var idx = this._path.lastIndexOf('/');
                        this._key = idx < 0 ? this._path : this._path.substring(idx + 1, this._path.length);
                    }
                    return this._key;
                };
                EntitySnapshot.prototype.ref = function () {
                    if (!this._meta) {
                        this._meta = new EntityMeta(this._path);
                    }
                    return this._meta;
                };
                EntitySnapshot.prototype.exists = function () {
                    return this._entity != null;
                };
                EntitySnapshot.prototype.child = function (key) {
                    key = key.startsWith('/') ? key.substring(1) : key;
                    var childPath;
                    if (!this._path.endsWith('/')) {
                        childPath = this._path + '/' + key;
                    }
                    else {
                        childPath = this._path + key;
                    }
                    var childVal = null;
                    if (this.exists() && this._entity.hasOwnProperty(key)) {
                        childVal = this._entity[key];
                    }
                    return new EntitySnapshot(childPath, childVal);
                };
                EntitySnapshot.prototype.forEach = function (childAction) {
                    var _this = this;
                    if (this._entity) {
                        Object.keys(this._entity).every(function (key) {
                            var snap = _this.child(key);
                            return childAction(snap) !== true; // break if 'true' returned by callback.
                        });
                    }
                };
                return EntitySnapshot;
            })();
            exports_1("EntitySnapshot", EntitySnapshot);
            EntityMeta = (function () {
                function EntityMeta(url) {
                    if (!url.startsWith('http')) {
                    }
                    this.path = url;
                    this.pathTokens = url ? url.split("/") : [];
                    this.latestSnapshot = null;
                    var idx = this.path.lastIndexOf('/');
                    this.$key = idx < 0 ? this.path : this.path.substring(idx + 1, this.path.length);
                    this.watches = {
                        value: new Set(),
                        child_added: new Set(),
                        child_removed: new Set(),
                        child_changed: new Set()
                    };
                    Dispatcher.register(this);
                }
                EntityMeta.prototype.toString = function () {
                    return this.path;
                };
                EntityMeta.prototype.child = function (key) {
                    key = key.startsWith('/') ? key.substring(1) : key;
                    var childPath;
                    if (!this.path.endsWith('/')) {
                        childPath = this.path + '/' + key;
                    }
                    else {
                        childPath = this.path + key;
                    }
                    return new EntityMeta(childPath);
                };
                EntityMeta.prototype.key = function () {
                    return this.$key;
                };
                /**
                 * Replace the existing entry at this location with the provided data.
                 * If 'data' is null this operation is effectively a remove.
                 * The provided data object will be serialized using JSON.stringify.
                 * @param data A literal, such as a string or number, or an object map with children of its own.
                 * @param onComplete
                 * @returns {*}
                 */
                EntityMeta.prototype.set = function (data, onComplete) {
                    var _this = this;
                    if (onComplete === void 0) { onComplete = pushSetEmptyFn; }
                    if (data === null) {
                        return this.remove(onComplete);
                    }
                    var prom = ApiRoot_1.ApiRoot.instance().dataStore.setItem(this.path, data);
                    prom.then(function (response) {
                        Dispatcher.notify(_this.path, "change", new EntitySnapshot(_this.toString(), data));
                        if (response.isError) {
                            throw response.error;
                        }
                        onComplete(null, response);
                    }).catch(function (e) { return onComplete(e); });
                    return prom;
                };
                /**
                 * Intended to do a merge, for now it just delegates to '#set'
                 * @param data
                 * @param onComplete
                 * @returns {*}
                 */
                EntityMeta.prototype.update = function (data, onComplete) {
                    if (onComplete === void 0) { onComplete = pushSetEmptyFn; }
                    return this.set(data, onComplete);
                };
                EntityMeta.prototype.remove = function (onComplete) {
                    var _this = this;
                    if (onComplete === void 0) { onComplete = pushSetEmptyFn; }
                    var prom = ApiRoot_1.ApiRoot.instance().dataStore.removeItem(this.path);
                    prom.then(function (response) {
                        if (response.isError) {
                            throw response.error;
                        }
                        Dispatcher.notify(_this.path, 'removed', _this.latestSnapshot);
                        onComplete(null, response);
                    }).catch(function (e) { return onComplete(e); });
                    return prom;
                };
                EntityMeta.prototype.push = function (data, onComplete) {
                    if (onComplete === void 0) { onComplete = pushSetEmptyFn; }
                    return ApiRoot_1.ApiRoot.instance().dataStore.setItem(this.path, data, true)
                        .then(function (result) {
                        if (result.isError) {
                            onComplete(result.error, result);
                        }
                        else {
                            console.log("Push succeeded, creating snapshot", data);
                            var snap = new EntitySnapshot(result.path, data);
                            var childMeta = new EntityMeta(result.path);
                            childMeta.latestSnapshot = snap;
                            onComplete(null, snap);
                            return snap;
                        }
                    }).catch(function (e) {
                        console.log('Error creating snapshot', e);
                        onComplete(e);
                    });
                };
                EntityMeta.prototype._sync = function () {
                    var _this = this;
                    ApiRoot_1.ApiRoot.instance().dataStore.getItem(this.path).then(function (responseEntity) {
                        var snap = new EntitySnapshot(_this.toString(), responseEntity);
                        Dispatcher.notify(_this.path, 'changed', snap);
                        return snap;
                    }).catch(function (e) {
                        console.log(e);
                        throw e;
                    });
                };
                EntityMeta.prototype.once = function (eventType, callback, failureCallback) {
                    var _this = this;
                    if (callback === void 0) { callback = emptyFn; }
                    if (failureCallback === void 0) { failureCallback = emptyFn; }
                    var tempCB = function (snap) {
                        _this.off(eventType, tempCB);
                        callback(snap);
                    };
                    this.on(eventType, tempCB, function (e) {
                        _this.off(eventType, tempCB);
                        failureCallback(e);
                    });
                };
                EntityMeta.prototype.off = function (eventType, callback) {
                    if (callback === void 0) { callback = null; }
                    if (callback === null) {
                        this.watches[eventType].clear();
                    }
                    else {
                        this.watches[eventType].delete(callback);
                    }
                };
                EntityMeta.prototype.on = function (eventType, callback, failureCallback) {
                    if (failureCallback === void 0) { failureCallback = pushSetEmptyFn; }
                    switch (eventType) {
                        case 'value':
                            return this.onValue(callback);
                        case 'child_added':
                            return this.onChildAdded(callback);
                        case 'child_changed':
                            return this.onChildChanged(callback);
                        case 'child_moved':
                            return this.onChildMoved(callback);
                        case 'child_removed':
                            return this.onChildRemoved(callback);
                        default:
                            {
                                var e = new Error("Invalid event name: '" + eventType + "'.");
                                console.log(e);
                                throw e;
                            }
                    }
                };
                EntityMeta.prototype.onValue = function (callback) {
                    this.watches.value.add(callback);
                    this._sync();
                    return callback;
                };
                EntityMeta.prototype.onChildAdded = function (callback) {
                    this.watches.child_added.add(callback);
                };
                EntityMeta.prototype.onChildRemoved = function (callback) {
                    this.watches.child_removed.add(callback);
                };
                EntityMeta.prototype.onChildChanged = function (callback) {
                    this.watches.child_changed.add(callback);
                };
                EntityMeta.prototype.onChildMoved = function (callback) {
                };
                EntityMeta.prototype.notify = function (path, eventType, payload) {
                    try {
                        var isSelf = this.path.length == path.length && this.path == path;
                        // this. path = /foo/abc/
                        //  --   path = /foo/abc/123
                        var isDescendant = !isSelf && path.startsWith(this.path);
                        var isAncestor = !isSelf && !isDescendant && this.path.startsWith(path);
                        if (isSelf) {
                            switch (eventType) {
                                case 'added':
                                case 'changed':
                                    this.latestSnapshot = payload;
                                    this.watches.value.forEach(function (cb) {
                                        cb(payload);
                                    });
                                    break;
                                default:
                            }
                        }
                        else if (isDescendant) {
                            var isChild = path.split("/").length === (this.pathTokens.length + 1);
                            if (isChild) {
                                switch (eventType) {
                                    case 'changed':
                                        this.watches.child_changed.forEach(function (cb) {
                                            cb(payload);
                                        });
                                        break;
                                    case 'added':
                                        this.watches.child_added.forEach(function (cb) {
                                            cb(payload);
                                        });
                                        break;
                                    case 'removed':
                                        this.watches.child_removed.forEach(function (cb) {
                                            cb(payload);
                                        });
                                        break;
                                    case 'moved':
                                        console.log('moved');
                                        break;
                                }
                            }
                        }
                    }
                    catch (e) {
                        console.log("Notification error: ", e);
                    }
                };
                return EntityMeta;
            })();
            exports_1("EntityMeta", EntityMeta);
        }
    }
});
//# sourceMappingURL=EntityBase.js.map