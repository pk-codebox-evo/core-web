System.register(['../../api/validation/Verify', '../../api/persistence/DataStore'], function(exports_1) {
    var __extends = (this && this.__extends) || function (d, b) {
        for (var p in b) if (b.hasOwnProperty(p)) d[p] = b[p];
        function __() { this.constructor = d; }
        d.prototype = b === null ? Object.create(b) : (__.prototype = b.prototype, new __());
    };
    var Verify_1, DataStore_1;
    var LocalDataStore;
    return {
        setters:[
            function (Verify_1_1) {
                Verify_1 = Verify_1_1;
            },
            function (DataStore_1_1) {
                DataStore_1 = DataStore_1_1;
            }],
        execute: function() {
            LocalDataStore = (function (_super) {
                __extends(LocalDataStore, _super);
                function LocalDataStore() {
                    _super.call(this);
                }
                Object.defineProperty(LocalDataStore.prototype, "length", {
                    get: function () {
                        return localStorage.length;
                    },
                    enumerable: true,
                    configurable: true
                });
                LocalDataStore.prototype.key = function (idx) {
                    return localStorage.key(idx);
                };
                LocalDataStore.prototype.clear = function () {
                    localStorage.clear();
                };
                LocalDataStore.prototype.setItem = function (path, value) {
                    path = this.checkPath(path);
                    if (Verify_1.Verify.exists(value)) {
                        localStorage.setItem(path, JSON.stringify(value));
                    }
                    else {
                        this.removeItem(path);
                    }
                };
                LocalDataStore.prototype.getItem = function (path) {
                    var item = localStorage.getItem(path);
                    item = item === null ? null : JSON.parse(item);
                    return item;
                };
                LocalDataStore.prototype.getItems = function () {
                    var _this = this;
                    var paths = [];
                    for (var _i = 0; _i < arguments.length; _i++) {
                        paths[_i - 0] = arguments[_i];
                    }
                    return paths.map(function (path) {
                        return _this.getItem(path);
                    });
                };
                LocalDataStore.prototype.hasItem = function (path) {
                    return localStorage.getItem(path) !== null;
                };
                LocalDataStore.prototype.removeItem = function (path) {
                    var itemJson = localStorage.getItem(path);
                    var item = null;
                    if (itemJson !== null) {
                        item = JSON.parse(item);
                    }
                    localStorage.removeItem(path);
                    return item;
                };
                LocalDataStore.prototype.childKeys = function (path) {
                    var pathLen = path.length;
                    return this.childPaths(path).map(function (childPath) {
                        return childPath.substring(pathLen);
                    });
                };
                LocalDataStore.prototype.childPaths = function (path) {
                    var childPaths = [];
                    for (var i = 0; i < localStorage.length; i++) {
                        var childPath = localStorage.key(i);
                        if (childPath.startsWith(path)) {
                            childPaths.push(childPath);
                        }
                    }
                    return childPaths;
                };
                LocalDataStore.prototype.childItems = function (path) {
                    var _this = this;
                    var pathLen = path.length;
                    return this.childPaths(path).map(function (childPath) {
                        return { path: childPath, key: childPath.substring(pathLen), val: _this.getItem(childPath) };
                    });
                };
                return LocalDataStore;
            })(DataStore_1.DataStore);
            exports_1("LocalDataStore", LocalDataStore);
        }
    }
});
//# sourceMappingURL=LocalDataStore.js.map