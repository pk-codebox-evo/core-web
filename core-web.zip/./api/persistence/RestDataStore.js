System.register(['../../api/validation/Check', "../../api/persistence/DataStore", 'whatwg-fetch'], function(exports_1) {
    var __extends = (this && this.__extends) || function (d, b) {
        for (var p in b) if (b.hasOwnProperty(p)) d[p] = b[p];
        function __() { this.constructor = d; }
        d.prototype = b === null ? Object.create(b) : (__.prototype = b.prototype, new __());
    };
    var Check_1, DataStore_1;
    var fetch, RestDataStore;
    return {
        setters:[
            function (Check_1_1) {
                Check_1 = Check_1_1;
            },
            function (DataStore_1_1) {
                DataStore_1 = DataStore_1_1;
            },
            function (_1) {}],
        execute: function() {
            fetch = window ? window['fetch'] : top['fetch'];
            RestDataStore = (function (_super) {
                __extends(RestDataStore, _super);
                function RestDataStore() {
                    _super.call(this);
                    console.log("Creating datastore");
                }
                RestDataStore.prototype.setItem = function (path, entity, isNew) {
                    if (isNew === void 0) { isNew = false; }
                    path = this.checkPath(path);
                    entity = Check_1.Check.exists(entity, "Cannot save empty values. Did you mean to remove?");
                    return this.remoteSet(path, entity, isNew).then(function (response) {
                        if (response.isError) {
                            response.entity = entity; // restore the original, entity
                        }
                        else if (isNew === true) {
                            path = path + '/' + response.entity.id;
                        }
                        else {
                            path = path.substring(0, path.lastIndexOf('/') + 1) + response.entity.id;
                        }
                        response['path'] = path;
                        return response;
                    });
                };
                RestDataStore.prototype.getItem = function (path) {
                    var _this = this;
                    return new Promise(function (resolve, reject) {
                        _this.remoteGet(path).then(function (response) {
                            resolve(response.entity);
                        }).catch(function (err) {
                            reject(err);
                        });
                    });
                };
                RestDataStore.prototype.removeItem = function (path) {
                    return this.remoteDelete(path);
                };
                RestDataStore.prototype.remoteGet = function (path) {
                    var url = this.pathToUrl(path);
                    console.log("Getting entity from: ", url);
                    return fetch(url, {
                        credentials: 'same-origin',
                        headers: {
                            'Accept': 'application/json',
                            'Content-Type': 'application/json',
                            'Authorization': this.authHeader
                        }
                    }).catch(this.checkStatus).then(this.checkStatus).then(this.transformResponse);
                };
                RestDataStore.prototype.remoteDelete = function (path) {
                    var url = this.pathToUrl(path);
                    console.log("Deleting entity at: ", url);
                    return fetch(url, {
                        method: "delete",
                        credentials: 'same-origin',
                        headers: {
                            'Accept': 'application/json',
                            'Content-Type': 'application/json',
                            'Authorization': this.authHeader
                        }
                    }).then(this.checkStatus).then(this.transformResponse).catch(function (e) {
                        console.log("Delete operation resulted in an error: ", e);
                    });
                };
                RestDataStore.prototype.transformResponse = function (response) {
                    var result = {
                        path: null,
                        key: null,
                        status: response.status || {},
                        headers: response.headers || {},
                        entity: {},
                        isError: false
                    };
                    var path = response.url;
                    result.path = path.substring(path.indexOf('/', 8)); // http://foo.com/thisIsThePathWeMean
                    result.key = path.substring(path.lastIndexOf('/') + 1);
                    var contentType = response.headers.get('Content-Type');
                    if (response.hasError === true) {
                        result.isError = true;
                        result.error = response.error;
                    }
                    else if (contentType && contentType.toLowerCase().includes('json')) {
                        return response.json().then(function (json) {
                            if (json) {
                                result.entity = json;
                            }
                            return result;
                        }).catch(function (e) {
                            console.log('Error parsing response:', e);
                            throw e;
                        });
                    }
                    return new Promise(function (resolve) { return resolve(result); });
                };
                RestDataStore.prototype.checkStatus = function (response) {
                    var error;
                    if (response instanceof TypeError) {
                        var message = response.message;
                        if (response.message == "Failed to fetch") {
                            message = response.message + ' (is the host available?)';
                        }
                        error = new Error(message);
                        error.response = {
                            status: -1
                        };
                    }
                    else if (!(response.status >= 200 && response.status < 300)) {
                        error = new Error(response.statusText);
                        error.response = response;
                    }
                    if (error) {
                        console.log("Status error: ", error);
                        response.error = error;
                        response.hasError = true;
                    }
                    return response;
                };
                RestDataStore.prototype.pathToUrl = function (path) {
                    if (!path.startsWith('http')) {
                        throw new Error("Path must be fully qualified URL.");
                    }
                    if (path.endsWith('/')) {
                        path = path.substring(0, path.length - 1);
                    }
                    return path;
                };
                RestDataStore.prototype.setAuth = function (username, password) {
                    if (username && password) {
                        this.authHeader = 'Basic ' + btoa(username + ':' + password);
                    }
                };
                RestDataStore.prototype.remoteSet = function (path, entity, create) {
                    if (create === void 0) { create = false; }
                    var url = this.pathToUrl(path);
                    console.log("Saving entity to: ", url, entity);
                    var headers = {
                        'Accept': 'application/json',
                        'Content-Type': 'application/json'
                    };
                    if (this.authHeader) {
                        headers.Authorization = this.authHeader;
                    }
                    return fetch(url, {
                        method: create ? "post" : "put",
                        credentials: 'same-origin',
                        headers: headers,
                        body: JSON.stringify(entity)
                    }).then(this.checkStatus)
                        .then(this.transformResponse)
                        .then(function (result) {
                        return result;
                    })
                        .catch(function (e) {
                        console.log("Save operation resulted in an error: ", e);
                        throw e;
                    });
                };
                return RestDataStore;
            })(DataStore_1.DataStore);
            exports_1("RestDataStore", RestDataStore);
        }
    }
});
//# sourceMappingURL=RestDataStore.js.map