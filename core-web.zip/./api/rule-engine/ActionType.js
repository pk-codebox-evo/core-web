System.register(['angular2/core', 'rxjs/Rx', "../persistence/ApiRoot", "../system/locale/I18n", "./ServerSideFieldModel"], function(exports_1) {
    var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
        var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
        if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
        else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
        return c > 3 && r && Object.defineProperty(target, key, r), r;
    };
    var __metadata = (this && this.__metadata) || function (k, v) {
        if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
    };
    var core_1, Rx_1, ApiRoot_1, I18n_1, ServerSideFieldModel_1;
    var noop, ActionTypeService;
    return {
        setters:[
            function (core_1_1) {
                core_1 = core_1_1;
            },
            function (Rx_1_1) {
                Rx_1 = Rx_1_1;
            },
            function (ApiRoot_1_1) {
                ApiRoot_1 = ApiRoot_1_1;
            },
            function (I18n_1_1) {
                I18n_1 = I18n_1_1;
            },
            function (ServerSideFieldModel_1_1) {
                ServerSideFieldModel_1 = ServerSideFieldModel_1_1;
            }],
        execute: function() {
            noop = function () {
                var arg = [];
                for (var _i = 0; _i < arguments.length; _i++) {
                    arg[_i - 0] = arguments[_i];
                }
            };
            ActionTypeService = (function () {
                function ActionTypeService(apiRoot, rsrcService) {
                    this._ref = apiRoot.root.child('system/ruleengine/actionlets');
                    this._apiRoot = apiRoot;
                    this._rsrcService = rsrcService;
                    this._cacheMap = {};
                }
                ActionTypeService.prototype.list = function (cb) {
                    var _this = this;
                    if (cb === void 0) { cb = noop; }
                    return Rx_1.Observable.defer(function () { return _this._list(cb); });
                };
                ActionTypeService.prototype._list = function (cb) {
                    var _this = this;
                    if (cb === void 0) { cb = noop; }
                    var ee;
                    var cachedKeys = Object.keys(this._cacheMap);
                    if (cachedKeys.length > 0) {
                        ee = this._listFromCache(cachedKeys);
                    }
                    else {
                        ee = new core_1.EventEmitter();
                        this._ref.once('value', function (snap) {
                            var types = snap.val();
                            var hydratedTypes = [];
                            var keys = Object.keys(types);
                            var count = 0;
                            keys.forEach(function (key) {
                                var json = snap.child(key).val();
                                json.key = key;
                                var model = ServerSideFieldModel_1.ServerSideTypeModel.fromJson(json);
                                _this._cacheMap[model.key] = model;
                                hydratedTypes.push(model);
                            });
                            ee.emit(hydratedTypes);
                            cb(hydratedTypes);
                        }, function (e) {
                            throw e;
                        });
                    }
                    return ee;
                };
                ActionTypeService.prototype._listFromCache = function (cachedKeys) {
                    var _this = this;
                    var types = [];
                    cachedKeys.forEach(function (key) { return types.push(_this._cacheMap[key]); });
                    return Rx_1.Observable.of(types);
                };
                ;
                ActionTypeService.prototype.get = function (key, cb) {
                    var _this = this;
                    if (cb === void 0) { cb = noop; }
                    var cachedValue = this._cacheMap[key];
                    if (cachedValue) {
                        cb(cachedValue);
                    }
                    else {
                        /* There is no direct endpoint to get actions by key. So we'll hydrate all of them  */
                        var sub = this.list().subscribe(function () {
                            cb(_this._cacheMap[key]);
                            sub.unsubscribe();
                        });
                    }
                };
                ActionTypeService = __decorate([
                    core_1.Injectable(), 
                    __metadata('design:paramtypes', [ApiRoot_1.ApiRoot, I18n_1.I18nService])
                ], ActionTypeService);
                return ActionTypeService;
            })();
            exports_1("ActionTypeService", ActionTypeService);
        }
    }
});
//# sourceMappingURL=ActionType.js.map