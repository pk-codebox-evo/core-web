System.register(['angular2/core', '../../api/persistence/DataStore', '../../api/persistence/RestDataStore', '../../api/persistence/ApiRoot', '../../api/auth/UserModel', '../../api/rule-engine/ConditionType', "../system/locale/I18n"], function(exports_1) {
    var core_1, DataStore_1, RestDataStore_1, ApiRoot_1, UserModel_1, ConditionType_1, I18n_1;
    var injector;
    return {
        setters:[
            function (core_1_1) {
                core_1 = core_1_1;
            },
            function (DataStore_1_1) {
                DataStore_1 = DataStore_1_1;
            },
            function (RestDataStore_1_1) {
                RestDataStore_1 = RestDataStore_1_1;
            },
            function (ApiRoot_1_1) {
                ApiRoot_1 = ApiRoot_1_1;
            },
            function (UserModel_1_1) {
                UserModel_1 = UserModel_1_1;
            },
            function (ConditionType_1_1) {
                ConditionType_1 = ConditionType_1_1;
            },
            function (I18n_1_1) {
                I18n_1 = I18n_1_1;
            }],
        execute: function() {
            injector = core_1.Injector.resolveAndCreate([
                ApiRoot_1.ApiRoot,
                I18n_1.I18nService,
                UserModel_1.UserModel,
                ConditionType_1.ConditionTypeService,
                new core_1.Provider(DataStore_1.DataStore, { useClass: RestDataStore_1.RestDataStore })
            ]);
            describe('Integration.api.rule-engine.RuleService', function () {
                var typeService;
                var subscriptions;
                beforeEach(function () {
                    subscriptions = [];
                    typeService = injector.get(ConditionType_1.ConditionTypeService);
                });
                afterEach(function () {
                    subscriptions.forEach(function (sub) {
                        sub.unsubscribe();
                    });
                });
                it("Can list condition types, and they are all persisted and valid.", function (done) {
                    var count = 0;
                    var subscription = typeService.list().subscribe(function (conditionType) {
                        count++;
                    }, function (err) {
                        expect(err).toBeUndefined("error was thrown creating Rule.");
                        done();
                    });
                    subscriptions.push(subscription); // for cleanup.
                    typeService.list(function (types) {
                        expect(count).toEqual(types.length, "onAdd subscriber notification count should be same as number of types provided to callback.");
                        types.forEach(function (type) {
                            expect(type.isPersisted()).toBe(true, "Condition types are readonly and should always be persisted.");
                            expect(type.isValid()).toBe(true, "Condition types are readonly and should always be valid.");
                        });
                        done();
                    });
                });
                it("There are three active condition types.", function (done) {
                    typeService.list(function (types) {
                        expect(types.length).toEqual(3, "We have only enabled three condition types. Please update name of test when you update this expectation.");
                        done();
                    });
                });
            });
        }
    }
});
//# sourceMappingURL=ConditionType.it-spec.js.map