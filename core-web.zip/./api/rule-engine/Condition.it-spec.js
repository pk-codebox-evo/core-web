System.register(['../../api/rule-engine/Rule', '../../api/rule-engine/Condition', 'angular2/core', '../../api/persistence/DataStore', '../../api/persistence/RestDataStore', '../../api/persistence/ApiRoot', '../../api/auth/UserModel', '../../api/rule-engine/ConditionType', '../../api/rule-engine/Action', '../../api/rule-engine/ConditionGroup', "./ActionType", "../system/locale/I18n", "./ServerSideFieldModel"], function(exports_1) {
    var Rule_1, Condition_1, core_1, DataStore_1, RestDataStore_1, ApiRoot_1, UserModel_1, ConditionType_1, Action_1, ConditionGroup_1, ActionType_1, I18n_1, ServerSideFieldModel_1;
    var injector, Tools;
    return {
        setters:[
            function (Rule_1_1) {
                Rule_1 = Rule_1_1;
            },
            function (Condition_1_1) {
                Condition_1 = Condition_1_1;
            },
            function (core_1_1) {
                core_1 = core_1_1;
            },
            function (DataStore_1_1) {
                DataStore_1 = DataStore_1_1;
            },
            function (RestDataStore_1_1) {
                RestDataStore_1 = RestDataStore_1_1;
            },
            function (ApiRoot_1_1) {
                ApiRoot_1 = ApiRoot_1_1;
            },
            function (UserModel_1_1) {
                UserModel_1 = UserModel_1_1;
            },
            function (ConditionType_1_1) {
                ConditionType_1 = ConditionType_1_1;
            },
            function (Action_1_1) {
                Action_1 = Action_1_1;
            },
            function (ConditionGroup_1_1) {
                ConditionGroup_1 = ConditionGroup_1_1;
            },
            function (ActionType_1_1) {
                ActionType_1 = ActionType_1_1;
            },
            function (I18n_1_1) {
                I18n_1 = I18n_1_1;
            },
            function (ServerSideFieldModel_1_1) {
                ServerSideFieldModel_1 = ServerSideFieldModel_1_1;
            }],
        execute: function() {
            injector = core_1.Injector.resolveAndCreate([ApiRoot_1.ApiRoot,
                I18n_1.I18nService,
                UserModel_1.UserModel,
                Rule_1.RuleService,
                Action_1.ActionService,
                ActionType_1.ActionTypeService,
                ConditionType_1.ConditionTypeService,
                Condition_1.ConditionService,
                ConditionGroup_1.ConditionGroupService,
                new core_1.Provider(DataStore_1.DataStore, { useClass: RestDataStore_1.RestDataStore })
            ]);
            describe('Integration.api.rule-engine.ConditionService', function () {
                var ruleService;
                var ruleOnAddSub;
                var conditionGroupService;
                var conditionService;
                var ruleUnderTest;
                var groupUnderTest;
                beforeEach(function (done) {
                    ruleUnderTest = null;
                    groupUnderTest = null;
                    ruleService = injector.get(Rule_1.RuleService);
                    conditionGroupService = injector.get(ConditionGroup_1.ConditionGroupService);
                    conditionService = injector.get(Condition_1.ConditionService);
                    Tools.createRule(ruleService, function (rule) {
                        if (!ruleUnderTest) {
                            ruleUnderTest = rule;
                            groupUnderTest = new ConditionGroup_1.ConditionGroupModel(null, ruleUnderTest, "OR", 1);
                            conditionGroupService.add(groupUnderTest, done);
                        }
                    });
                });
                afterEach(function () {
                    ruleService.remove(ruleUnderTest);
                    ruleUnderTest = null;
                    ruleOnAddSub.unsubscribe();
                });
                it("Has a rule and group that we can add conditions to", function () {
                    expect(ruleUnderTest.isPersisted()).toBe(true);
                    expect(groupUnderTest.isPersisted()).toBe(true);
                });
                it("Can add a new Condition", function (done) {
                    var aCondition = new Condition_1.ConditionModel(null, new ServerSideFieldModel_1.ServerSideTypeModel("UsersCountryConditionlet"));
                    aCondition.name = "pointless_name-" + new Date().getTime();
                    aCondition.owningGroup = groupUnderTest;
                    aCondition.setParameter("sessionKey", "foo");
                    aCondition.setParameter("sessionValue", "bar");
                    var sub = conditionService.listForGroup(groupUnderTest).subscribe(function (condition) {
                        sub.unsubscribe();
                        //noinspection TypeScriptUnresolvedFunction
                        expect(condition.isPersisted()).toBe(true, "Condition is not persisted!");
                        done();
                    }, function (err) {
                        expect(err).toBeUndefined("error was thrown.");
                        done();
                    });
                    conditionService.add(aCondition);
                });
                it("Is added to the owning rule's list of conditions.", function (done) {
                    var aCondition = new Condition_1.ConditionModel(null, new ServerSideFieldModel_1.ServerSideTypeModel("UsersCountryConditionlet"));
                    aCondition.name = "pointless_name-" + new Date().getTime();
                    aCondition.owningGroup = groupUnderTest;
                    aCondition.setParameter("comparatorValue", "is");
                    aCondition.setParameter("isoCode", "US");
                    var sub = conditionService.listForGroup(groupUnderTest).subscribe(function (condition) {
                        sub.unsubscribe();
                        expect(groupUnderTest.conditions[condition.key]).toBe(true, "Check the ConditionService.onAdd listener in the RuleService.");
                        done();
                    }, function (err) {
                        expect(err).toBeUndefined("error was thrown.");
                        done();
                    });
                    conditionService.add(aCondition);
                });
                it("Condition being added to the owning group is persisted to server.", function (done) {
                    var aCondition = new Condition_1.ConditionModel(null, new ServerSideFieldModel_1.ServerSideTypeModel("UsersCountryConditionlet"));
                    aCondition.name = "pointless_name-" + new Date().getTime();
                    aCondition.owningGroup = groupUnderTest;
                    aCondition.setParameter("comparatorValue", "is");
                    aCondition.setParameter("isoCode", "US");
                    var firstPass = conditionService.listForGroup(groupUnderTest).subscribe(function (condition) {
                        //noinspection TypeScriptUnresolvedFunction
                        firstPass.unsubscribe(); // don't want to run THIS watcher twice.
                        expect(groupUnderTest.conditions[condition.key]).toBe(true, "Check the ConditionService.onAdd listener in the RuleService.");
                        // condition was persisted to server and is present on the Rule.
                        ruleService.save(ruleUnderTest, function () {
                            ruleService.get(ruleUnderTest.key, function (rule) {
                                var rehydratedGroup = rule.groups[groupUnderTest.key];
                                expect(rehydratedGroup).toBeDefined("The condition group should still exist");
                                expect(rehydratedGroup.conditions[condition.key]).toBeDefined("The condition should still exist as a child of the group.");
                                done();
                            });
                        });
                    }, function (err) {
                        expect(err).toBeUndefined("error was thrown!");
                        done();
                    });
                    // save the condition to the group:
                    conditionService.add(aCondition);
                });
                it("Will add a new condition parameters to an existing condition.", function (done) {
                    var clientCondition = new Condition_1.ConditionModel(null, new ServerSideFieldModel_1.ServerSideTypeModel("UserBrowserHeaderConditionlet"));
                    clientCondition.owningGroup = groupUnderTest;
                    clientCondition.setParameter("headerKey", "foo");
                    clientCondition.setParameter("headerValue", "bar");
                    var key = "aParamKey";
                    var value = "aParamValue";
                    conditionService.add(clientCondition, function (resultCondition) {
                        // serverCondition is the same instance as resultCondition
                        expect(clientCondition.isPersisted()).toBe(true, "Condition is not persisted!");
                        clientCondition.setParameter(key, value);
                        conditionService.save(clientCondition, function (savedCondition) {
                            // savedCondition is also the same instance as resultCondition
                            conditionService.get(clientCondition.owningGroup, clientCondition.key, function (updatedCondition) {
                                // updatedCondition and clientCondition SHOULD NOT be the same instance object.
                                updatedCondition['abc123'] = 100;
                                expect(clientCondition['abc123']).toBeUndefined();
                                expect(clientCondition.getParameterValue(key)).toBe(value, "ClientCondition param value should still be set.");
                                expect(updatedCondition.getParameterValue(key)).toBe(value, "Condition refreshed from server should have the correct param value.");
                                expect(Object.keys(updatedCondition.parameters).length).toEqual(1, "The old keys should have been removed.");
                                done();
                            });
                        });
                    });
                });
                it("Can update condition parameter values on existing condition.", function (done) {
                    var param1 = { key: 'sessionKey', v1: 'value1', v2: 'value2' };
                    var param2 = { key: 'sessionValue', v1: 'abc123', v2: 'def456' };
                    var clientCondition = new Condition_1.ConditionModel(null, new ServerSideFieldModel_1.ServerSideTypeModel("SetSessionAttributeConditionlet"));
                    clientCondition.owningGroup = groupUnderTest;
                    clientCondition.setParameter(param1.key, param1.v1);
                    clientCondition.setParameter(param2.key, param2.v1);
                    conditionService.add(clientCondition, function (resultCondition) {
                        clientCondition.setParameter(param1.key, param1.v2);
                        conditionService.save(clientCondition, function (savedCondition) {
                            conditionService.get(clientCondition.owningGroup, clientCondition.key, function (updatedCondition) {
                                expect(updatedCondition.getParameterValue(param1.key)).toBe(param1.v2, "Condition refreshed from server should have the correct param value.");
                                expect(updatedCondition.getParameterValue(param2.key)).toBe(param2.v1, "Condition refreshed from server should have the correct param value.");
                                expect(Object.keys(updatedCondition.parameters).length).toEqual(2);
                                done();
                            });
                        });
                    });
                });
            });
            Tools = (function () {
                function Tools() {
                }
                Tools.createRule = function (ruleService, cb) {
                    if (cb === void 0) { cb = null; }
                    console.log('Attempting to create rule.');
                    var rule = new Rule_1.RuleModel(null);
                    rule.enabled = true;
                    rule.name = "TestRule-" + new Date().getTime();
                    ruleService.add(rule, cb);
                };
                return Tools;
            })();
        }
    }
});
//# sourceMappingURL=Condition.it-spec.js.map