System.register(['angular2/http', 'angular2/core', "./ConditionGroup", "../util/CwModel", "../persistence/ApiRoot", "./Action", "../system/locale/I18n"], function(exports_1) {
    var __extends = (this && this.__extends) || function (d, b) {
        for (var p in b) if (b.hasOwnProperty(p)) d[p] = b[p];
        function __() { this.constructor = d; }
        d.prototype = b === null ? Object.create(b) : (__.prototype = b.prototype, new __());
    };
    var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
        var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
        if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
        else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
        return c > 3 && r && Object.defineProperty(target, key, r), r;
    };
    var __metadata = (this && this.__metadata) || function (k, v) {
        if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
    };
    var http_1, core_1, ConditionGroup_1, CwModel_1, ApiRoot_1, Action_1, I18n_1;
    var RuleModel, RULE_DEFAULT_RSRC, RULE_I18N_BASE_KEY, RuleService;
    return {
        setters:[
            function (http_1_1) {
                http_1 = http_1_1;
            },
            function (core_1_1) {
                core_1 = core_1_1;
            },
            function (ConditionGroup_1_1) {
                ConditionGroup_1 = ConditionGroup_1_1;
            },
            function (CwModel_1_1) {
                CwModel_1 = CwModel_1_1;
            },
            function (ApiRoot_1_1) {
                ApiRoot_1 = ApiRoot_1_1;
            },
            function (Action_1_1) {
                Action_1 = Action_1_1;
            },
            function (I18n_1_1) {
                I18n_1 = I18n_1_1;
            }],
        execute: function() {
            RuleModel = (function (_super) {
                __extends(RuleModel, _super);
                function RuleModel(key, name, fireOn) {
                    if (name === void 0) { name = ''; }
                    if (fireOn === void 0) { fireOn = 'EVERY_PAGE'; }
                    _super.call(this, key);
                    this.name = name;
                    this.fireOn = fireOn;
                    this.enabled = false;
                    this.actions = {};
                    this.groups = {};
                }
                RuleModel.prototype.addGroup = function (group) {
                    this.groups[group.key] = group;
                };
                RuleModel.prototype.removeGroup = function (group) {
                    delete this.groups[group.key];
                };
                RuleModel.prototype.isValid = function () {
                    var valid = !!this.name;
                    valid = valid && this.name.trim().length > 0;
                    return valid;
                };
                RuleModel.fromJson = function (key, json) {
                    var rule = new RuleModel(key, json.name, json.fireOn);
                    rule.enabled = json.enabled;
                    rule.priority = json.priority;
                    return rule;
                };
                return RuleModel;
            })(CwModel_1.CwModel);
            exports_1("RuleModel", RuleModel);
            RULE_DEFAULT_RSRC = {
                inputs: {
                    filter: {
                        placeholder: "Start typing to filter rules...",
                        tip: "Show only the rules that match your filter."
                    },
                    fireOn: {
                        label: "Fire On",
                        options: {
                            EveryPage: "Every Page",
                            OncePerVisit: "Once per Visit",
                            OncePerVisitor: "Once per visitor",
                            EveryRequest: "Every Request"
                        }
                    },
                    addRule: {
                        label: "Add Rule",
                        tip: "Create a new rule"
                    },
                    onOff: {
                        tip: "Prevent or allow this rule to execute",
                        on: {
                            label: "On"
                        },
                        off: {
                            label: "Off"
                        }
                    },
                    name: {
                        placeholder: "Describe the rule"
                    },
                    group: {
                        whenConditions: {
                            label: "This rule fires when the following conditions are met:",
                        },
                        whenFurtherConditions: {
                            label: "when the following condition(s) are met:"
                        },
                        andOr: {
                            and: { label: "AND", },
                            or: { label: "OR", }
                        }
                    },
                    condition: {
                        andOr: {
                            and: { label: "AND", },
                            or: { label: "OR", }
                        },
                        type: {
                            placeholder: "Select a Condition"
                        }
                    },
                    action: {
                        firesActions: "This rule sets the following action(s)",
                        type: {
                            placeholder: "Select an Action"
                        }
                    }
                }
            };
            RULE_I18N_BASE_KEY = 'api.sites.ruleengine.rules';
            RuleService = (function () {
                function RuleService(apiRoot, http, actionService, conditionGroupService, rsrcService) {
                    this.rsrc = RULE_DEFAULT_RSRC;
                    this.apiRoot = apiRoot;
                    this.http = http;
                    this.ref = apiRoot.defaultSite.child('ruleengine/rules');
                    this._rsrcService = rsrcService;
                }
                RuleService.toJson = function (rule) {
                    var json = {};
                    json.key = rule.key;
                    json.enabled = rule.enabled;
                    json.fireOn = rule.fireOn;
                    json.name = rule.name;
                    json.priority = rule.priority;
                    json.conditionGroups = ConditionGroup_1.ConditionGroupService.toJsonList(rule.groups);
                    json.ruleActions = rule.actions;
                    return json;
                };
                RuleService.fromSnapshot = function (key, snapshot) {
                    var rule = new RuleModel(key);
                    var val = snapshot.val();
                    rule.snapshot = snapshot;
                    rule.enabled = val.enabled;
                    rule.fireOn = val.fireOn;
                    rule.name = val.name;
                    rule.priority = val.priority;
                    rule.actions = val.ruleActions;
                    var groups = snapshot.child('conditionGroups');
                    if (groups.exists()) {
                        groups.forEach(function (groupSnap) {
                            rule.addGroup(ConditionGroup_1.ConditionGroupService._fromSnapshot(rule, groupSnap));
                        });
                    }
                    return rule;
                };
                RuleService.prototype.get = function (key, cb) {
                    this.ref.child(key).once('value', function (snap) {
                        var rule = RuleService.fromSnapshot(key, snap);
                        cb(rule);
                    }, function (e) {
                        throw e;
                    });
                };
                RuleService.prototype.list = function () {
                    var emitter = new core_1.EventEmitter();
                    this.ref.once('value', function (snap) {
                        var rules = snap['val']();
                        var parsed = [];
                        Object.keys(rules).forEach(function (key) {
                            var rule = RuleService.fromSnapshot(key, snap.child(key));
                            parsed.push(rule);
                        });
                        emitter.emit(parsed);
                    }, function (e) {
                        console.log("RuleService", "list", "error", e);
                        throw e;
                    });
                    return emitter;
                };
                RuleService.prototype.add = function (rule, cb) {
                    if (cb === void 0) { cb = null; }
                    this.ref.push(RuleService.toJson(rule), function (e, resultSnapshot) {
                        if (e) {
                            throw e;
                        }
                        rule.snapshot = resultSnapshot;
                        rule.key = resultSnapshot.key();
                        if (cb) {
                            cb(rule);
                        }
                    });
                };
                RuleService.prototype.save = function (rule, cb) {
                    if (cb === void 0) { cb = null; }
                    if (!rule.isValid()) {
                        throw new Error("Rule is not valid, cannot save.");
                    }
                    if (!rule.isPersisted()) {
                        this.add(rule, cb);
                    }
                    else {
                        this.ref.child(rule.key).set(RuleService.toJson(rule), function () {
                            if (cb) {
                                cb(rule);
                            }
                        });
                    }
                };
                RuleService.prototype.remove = function (rule, cb) {
                    if (cb === void 0) { cb = null; }
                    if (rule.isPersisted()) {
                        rule.snapshot.ref().remove(function (key) {
                            if (cb) {
                                cb();
                            }
                        }).catch(function (e) {
                            console.log("Error removing rule", e);
                            if (cb) {
                                cb(e);
                            }
                            throw e;
                        });
                    }
                };
                RuleService = __decorate([
                    core_1.Injectable(), 
                    __metadata('design:paramtypes', [ApiRoot_1.ApiRoot, http_1.Http, Action_1.ActionService, ConditionGroup_1.ConditionGroupService, I18n_1.I18nService])
                ], RuleService);
                return RuleService;
            })();
            exports_1("RuleService", RuleService);
        }
    }
});
//# sourceMappingURL=Rule.js.map