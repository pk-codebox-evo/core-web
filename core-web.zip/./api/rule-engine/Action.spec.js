System.register(['../../api/rule-engine/Action', "./ServerSideFieldModel"], function(exports_1) {
    var Action_1, ServerSideFieldModel_1;
    return {
        setters:[
            function (Action_1_1) {
                Action_1 = Action_1_1;
            },
            function (ServerSideFieldModel_1_1) {
                ServerSideFieldModel_1 = ServerSideFieldModel_1_1;
            }],
        execute: function() {
            describe('Unit.api.rule-engine.Action', function () {
                beforeEach(function () {
                });
                it("Isn't valid when no rule.", function () {
                    var foo = new Action_1.ActionModel(null, new ServerSideFieldModel_1.ServerSideTypeModel(), null);
                    expect(foo.isValid()).toEqual(false);
                });
            });
        }
    }
});
//# sourceMappingURL=Action.spec.js.map