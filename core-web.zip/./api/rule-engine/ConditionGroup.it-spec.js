System.register(['../../api/rule-engine/Rule', '../../api/rule-engine/Condition', 'angular2/core', '../../api/persistence/DataStore', '../../api/persistence/RestDataStore', '../../api/persistence/ApiRoot', '../../api/auth/UserModel', '../../api/rule-engine/ConditionType', '../../api/rule-engine/Action', '../../api/rule-engine/ConditionGroup', "./ActionType", "../system/locale/I18n"], function(exports_1) {
    var Rule_1, Condition_1, core_1, DataStore_1, RestDataStore_1, ApiRoot_1, UserModel_1, ConditionType_1, Action_1, ConditionGroup_1, ActionType_1, I18n_1;
    var injector, Gen;
    return {
        setters:[
            function (Rule_1_1) {
                Rule_1 = Rule_1_1;
            },
            function (Condition_1_1) {
                Condition_1 = Condition_1_1;
            },
            function (core_1_1) {
                core_1 = core_1_1;
            },
            function (DataStore_1_1) {
                DataStore_1 = DataStore_1_1;
            },
            function (RestDataStore_1_1) {
                RestDataStore_1 = RestDataStore_1_1;
            },
            function (ApiRoot_1_1) {
                ApiRoot_1 = ApiRoot_1_1;
            },
            function (UserModel_1_1) {
                UserModel_1 = UserModel_1_1;
            },
            function (ConditionType_1_1) {
                ConditionType_1 = ConditionType_1_1;
            },
            function (Action_1_1) {
                Action_1 = Action_1_1;
            },
            function (ConditionGroup_1_1) {
                ConditionGroup_1 = ConditionGroup_1_1;
            },
            function (ActionType_1_1) {
                ActionType_1 = ActionType_1_1;
            },
            function (I18n_1_1) {
                I18n_1 = I18n_1_1;
            }],
        execute: function() {
            injector = core_1.Injector.resolveAndCreate([ApiRoot_1.ApiRoot,
                I18n_1.I18nService,
                UserModel_1.UserModel,
                Rule_1.RuleService,
                Action_1.ActionService,
                ActionType_1.ActionTypeService,
                ConditionType_1.ConditionTypeService,
                Condition_1.ConditionService,
                ConditionGroup_1.ConditionGroupService,
                new core_1.Provider(DataStore_1.DataStore, { useClass: RestDataStore_1.RestDataStore })
            ]);
            describe('Integration.api.rule-engine.ConditionGroupService', function () {
                var ruleService;
                var onAddSub;
                var conditionGroupService;
                var ruleUnderTest;
                beforeEach(function (done) {
                    ruleService = injector.get(Rule_1.RuleService);
                    conditionGroupService = injector.get(ConditionGroup_1.ConditionGroupService);
                    onAddSub = ruleService.list().subscribe(function (rule) {
                        ruleUnderTest = rule[0];
                        done();
                    }, function (err) {
                        expect(err).toBeUndefined("error was thrown.");
                        done();
                    });
                    Gen.createRules(ruleService);
                });
                afterEach(function () {
                    ruleService.remove(ruleUnderTest);
                    ruleUnderTest = null;
                    onAddSub.unsubscribe();
                });
                it("Has rules that we can add conditionGroups to", function () {
                    expect(ruleUnderTest.isPersisted()).toBe(true);
                });
                it("Can add a new ConditionGroup", function (done) {
                    var aConditionGroup = new ConditionGroup_1.ConditionGroupModel(null, ruleUnderTest, "OR", 1);
                    var subscriber = conditionGroupService.list(ruleUnderTest).subscribe(function (conditionGroup) {
                        //noinspection TypeScriptUnresolvedFunction
                        expect(conditionGroup.isPersisted()).toBe(true, "ConditionGroup is not persisted!");
                        done();
                    }, function (err) {
                        expect(err).toBeUndefined("error was thrown.");
                        done();
                    });
                    conditionGroupService.add(aConditionGroup);
                });
                it("Is added to the owning rule's list of conditionGroups.", function (done) {
                    var aConditionGroup = new ConditionGroup_1.ConditionGroupModel(null, ruleUnderTest, "OR", 1);
                    conditionGroupService.list(ruleUnderTest).subscribe(function (conditionGroup) {
                        expect(ruleUnderTest.groups[conditionGroup.key]).toBeDefined();
                        done();
                    }, function (err) {
                        expect(err).toBeUndefined("error was thrown.");
                        done();
                    });
                    conditionGroupService.add(aConditionGroup);
                });
                it("ConditionGroup being added to the owning rule is persisted to server.", function (done) {
                    var aConditionGroup = new ConditionGroup_1.ConditionGroupModel(null, ruleUnderTest, "OR", 99);
                    aConditionGroup.owningRule = ruleUnderTest;
                    var firstPass = conditionGroupService.list(ruleUnderTest).subscribe(function (conditionGroup) {
                        firstPass.unsubscribe(); // don't want to run THIS watcher twice.
                        expect(ruleUnderTest.groups[conditionGroup.key]).toBeDefined("Expected group to be on the rule.");
                        ruleService.save(ruleUnderTest, function () {
                            ruleService.get(ruleUnderTest.key, function (rule) {
                                expect(rule.groups[conditionGroup.key]).toBeDefined("Well that's odd");
                                expect(rule.groups[conditionGroup.key].operator).toEqual("OR");
                                // @todo ggranum: Defect=Cannot set priority at creation time.
                                //expect(rule.groups[conditionGroup.key].priority).toEqual(99)
                                /* Now read the ConditionGroups off the rule we just got back. Add listener first, then trigger call. */
                                conditionGroupService.list(ruleUnderTest).subscribe(function (conditionGroup) {
                                    expect(conditionGroup.operator).toEqual("OR");
                                    // @todo ggranum: Defect=Cannot set priority at creation time.
                                    //expect(conditionGroup.priority).toEqual(99)
                                    done();
                                });
                                conditionGroupService.list(rule);
                            });
                        });
                    }, function (err) {
                        expect(err).toBeUndefined("error was thrown!");
                        done();
                    });
                    conditionGroupService.add(aConditionGroup);
                });
            });
            Gen = (function () {
                function Gen() {
                }
                Gen.createRules = function (ruleService) {
                    console.log('Attempting to create rule.');
                    var rule = new Rule_1.RuleModel(null);
                    rule.enabled = true;
                    rule.name = "TestRule-" + new Date().getTime();
                    ruleService.add(rule);
                };
                return Gen;
            })();
        }
    }
});
//# sourceMappingURL=ConditionGroup.it-spec.js.map