System.register(['angular2/core', "./Condition", "../util/CwModel", "../persistence/ApiRoot"], function(exports_1) {
    var __extends = (this && this.__extends) || function (d, b) {
        for (var p in b) if (b.hasOwnProperty(p)) d[p] = b[p];
        function __() { this.constructor = d; }
        d.prototype = b === null ? Object.create(b) : (__.prototype = b.prototype, new __());
    };
    var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
        var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
        if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
        else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
        return c > 3 && r && Object.defineProperty(target, key, r), r;
    };
    var __metadata = (this && this.__metadata) || function (k, v) {
        if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
    };
    var __param = (this && this.__param) || function (paramIndex, decorator) {
        return function (target, key) { decorator(target, key, paramIndex); }
    };
    var core_1, Condition_1, CwModel_1, ApiRoot_1;
    var ConditionGroupModel, ConditionGroupService;
    return {
        setters:[
            function (core_1_1) {
                core_1 = core_1_1;
            },
            function (Condition_1_1) {
                Condition_1 = Condition_1_1;
            },
            function (CwModel_1_1) {
                CwModel_1 = CwModel_1_1;
            },
            function (ApiRoot_1_1) {
                ApiRoot_1 = ApiRoot_1_1;
            }],
        execute: function() {
            ConditionGroupModel = (function (_super) {
                __extends(ConditionGroupModel, _super);
                function ConditionGroupModel(key, owningRule, operator, priority) {
                    if (key === void 0) { key = null; }
                    _super.call(this, key);
                    this.owningRule = owningRule;
                    this.operator = operator;
                    this.priority = priority;
                    this.conditions = {};
                }
                ConditionGroupModel.prototype.isValid = function () {
                    var valid = !!this.owningRule;
                    valid = valid && this.owningRule.isValid() && this.owningRule.isPersisted();
                    valid = valid && this.operator && (this.operator === 'AND' || this.operator === 'OR');
                    return valid;
                };
                return ConditionGroupModel;
            })(CwModel_1.CwModel);
            exports_1("ConditionGroupModel", ConditionGroupModel);
            ConditionGroupService = (function () {
                function ConditionGroupService(apiRoot, conditionService) {
                    this.ref = apiRoot.defaultSite.child('ruleengine/rules');
                    this.apiRoot = apiRoot;
                }
                ConditionGroupService._fromSnapshot = function (rule, snapshot) {
                    var val = snapshot.val();
                    var ra = new ConditionGroupModel(snapshot.key(), rule, val.operator, val.priority);
                    ra.conditions = val.conditions;
                    return ra;
                };
                ConditionGroupService._toJson = function (conditionGroup) {
                    var json = {};
                    json.id = conditionGroup.key;
                    json.operator = conditionGroup.operator;
                    json.priority = conditionGroup.priority;
                    json.conditions = conditionGroup.conditions;
                    return json;
                };
                ConditionGroupService.toJsonList = function (models) {
                    var list = {};
                    Object.keys(models).forEach(function (key) {
                        list[key] = ConditionGroupService._toJson(models[key]);
                    });
                    return list;
                };
                ConditionGroupService.prototype.list = function (rule) {
                    var ee = new core_1.EventEmitter();
                    /* @todo ggranum remove stupid hack (ee returning after an emit means no fire on subscribe) */
                    window.setTimeout(function () {
                        if (rule.isPersisted()) {
                            var groups = [];
                            var conditionGroupsSnap = rule.snapshot.child('conditionGroups');
                            if (conditionGroupsSnap.exists()) {
                                conditionGroupsSnap.forEach(function (conditionGroupSnap) {
                                    groups.push(ConditionGroupService._fromSnapshot(rule, conditionGroupSnap));
                                });
                                ee.emit(groups);
                            }
                            else {
                                ee.emit([]);
                            }
                        }
                    }, 50);
                    return ee;
                };
                ConditionGroupService.prototype.add = function (model, cb) {
                    if (cb === void 0) { cb = null; }
                    console.log("api.rule-engine.ConditionGroupService", "add", model);
                    if (!model.isValid()) {
                        throw new Error("This should be thrown from a checkValid function on the model, and should provide the info needed to make the user aware of the fix.");
                    }
                    var json = ConditionGroupService._toJson(model);
                    this.ref.child(model.owningRule.key).child('conditionGroups').push(json, function (e, result) {
                        if (e) {
                            throw e;
                        }
                        model.key = result.key();
                        if (cb) {
                            cb(model);
                        }
                    });
                };
                ConditionGroupService.prototype.save = function (model, cb) {
                    if (cb === void 0) { cb = null; }
                    console.log("api.rule-engine.ConditionGroupService", "save", model);
                    if (!model.isValid()) {
                        throw new Error("This should be thrown from a checkValid function on the model, and should provide the info needed to make the user aware of the fix.");
                    }
                    if (!model.isPersisted()) {
                        this.add(model, cb);
                    }
                    else {
                        var json = ConditionGroupService._toJson(model);
                        this.ref.child(model.owningRule.key).child('conditionGroups').child(model.key).set(json, function (result) {
                            if (cb) {
                                cb(model);
                            }
                        });
                    }
                };
                ConditionGroupService.prototype.remove = function (model, cb) {
                    if (cb === void 0) { cb = null; }
                    console.log("api.rule-engine.ConditionGroupService", "remove", model);
                    // ConditionGroup is a special case. Have to delete the group from
                    if (model.isPersisted()) {
                        this.ref.child(model.owningRule.key).child('conditionGroups').child(model.key).remove(function () {
                            if (cb) {
                                cb(model);
                            }
                        });
                    }
                };
                ConditionGroupService = __decorate([
                    __param(0, core_1.Inject(ApiRoot_1.ApiRoot)),
                    __param(1, core_1.Inject(Condition_1.ConditionService)), 
                    __metadata('design:paramtypes', [Object, Condition_1.ConditionService])
                ], ConditionGroupService);
                return ConditionGroupService;
            })();
            exports_1("ConditionGroupService", ConditionGroupService);
        }
    }
});
//# sourceMappingURL=ConditionGroup.js.map