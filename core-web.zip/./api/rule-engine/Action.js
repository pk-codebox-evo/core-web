System.register(['angular2/core', "../persistence/ApiRoot", "./ActionType", "./ServerSideFieldModel"], function(exports_1) {
    var __extends = (this && this.__extends) || function (d, b) {
        for (var p in b) if (b.hasOwnProperty(p)) d[p] = b[p];
        function __() { this.constructor = d; }
        d.prototype = b === null ? Object.create(b) : (__.prototype = b.prototype, new __());
    };
    var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
        var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
        if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
        else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
        return c > 3 && r && Object.defineProperty(target, key, r), r;
    };
    var __metadata = (this && this.__metadata) || function (k, v) {
        if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
    };
    var core_1, ApiRoot_1, ActionType_1, ServerSideFieldModel_1;
    var noop, ActionModel, ActionService;
    return {
        setters:[
            function (core_1_1) {
                core_1 = core_1_1;
            },
            function (ApiRoot_1_1) {
                ApiRoot_1 = ApiRoot_1_1;
            },
            function (ActionType_1_1) {
                ActionType_1 = ActionType_1_1;
            },
            function (ServerSideFieldModel_1_1) {
                ServerSideFieldModel_1 = ServerSideFieldModel_1_1;
            }],
        execute: function() {
            noop = function () {
                var arg = [];
                for (var _i = 0; _i < arguments.length; _i++) {
                    arg[_i - 0] = arguments[_i];
                }
            };
            ActionModel = (function (_super) {
                __extends(ActionModel, _super);
                function ActionModel(key, type, rule, priority) {
                    if (priority === void 0) { priority = 1; }
                    _super.call(this, key, type, priority);
                    this.owningRule = rule;
                }
                ActionModel.prototype.isValid = function () {
                    return !!this.owningRule && _super.prototype.isValid.call(this);
                };
                ActionModel.prototype.toJson = function () {
                    var json = _super.prototype.toJson.call(this);
                    json.owningRule = this.owningRule;
                    return json;
                };
                ActionModel.fromJson = function () {
                    return null;
                };
                return ActionModel;
            })(ServerSideFieldModel_1.ServerSideFieldModel);
            exports_1("ActionModel", ActionModel);
            ActionService = (function () {
                function ActionService(apiRoot, typeService) {
                    this._typeService = typeService;
                    this.ref = apiRoot.defaultSite.child('ruleengine/actions');
                    this.apiRoot = apiRoot;
                }
                ActionService.prototype._fromSnapshot = function (rule, snapshot, cb) {
                    if (cb === void 0) { cb = noop; }
                    var val = snapshot.val();
                    this._typeService.get(val.actionlet, function (type) {
                        var ra = new ActionModel(snapshot.key(), type, rule);
                        ra.name = val.name;
                        ra.owningRule = rule;
                        Object.keys(val.parameters).forEach(function (key) {
                            var param = val.parameters[key];
                            ra.setParameter(key, param.value);
                        });
                        cb(ra);
                    });
                };
                ActionService.prototype._toJson = function (action) {
                    var json = {};
                    json.name = action.name || "fake_name_" + new Date().getTime() + '_' + Math.random();
                    json.owningRule = action.owningRule.key;
                    json.actionlet = action.type.key;
                    json.priority = action.priority;
                    json.parameters = action.parameters;
                    return json;
                };
                ActionService.prototype.list = function (rule) {
                    var _this = this;
                    var ee = new core_1.EventEmitter();
                    if (rule.isPersisted()) {
                        var keys = Object.keys(rule.actions);
                        var count = 0;
                        var actions = [];
                        keys.forEach(function (actionId) {
                            _this.get(rule, actionId, function (action) {
                                count++;
                                actions.push(action);
                                if (count = keys.length) {
                                    ee.emit(actions);
                                }
                            });
                        });
                        if (keys.length === 0) {
                            /* @todo ggranum remove stupid hack (ee returning after an emit means no fire on subscribe) */
                            window.setTimeout(function () { return ee.emit([]); }, 500);
                        }
                    }
                    return ee;
                };
                ActionService.prototype.get = function (rule, key, cb) {
                    var _this = this;
                    if (cb === void 0) { cb = noop; }
                    this.ref.child(key).once('value', function (actionSnap) {
                        _this._fromSnapshot(rule, actionSnap, function (model) {
                            cb(model);
                        });
                    }, function (e) {
                        throw e;
                    });
                };
                ActionService.prototype.add = function (model, cb) {
                    if (cb === void 0) { cb = noop; }
                    console.log("api.rule-engine.ActionService", "add", model);
                    var json = this._toJson(model);
                    this.ref.push(json, function (e, result) {
                        if (e) {
                            cb(model, e);
                        }
                        else {
                            model.key = result.key();
                            cb(model);
                        }
                    });
                };
                ActionService.prototype.save = function (model, cb) {
                    if (cb === void 0) { cb = noop; }
                    console.log("api.rule-engine.ActionService", "save", model);
                    if (!model.isValid()) {
                        throw new Error("This should be thrown from a checkValid function on model, and should provide the info needed to make the user aware of the fix.");
                    }
                    if (!model.isPersisted()) {
                        this.add(model, cb);
                    }
                    else {
                        var json = this._toJson(model);
                        this.ref.child(model.key).set(json, function (e, result) {
                            if (e) {
                                throw e;
                            }
                            cb(model);
                        });
                    }
                };
                ActionService.prototype.remove = function (model, cb) {
                    if (cb === void 0) { cb = noop; }
                    console.log("api.rule-engine.ActionService", "remove", model);
                    this.ref.child(model.key).remove(function () {
                        cb(model);
                    });
                };
                ActionService = __decorate([
                    core_1.Injectable(), 
                    __metadata('design:paramtypes', [ApiRoot_1.ApiRoot, ActionType_1.ActionTypeService])
                ], ActionService);
                return ActionService;
            })();
            exports_1("ActionService", ActionService);
        }
    }
});
//# sourceMappingURL=Action.js.map