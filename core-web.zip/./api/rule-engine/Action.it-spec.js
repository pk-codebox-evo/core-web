System.register(['../../api/rule-engine/Rule', 'angular2/core', "../../api/persistence/RestDataStore", "../../api/persistence/DataStore", '../../api/persistence/ApiRoot', "../../api/auth/UserModel", '../../api/rule-engine/ConditionType', "../../api/rule-engine/Action", "../../api/rule-engine/ConditionGroup", "../../api/rule-engine/Condition", "./ActionType", "../system/locale/I18n", "./ServerSideFieldModel"], function(exports_1) {
    var Rule_1, core_1, RestDataStore_1, DataStore_1, ApiRoot_1, UserModel_1, ConditionType_1, Action_1, ConditionGroup_1, Condition_1, ActionType_1, I18n_1, ServerSideFieldModel_1;
    var injector, Gen;
    return {
        setters:[
            function (Rule_1_1) {
                Rule_1 = Rule_1_1;
            },
            function (core_1_1) {
                core_1 = core_1_1;
            },
            function (RestDataStore_1_1) {
                RestDataStore_1 = RestDataStore_1_1;
            },
            function (DataStore_1_1) {
                DataStore_1 = DataStore_1_1;
            },
            function (ApiRoot_1_1) {
                ApiRoot_1 = ApiRoot_1_1;
            },
            function (UserModel_1_1) {
                UserModel_1 = UserModel_1_1;
            },
            function (ConditionType_1_1) {
                ConditionType_1 = ConditionType_1_1;
            },
            function (Action_1_1) {
                Action_1 = Action_1_1;
            },
            function (ConditionGroup_1_1) {
                ConditionGroup_1 = ConditionGroup_1_1;
            },
            function (Condition_1_1) {
                Condition_1 = Condition_1_1;
            },
            function (ActionType_1_1) {
                ActionType_1 = ActionType_1_1;
            },
            function (I18n_1_1) {
                I18n_1 = I18n_1_1;
            },
            function (ServerSideFieldModel_1_1) {
                ServerSideFieldModel_1 = ServerSideFieldModel_1_1;
            }],
        execute: function() {
            injector = core_1.Injector.resolveAndCreate([ApiRoot_1.ApiRoot,
                I18n_1.I18nService,
                UserModel_1.UserModel,
                Rule_1.RuleService,
                Action_1.ActionService,
                ActionType_1.ActionTypeService,
                ConditionType_1.ConditionTypeService,
                Condition_1.ConditionService,
                ConditionGroup_1.ConditionGroupService,
                new core_1.Provider(DataStore_1.DataStore, { useClass: RestDataStore_1.RestDataStore })
            ]);
            describe('Integration.api.rule-engine.ActionService', function () {
                var ruleService;
                var ruleOnAddSub;
                var actionService;
                var ruleUnderTest;
                beforeEach(function (done) {
                    ruleService = injector.get(Rule_1.RuleService);
                    actionService = injector.get(Action_1.ActionService);
                    ruleOnAddSub = ruleService.list().subscribe(function (rule) {
                        ruleUnderTest = rule[0];
                        done();
                    }, function (err) {
                        expect(err).toBeUndefined("error was thrown.");
                        done();
                    });
                    Gen.createRules(ruleService);
                });
                afterEach(function () {
                    ruleService.remove(ruleUnderTest);
                    ruleUnderTest = null;
                    ruleOnAddSub.unsubscribe();
                });
                it("Has rules that we can add actions to", function () {
                    expect(ruleUnderTest.isPersisted()).toBe(true);
                });
                it("Can add a new Action", function (done) {
                    var anAction = new Action_1.ActionModel(null, new ServerSideFieldModel_1.ServerSideTypeModel("SetSessionAttributeActionlet"), ruleUnderTest);
                    anAction.setParameter("sessionKey", "foo");
                    anAction.setParameter("sessionValue", "bar");
                    actionService.list(ruleUnderTest).subscribe(function (action) {
                        //noinspection TypeScriptUnresolvedFunction
                        expect(action.isPersisted()).toBe(true, "Action is not persisted!");
                        done();
                    }, function (err) {
                        expect(err).toBeUndefined("error was thrown.");
                        done();
                    });
                    actionService.add(anAction);
                });
                it("Is added to the owning rule's list of actions.", function (done) {
                    var anAction = new Action_1.ActionModel(null, new ServerSideFieldModel_1.ServerSideTypeModel("SetSessionAttributeActionlet"), ruleUnderTest);
                    anAction.setParameter("sessionKey", "foo");
                    anAction.setParameter("sessionValue", "bar");
                    actionService.list(ruleUnderTest).subscribe(function (action) {
                        expect(ruleUnderTest.actions[action.key]).toBe(true, "Check the ActionService.list(ruleUnderTest) listener in the RuleService.");
                        done();
                    }, function (err) {
                        expect(err).toBeUndefined("error was thrown.");
                        done();
                    });
                    actionService.add(anAction);
                });
                it("Action being added to the owning rule is persisted to server.", function (done) {
                    var anAction = new Action_1.ActionModel(null, new ServerSideFieldModel_1.ServerSideTypeModel("SetSessionAttributeActionlet"), ruleUnderTest);
                    anAction.setParameter("sessionKey", "foo");
                    anAction.setParameter("sessionValue", "bar");
                    var firstPass = actionService.list(ruleUnderTest).subscribe(function (action) {
                        //noinspection TypeScriptUnresolvedFunction
                        firstPass.unsubscribe(); // don't want to run THIS watcher twice.
                        expect(ruleUnderTest.actions[action.key]).toBe(true, "Check the ActionService.list(ruleUnderTest) listener in the RuleService.");
                        ruleService.save(ruleUnderTest, function () {
                            ruleService.get(ruleUnderTest.key, function (rule) {
                                expect(rule.actions[action.key]).toBe(true);
                                /* Now read the Actions off the rule we just got back. Add listener first, then trigger call. */
                                var sub = actionService.list(ruleUnderTest).subscribe(function (action) {
                                    expect(action.getParameter("sessionKey")).toEqual("foo");
                                    sub.unsubscribe();
                                    done();
                                });
                                actionService.list(rule);
                            });
                        });
                    }, function (err) {
                        expect(err).toBeUndefined("error was thrown!");
                        done();
                    });
                    actionService.add(anAction);
                });
                it("Will add a new action parameters to an existing action.", function (done) {
                    var clientAction = new Action_1.ActionModel(null, new ServerSideFieldModel_1.ServerSideTypeModel("SetSessionAttributeActionlet"), ruleUnderTest);
                    clientAction.setParameter("sessionKey", "foo");
                    clientAction.setParameter("sessionValue", "bar");
                    var key = "aParamKey";
                    var value = "aParamValue";
                    actionService.add(clientAction, function () {
                        // serverAction is the same instance as resultAction
                        expect(clientAction.isPersisted()).toBe(true, "Action is not persisted!");
                        clientAction.setParameter(key, value);
                        actionService.save(clientAction, function () {
                            // savedAction is also the same instance as resultAction
                            actionService.get(clientAction.owningRule, clientAction.key, function (updatedAction) {
                                // updatedAction and clientAction SHOULD NOT be the same instance object.
                                updatedAction['abc123'] = 100;
                                expect(clientAction['abc123']).toBeUndefined();
                                expect(clientAction.getParameter(key)).toBe(value, "ClientAction param value should still be set.");
                                expect(updatedAction.getParameterValue(key)).toBe(value, "Action refreshed from server should have the correct param value.");
                                expect(Object.keys(updatedAction.parameters).length).toEqual(1, "The old keys should have been removed.");
                                done();
                            });
                        });
                    });
                });
                it("Can update action parameter values on existing action.", function (done) {
                    var param1 = { key: 'sessionKey', v1: 'value1', v2: 'value2' };
                    var param2 = { key: 'sessionValue', v1: 'abc123', v2: 'def456' };
                    var clientAction = new Action_1.ActionModel(null, new ServerSideFieldModel_1.ServerSideTypeModel("SetSessionAttributeActionlet"), ruleUnderTest);
                    clientAction.setParameter(param1.key, param1.v1);
                    clientAction.setParameter(param2.key, param2.v1);
                    actionService.add(clientAction, function () {
                        clientAction.setParameter(param1.key, param1.v2);
                        actionService.save(clientAction, function () {
                            actionService.get(clientAction.owningRule, clientAction.key, function (updatedAction) {
                                expect(updatedAction.getParameterValue(param1.key)).toBe(param1.v2, "Action refreshed from server should have the correct param value.");
                                expect(updatedAction.getParameterValue(param2.key)).toBe(param2.v1, "Action refreshed from server should have the correct param value.");
                                expect(Object.keys(updatedAction.parameters).length).toEqual(2, "The old keys should have been removed.");
                                done();
                            });
                        });
                    });
                });
            });
            Gen = (function () {
                function Gen() {
                }
                Gen.createRules = function (ruleService) {
                    console.log('Attempting to create rule.');
                    var rule = new Rule_1.RuleModel(null);
                    rule.enabled = true;
                    rule.name = "TestRule-" + new Date().getTime();
                    ruleService.add(rule);
                };
                return Gen;
            })();
        }
    }
});
//# sourceMappingURL=Action.it-spec.js.map