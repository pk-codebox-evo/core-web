System.register(['angular2/core', 'rxjs/Rx', "../persistence/ApiRoot", "./ConditionType", "./ServerSideFieldModel"], function(exports_1) {
    var __extends = (this && this.__extends) || function (d, b) {
        for (var p in b) if (b.hasOwnProperty(p)) d[p] = b[p];
        function __() { this.constructor = d; }
        d.prototype = b === null ? Object.create(b) : (__.prototype = b.prototype, new __());
    };
    var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
        var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
        if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
        else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
        return c > 3 && r && Object.defineProperty(target, key, r), r;
    };
    var __metadata = (this && this.__metadata) || function (k, v) {
        if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
    };
    var core_1, Rx_1, ApiRoot_1, ConditionType_1, ServerSideFieldModel_1;
    var noop, ConditionModel, ConditionService;
    return {
        setters:[
            function (core_1_1) {
                core_1 = core_1_1;
            },
            function (Rx_1_1) {
                Rx_1 = Rx_1_1;
            },
            function (ApiRoot_1_1) {
                ApiRoot_1 = ApiRoot_1_1;
            },
            function (ConditionType_1_1) {
                ConditionType_1 = ConditionType_1_1;
            },
            function (ServerSideFieldModel_1_1) {
                ServerSideFieldModel_1 = ServerSideFieldModel_1_1;
            }],
        execute: function() {
            noop = function () {
                var arg = [];
                for (var _i = 0; _i < arguments.length; _i++) {
                    arg[_i - 0] = arguments[_i];
                }
            };
            ConditionModel = (function (_super) {
                __extends(ConditionModel, _super);
                function ConditionModel(key, type) {
                    _super.call(this, key, type);
                }
                ConditionModel.prototype.isValid = function () {
                    return !!this.owningGroup && _super.prototype.isValid.call(this);
                };
                ConditionModel.prototype.toJson = function () {
                    var json = _super.prototype.toJson.call(this);
                    json.owningGroup = this.owningGroup;
                    return json;
                };
                ConditionModel.fromJson = function () {
                    return null;
                };
                return ConditionModel;
            })(ServerSideFieldModel_1.ServerSideFieldModel);
            exports_1("ConditionModel", ConditionModel);
            ConditionService = (function () {
                function ConditionService(apiRoot, conditionTypeService) {
                    this._apiRoot = apiRoot;
                    this._conditionTypeService = conditionTypeService;
                    this._ref = apiRoot.defaultSite.child('ruleengine/conditions');
                    this._cacheMap = {};
                }
                ConditionService.prototype.fromSnapshot = function (group, snapshot, cb) {
                    if (cb === void 0) { cb = noop; }
                    var val = snapshot.val();
                    var count = 0;
                    this._conditionTypeService.get(val.conditionlet, function (type) {
                        console.log("ConditionService", "count:", count++, snapshot.key());
                        try {
                            var ra = new ConditionModel(snapshot.key(), type);
                            ra.name = val.name;
                            ra.owningGroup = group;
                            ra.priority = val.priority;
                            ra.operator = val.operator;
                            Object.keys(val.values).forEach(function (key) {
                                var x = val.values[key];
                                ra.setParameter(key, x.value, x.priority);
                            });
                            cb(ra);
                        }
                        catch (e) {
                            console.log("Error reading Condition.", e);
                            throw e;
                        }
                    });
                };
                ConditionService.toJson = function (condition) {
                    var json = {};
                    json.id = condition.key;
                    json.name = condition.name || "fake_name_" + new Date().getTime() + '_' + Math.random();
                    json.owningGroup = condition.owningGroup.key;
                    json.conditionlet = condition.type.key;
                    json.priority = condition.priority;
                    json.operator = condition.operator;
                    json.values = condition.parameters;
                    return json;
                };
                ConditionService.prototype.listForGroup = function (group) {
                    var _this = this;
                    var ee = new core_1.EventEmitter();
                    var deferred = Rx_1.Observable.defer(function () { return ee; });
                    var keys = Object.keys(group.conditions);
                    var count = 0;
                    var conditions = [];
                    keys.forEach(function (conditionId) {
                        if (_this._cacheMap[conditionId]) {
                            count++;
                            conditions.push(_this._cacheMap[conditionId]);
                            if (count == keys.length) {
                                ee.emit(conditions);
                            }
                        }
                        else {
                            var cRef = _this._ref.child(conditionId);
                            cRef.once('value', function (conditionSnap) {
                                _this.fromSnapshot(group, conditionSnap, function (model) {
                                    count++;
                                    conditions.push(model);
                                    _this._cacheMap[model.key] = model;
                                    if (count == keys.length) {
                                        ee.emit(conditions);
                                    }
                                });
                            }, function (e) {
                                throw e;
                            });
                        }
                    });
                    return deferred;
                };
                ConditionService.prototype.get = function (group, key, cb) {
                    var _this = this;
                    if (cb === void 0) { cb = null; }
                    this._ref.child(key).once('value', function (conditionSnap) {
                        var model = _this.fromSnapshot(group, conditionSnap, function (model) {
                            cb(model);
                        });
                    }, function (e) {
                        throw e;
                    });
                };
                ConditionService.prototype.add = function (model, cb) {
                    if (cb === void 0) { cb = noop; }
                    console.log("api.rule-engine.ConditionService", "add", model);
                    if (!model.isValid()) {
                        throw new Error("This should be thrown from a checkValid function on the model, and should provide the info needed to make the user aware of the fix.");
                    }
                    var json = ConditionService.toJson(model);
                    this._ref.push(json, function (e, result) {
                        if (e) {
                            throw e;
                        }
                        model.key = result.key();
                        cb(model);
                    });
                };
                ConditionService.prototype.save = function (model, cb) {
                    if (cb === void 0) { cb = noop; }
                    console.log("api.rule-engine.ConditionService", "save", model);
                    if (!model.isValid()) {
                        throw new Error("This should be thrown from a checkValid function on the model, and should provide the info needed to make the user aware of the fix.");
                    }
                    if (!model.isPersisted()) {
                        this.add(model, cb);
                    }
                    else {
                        var json = ConditionService.toJson(model);
                        this._ref.child(model.key).set(json, function (result) {
                            cb(model);
                        });
                    }
                };
                ConditionService.prototype.remove = function (model, cb) {
                    if (cb === void 0) { cb = noop; }
                    console.log("api.rule-engine.ConditionService", "remove", model);
                    this._ref.child(model.key).remove(function () {
                        cb(model);
                    });
                };
                ConditionService = __decorate([
                    core_1.Injectable(), 
                    __metadata('design:paramtypes', [ApiRoot_1.ApiRoot, ConditionType_1.ConditionTypeService])
                ], ConditionService);
                return ConditionService;
            })();
            exports_1("ConditionService", ConditionService);
        }
    }
});
//# sourceMappingURL=Condition.js.map