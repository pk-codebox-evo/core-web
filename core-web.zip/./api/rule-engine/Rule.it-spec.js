System.register(['../../api/rule-engine/Rule', '../../api/rule-engine/Condition', 'angular2/core', '../../api/persistence/DataStore', '../../api/persistence/RestDataStore', '../../api/persistence/ApiRoot', '../../api/auth/UserModel', '../../api/rule-engine/ConditionType', '../../api/rule-engine/Action', "./ActionType", '../../api/rule-engine/ConditionGroup', "../system/locale/I18n"], function(exports_1) {
    var Rule_1, Condition_1, core_1, DataStore_1, RestDataStore_1, ApiRoot_1, UserModel_1, ConditionType_1, Action_1, ActionType_1, ConditionGroup_1, I18n_1;
    var injector;
    return {
        setters:[
            function (Rule_1_1) {
                Rule_1 = Rule_1_1;
            },
            function (Condition_1_1) {
                Condition_1 = Condition_1_1;
            },
            function (core_1_1) {
                core_1 = core_1_1;
            },
            function (DataStore_1_1) {
                DataStore_1 = DataStore_1_1;
            },
            function (RestDataStore_1_1) {
                RestDataStore_1 = RestDataStore_1_1;
            },
            function (ApiRoot_1_1) {
                ApiRoot_1 = ApiRoot_1_1;
            },
            function (UserModel_1_1) {
                UserModel_1 = UserModel_1_1;
            },
            function (ConditionType_1_1) {
                ConditionType_1 = ConditionType_1_1;
            },
            function (Action_1_1) {
                Action_1 = Action_1_1;
            },
            function (ActionType_1_1) {
                ActionType_1 = ActionType_1_1;
            },
            function (ConditionGroup_1_1) {
                ConditionGroup_1 = ConditionGroup_1_1;
            },
            function (I18n_1_1) {
                I18n_1 = I18n_1_1;
            }],
        execute: function() {
            injector = core_1.Injector.resolveAndCreate([
                ApiRoot_1.ApiRoot,
                I18n_1.I18nService,
                UserModel_1.UserModel,
                Rule_1.RuleService,
                Action_1.ActionService,
                ActionType_1.ActionTypeService,
                ConditionType_1.ConditionTypeService,
                Condition_1.ConditionService,
                ConditionGroup_1.ConditionGroupService,
                new core_1.Provider(DataStore_1.DataStore, { useClass: RestDataStore_1.RestDataStore })
            ]);
            describe('Integration.api.rule-engine.RuleService', function () {
                var ruleService;
                var rulesToRemove;
                beforeEach(function () {
                    ruleService = injector.get(Rule_1.RuleService);
                    rulesToRemove = [];
                });
                afterEach(function () {
                    rulesToRemove.forEach(function (rule) {
                        ruleService.remove(rule);
                    });
                });
                it("Can create a simple rule.", function (done) {
                    var clientRule;
                    clientRule = new Rule_1.RuleModel(null);
                    clientRule.enabled = true;
                    clientRule.name = "TestRule-" + new Date().getTime();
                    ruleService.add(clientRule, function (serverRule) {
                        rulesToRemove.push(serverRule);
                        expect(serverRule.isPersisted()).toBe(true);
                        expect(serverRule.enabled).toBe(true);
                        expect(serverRule.name).toBe(clientRule.name);
                        var randomKey = 'abc_' + Math.round(Math.random() * 1000);
                        serverRule[randomKey] = "The object provided by the observer is the same instance as the one added.";
                        expect(clientRule[randomKey]).toBe(serverRule[randomKey]);
                        done();
                    });
                });
            });
        }
    }
});
//# sourceMappingURL=Rule.it-spec.js.map