System.register(['angular2/core', '../../../api/persistence/DataStore', '../../../api/persistence/RestDataStore', '../../../api/auth/UserModel', '../../../api/persistence/ApiRoot', "./I18n"], function(exports_1) {
    var core_1, DataStore_1, RestDataStore_1, UserModel_1, ApiRoot_1, I18n_1;
    var injector;
    return {
        setters:[
            function (core_1_1) {
                core_1 = core_1_1;
            },
            function (DataStore_1_1) {
                DataStore_1 = DataStore_1_1;
            },
            function (RestDataStore_1_1) {
                RestDataStore_1 = RestDataStore_1_1;
            },
            function (UserModel_1_1) {
                UserModel_1 = UserModel_1_1;
            },
            function (ApiRoot_1_1) {
                ApiRoot_1 = ApiRoot_1_1;
            },
            function (I18n_1_1) {
                I18n_1 = I18n_1_1;
            }],
        execute: function() {
            injector = core_1.Injector.resolveAndCreate([
                UserModel_1.UserModel,
                ApiRoot_1.ApiRoot,
                I18n_1.I18nService,
                new core_1.Provider(DataStore_1.DataStore, { useClass: RestDataStore_1.RestDataStore })
            ]);
            describe('Integration.api.system.locale.I18n', function () {
                var rsrcService;
                beforeEach(function () {
                    rsrcService = injector.get(I18n_1.I18nService);
                });
                it("Can get a specific message.", function (done) {
                    rsrcService.getForLocale('en-US', 'message.comment.success').subscribe(function (rsrc) {
                        expect(rsrc).toBe("Your comment has been saved");
                        rsrcService.get('de', 'message.comment.success').subscribe(function (rsrc) {
                            expect(rsrc).toBe("Ihr Kommentar wurde gespeichert");
                            done();
                        });
                    });
                });
                it("Can get all message under a particular path.", function (done) {
                    rsrcService.getForLocale('en-US', 'message.comment').subscribe(function (rsrc) {
                        expect(rsrc.delete).toBe("Your comment has been delete");
                        expect(rsrc.failure).toBe("Your comment couldn't be created");
                        expect(rsrc.success).toBe("Your comment has been saved");
                        rsrcService.getForLocale('de', 'message.comment').subscribe(function (rsrc) {
                            expect(rsrc.delete).toBe("Ihr Kommentar wurde gelöscht");
                            expect(rsrc.failure).toBe("Ihr Kommentar konnte nicht erstellt werden");
                            expect(rsrc.success).toBe("Ihr Kommentar wurde gespeichert");
                            done();
                        });
                    });
                });
            });
        }
    }
});
//# sourceMappingURL=I18n.it-spec.js.map