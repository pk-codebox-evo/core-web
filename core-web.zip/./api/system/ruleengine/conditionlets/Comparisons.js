System.register(['angular2/core', "../../../persistence/ApiRoot"], function(exports_1) {
    var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
        var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
        if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
        else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
        return c > 3 && r && Object.defineProperty(target, key, r), r;
    };
    var __metadata = (this && this.__metadata) || function (k, v) {
        if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
    };
    var __param = (this && this.__param) || function (paramIndex, decorator) {
        return function (target, key) { decorator(target, key, paramIndex); }
    };
    var core_1, ApiRoot_1;
    var noop, ComparisonsModel, ComparisonService;
    return {
        setters:[
            function (core_1_1) {
                core_1 = core_1_1;
            },
            function (ApiRoot_1_1) {
                ApiRoot_1 = ApiRoot_1_1;
            }],
        execute: function() {
            noop = function () {
                var arg = [];
                for (var _i = 0; _i < arguments.length; _i++) {
                    arg[_i - 0] = arguments[_i];
                }
            };
            ComparisonsModel = (function () {
                function ComparisonsModel(comparisons) {
                    var _this = this;
                    this._comparisons = {};
                    comparisons.forEach(function (comparison) {
                        _this._comparisons[comparison.type] = comparison.label;
                    });
                }
                Object.defineProperty(ComparisonsModel.prototype, "comparisons", {
                    get: function () {
                        return this._comparisons;
                    },
                    enumerable: true,
                    configurable: true
                });
                return ComparisonsModel;
            })();
            exports_1("ComparisonsModel", ComparisonsModel);
            ComparisonService = (function () {
                function ComparisonService(apiRoot) {
                    this.ref = apiRoot.root.child('system/ruleengine/conditionlets/');
                }
                ComparisonService.fromSnapshot = function (snapshot) {
                    return new ComparisonsModel(snapshot.val()[0]);
                };
                ComparisonService.prototype.get = function (conditionletID, cb) {
                    if (cb === void 0) { cb = noop; }
                    this.ref.child(conditionletID).child('comparisons').once('value', function (snap) {
                        var comparisonsModel = ComparisonService.fromSnapshot(snap);
                        cb(comparisonsModel);
                    }, function (e) {
                        throw e;
                    });
                };
                ComparisonService = __decorate([
                    __param(0, core_1.Inject(ApiRoot_1.ApiRoot)), 
                    __metadata('design:paramtypes', [ApiRoot_1.ApiRoot])
                ], ComparisonService);
                return ComparisonService;
            })();
            exports_1("ComparisonService", ComparisonService);
        }
    }
});
//# sourceMappingURL=Comparisons.js.map