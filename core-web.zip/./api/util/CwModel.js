System.register([], function(exports_1) {
    var CwModel;
    return {
        setters:[],
        execute: function() {
            CwModel = (function () {
                function CwModel(key) {
                    if (key === void 0) { key = null; }
                    this.key = key;
                }
                CwModel.prototype.isPersisted = function () {
                    return !!this.key;
                };
                /**
                 * Override me.
                 * @returns {boolean}
                 */
                CwModel.prototype.isValid = function () {
                    return true;
                };
                return CwModel;
            })();
            exports_1("CwModel", CwModel);
        }
    }
});
//# sourceMappingURL=CwModel.js.map