System.register([], function(exports_1) {
    var __extends = (this && this.__extends) || function (d, b) {
        for (var p in b) if (b.hasOwnProperty(p)) d[p] = b[p];
        function __() { this.constructor = d; }
        d.prototype = b === null ? Object.create(b) : (__.prototype = b.prototype, new __());
    };
    var CwModel, CwI18nModel;
    return {
        setters:[],
        execute: function() {
            CwModel = (function () {
                function CwModel(key) {
                    if (key === void 0) { key = null; }
                    this.key = key;
                }
                CwModel.prototype.isPersisted = function () {
                    return !!this.key;
                };
                /**
                 * Override me.
                 * @returns {boolean}
                 */
                CwModel.prototype.isValid = function () {
                    return true;
                };
                return CwModel;
            })();
            exports_1("CwModel", CwModel);
            CwI18nModel = (function (_super) {
                __extends(CwI18nModel, _super);
                function CwI18nModel(key, i18nKey, defaultResources) {
                    if (key === void 0) { key = null; }
                    if (i18nKey === void 0) { i18nKey = null; }
                    if (defaultResources === void 0) { defaultResources = null; }
                    _super.call(this, key);
                    this._i18nKey = i18nKey;
                    this.rsrc = defaultResources ? defaultResources : {};
                }
                Object.defineProperty(CwI18nModel.prototype, "i18nKey", {
                    get: function () {
                        return this._i18nKey;
                    },
                    enumerable: true,
                    configurable: true
                });
                return CwI18nModel;
            })(CwModel);
            exports_1("CwI18nModel", CwI18nModel);
        }
    }
});
//# sourceMappingURL=CwModel.js.map