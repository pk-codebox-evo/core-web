System.register(["../validation/Verify"], function(exports_1) {
    var __extends = (this && this.__extends) || function (d, b) {
        for (var p in b) if (b.hasOwnProperty(p)) d[p] = b[p];
        function __() { this.constructor = d; }
        d.prototype = b === null ? Object.create(b) : (__.prototype = b.prototype, new __());
    };
    var Verify_1;
    var CwValidationResults, DataTypeModel, Registry, CwInputDefinition, CwSpacerInputDefinition, CwTextInputModel, CwDateTimeInputModel, CwDropdownInputModel, CwRestDropdownInputModel, ParameterDefinition;
    return {
        setters:[
            function (Verify_1_1) {
                Verify_1 = Verify_1_1;
            }],
        execute: function() {
            CwValidationResults = (function () {
                function CwValidationResults(valid) {
                    this.valid = valid;
                }
                return CwValidationResults;
            })();
            exports_1("CwValidationResults", CwValidationResults);
            DataTypeModel = (function () {
                function DataTypeModel(typeDef) {
                    this.type = typeDef.type;
                }
                return DataTypeModel;
            })();
            exports_1("DataTypeModel", DataTypeModel);
            Registry = {};
            CwInputDefinition = (function () {
                function CwInputDefinition(id, name) {
                    this.type = id;
                    this.name = name;
                }
                CwInputDefinition.prototype.verify = function (value) {
                    return new CwValidationResults(true);
                };
                CwInputDefinition.registerType = function (typeId, type) {
                    Registry[typeId] = type;
                };
                CwInputDefinition.fromJson = function (json, name) {
                    var type = Registry[json.id || json.type];
                    if (!type) {
                        var msg = "No input definition registered for '" + (json.id || json.type) + "'";
                        console.error(msg, json);
                        throw new Error(msg);
                    }
                    var m = type.fromJson(json, name);
                    m.placeholder = json.placeholder;
                    m.dataType = json.dataType;
                    return m;
                };
                return CwInputDefinition;
            })();
            exports_1("CwInputDefinition", CwInputDefinition);
            CwSpacerInputDefinition = (function (_super) {
                __extends(CwSpacerInputDefinition, _super);
                function CwSpacerInputDefinition(flex) {
                    _super.call(this, "spacer", null);
                    this.flex = flex;
                }
                return CwSpacerInputDefinition;
            })(CwInputDefinition);
            exports_1("CwSpacerInputDefinition", CwSpacerInputDefinition);
            CwTextInputModel = (function (_super) {
                __extends(CwTextInputModel, _super);
                function CwTextInputModel(id, name) {
                    _super.call(this, id, name);
                    this.minLength = 0;
                    this.maxLength = 255;
                }
                CwTextInputModel.prototype.verify = function (value) {
                    var valid = true;
                    if (this.minLength > 0) {
                        valid = value != null && value.length >= this.minLength;
                    }
                    if (this.maxLength && value) {
                        valid = valid && value.length <= this.maxLength;
                    }
                    return new CwValidationResults(valid);
                };
                CwTextInputModel.fromJson = function (json, name) {
                    var m = new CwTextInputModel(json.id, name);
                    m.minLength = json.dataType.minLength;
                    m.maxLength = json.dataType.maxLength;
                    return m;
                };
                return CwTextInputModel;
            })(CwInputDefinition);
            exports_1("CwTextInputModel", CwTextInputModel);
            CwInputDefinition.registerType("text", CwTextInputModel);
            CwDateTimeInputModel = (function (_super) {
                __extends(CwDateTimeInputModel, _super);
                function CwDateTimeInputModel(id, name) {
                    _super.call(this, id, name);
                }
                CwDateTimeInputModel.prototype.verify = function (value) {
                    return new CwValidationResults(true);
                };
                CwDateTimeInputModel.fromJson = function (json, name) {
                    var m = new CwDateTimeInputModel(json.id, name);
                    return m;
                };
                return CwDateTimeInputModel;
            })(CwInputDefinition);
            exports_1("CwDateTimeInputModel", CwDateTimeInputModel);
            CwInputDefinition.registerType("datetime", CwDateTimeInputModel);
            CwInputDefinition.registerType("number", CwTextInputModel);
            CwDropdownInputModel = (function (_super) {
                __extends(CwDropdownInputModel, _super);
                function CwDropdownInputModel(id, name) {
                    _super.call(this, id, name);
                    this.minSelections = 0;
                    this.maxSelections = 1;
                    this.selected = [];
                }
                CwDropdownInputModel.prototype.verify = function (selections) {
                    var valid = true;
                    if (Verify_1.Verify.isString(selections)) {
                        selections = [selections];
                    }
                    if (this.minSelections > 0) {
                        valid = selections != null && selections.length >= this.minSelections;
                    }
                    if (selections != null) {
                        valid = valid && selections.length <= this.maxSelections;
                    }
                    return new CwValidationResults(valid);
                };
                CwDropdownInputModel.fromJson = function (json, name) {
                    var m = new CwDropdownInputModel(json.id, name);
                    m.options = json.options;
                    m.allowAdditions = json.allowAdditions;
                    m.minSelections = json.minSelections;
                    m.maxSelections = json.maxSelections;
                    var defV = json.dataType.defaultValue;
                    m.selected = (defV == null || defV === '') ? [] : [defV];
                    return m;
                };
                return CwDropdownInputModel;
            })(CwInputDefinition);
            exports_1("CwDropdownInputModel", CwDropdownInputModel);
            CwInputDefinition.registerType("dropdown", CwDropdownInputModel);
            CwRestDropdownInputModel = (function (_super) {
                __extends(CwRestDropdownInputModel, _super);
                function CwRestDropdownInputModel(id, name) {
                    _super.call(this, id, name);
                    this.minSelections = 0;
                    this.maxSelections = 1;
                    this.selected = [];
                }
                CwRestDropdownInputModel.prototype.verify = function (selections) {
                    var valid = true;
                    if (Verify_1.Verify.isString(selections)) {
                        selections = [selections];
                    }
                    if (this.minSelections > 0) {
                        valid = selections != null && selections.length >= this.minSelections;
                    }
                    if (selections != null) {
                        valid = valid && selections.length <= this.maxSelections;
                    }
                    return new CwValidationResults(valid);
                };
                CwRestDropdownInputModel.fromJson = function (json, name) {
                    var m = new CwRestDropdownInputModel(json.id, name);
                    m.optionUrl = json.optionUrl;
                    m.optionValueField = json.jsonValueField;
                    m.optionLabelField = json.jsonLabelField;
                    m.allowAdditions = json.allowAdditions;
                    m.minSelections = json.minSelections;
                    m.maxSelections = json.maxSelections;
                    var defV = json.dataType.defaultValue;
                    m.selected = (defV == null || defV === '') ? [] : [defV];
                    return m;
                };
                return CwRestDropdownInputModel;
            })(CwInputDefinition);
            exports_1("CwRestDropdownInputModel", CwRestDropdownInputModel);
            CwInputDefinition.registerType("restDropdown", CwRestDropdownInputModel);
            ParameterDefinition = (function () {
                function ParameterDefinition() {
                }
                ParameterDefinition.fromJson = function (json) {
                    var m = new ParameterDefinition;
                    var defV = json.defaultValue;
                    m.defaultValue = (defV == null || defV === '') ? null : defV;
                    m.priority = json.priority;
                    m.key = json.key;
                    m.inputType = CwInputDefinition.fromJson(json.inputType, m.key);
                    m.i18nBaseKey = json.i18nBaseKey;
                    return m;
                };
                return ParameterDefinition;
            })();
            exports_1("ParameterDefinition", ParameterDefinition);
        }
    }
});
//# sourceMappingURL=CwInputModel.js.map