System.register([], function(exports_1) {
    var CwChangeEvent;
    return {
        setters:[],
        execute: function() {
            CwChangeEvent = (function () {
                function CwChangeEvent() {
                }
                return CwChangeEvent;
            })();
            exports_1("CwChangeEvent", CwChangeEvent);
        }
    }
});
//# sourceMappingURL=CwEvent.js.map