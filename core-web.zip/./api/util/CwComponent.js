System.register([], function(exports_1, context_1) {
    "use strict";
    var __moduleName = context_1 && context_1.id;
    var CwComponent;
    return {
        setters:[],
        execute: function() {
            CwComponent = (function () {
                function CwComponent() {
                }
                return CwComponent;
            }());
            exports_1("CwComponent", CwComponent);
        }
    }
});
//# sourceMappingURL=CwComponent.js.map