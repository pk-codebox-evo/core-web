System.register([], function(exports_1) {
    var CwComponent;
    return {
        setters:[],
        execute: function() {
            CwComponent = (function () {
                function CwComponent() {
                }
                return CwComponent;
            })();
            exports_1("CwComponent", CwComponent);
        }
    }
});
//# sourceMappingURL=CwComponent.js.map