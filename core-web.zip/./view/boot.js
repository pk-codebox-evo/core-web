System.register(['angular2/platform/browser', 'angular2/http', '../api/persistence/ApiRoot', "../api/auth/UserModel", "../api/rule-engine/Rule", "../api/rule-engine/Action", "../api/rule-engine/ConditionGroup", "../api/rule-engine/Condition", "../api/system/locale/I18n", "./components/rule-engine/rule-engine.container"], function(exports_1) {
    var browser_1, http_1, ApiRoot_1, UserModel_1, Rule_1, Action_1, ConditionGroup_1, Condition_1, I18n_1, rule_engine_container_1;
    return {
        setters:[
            function (browser_1_1) {
                browser_1 = browser_1_1;
            },
            function (http_1_1) {
                http_1 = http_1_1;
            },
            function (ApiRoot_1_1) {
                ApiRoot_1 = ApiRoot_1_1;
            },
            function (UserModel_1_1) {
                UserModel_1 = UserModel_1_1;
            },
            function (Rule_1_1) {
                Rule_1 = Rule_1_1;
            },
            function (Action_1_1) {
                Action_1 = Action_1_1;
            },
            function (ConditionGroup_1_1) {
                ConditionGroup_1 = ConditionGroup_1_1;
            },
            function (Condition_1_1) {
                Condition_1 = Condition_1_1;
            },
            function (I18n_1_1) {
                I18n_1 = I18n_1_1;
            },
            function (rule_engine_container_1_1) {
                rule_engine_container_1 = rule_engine_container_1_1;
            }],
        execute: function() {
            browser_1.bootstrap(rule_engine_container_1.RuleEngineContainer, [
                ApiRoot_1.ApiRoot,
                I18n_1.I18nService,
                UserModel_1.UserModel,
                Rule_1.RuleService,
                Action_1.ActionService,
                ConditionGroup_1.ConditionGroupService,
                Condition_1.ConditionService,
                http_1.HTTP_PROVIDERS
            ]);
        }
    }
});
//# sourceMappingURL=boot.js.map