System.register(['angular2/platform/browser', 'angular2/core', 'angular2/http', './components/rule-engine/rule-engine', '../api/persistence/ApiRoot', "../api/auth/UserModel", "../api/rule-engine/Rule", "../api/rule-engine/Action", "../api/persistence/RestDataStore", "../api/persistence/DataStore", "../api/rule-engine/ConditionGroup", "../api/rule-engine/ConditionType", "../api/rule-engine/Condition", "../api/system/locale/I18n", "../api/system/ruleengine/conditionlets/Comparisons", "../api/system/ruleengine/conditionlets/Inputs", "../api/rule-engine/ActionType"], function(exports_1) {
    var browser_1, core_1, http_1, rule_engine_1, ApiRoot_1, UserModel_1, Rule_1, Action_1, RestDataStore_1, DataStore_1, ConditionGroup_1, ConditionType_1, Condition_1, I18n_1, Comparisons_1, Inputs_1, ActionType_1;
    return {
        setters:[
            function (browser_1_1) {
                browser_1 = browser_1_1;
            },
            function (core_1_1) {
                core_1 = core_1_1;
            },
            function (http_1_1) {
                http_1 = http_1_1;
            },
            function (rule_engine_1_1) {
                rule_engine_1 = rule_engine_1_1;
            },
            function (ApiRoot_1_1) {
                ApiRoot_1 = ApiRoot_1_1;
            },
            function (UserModel_1_1) {
                UserModel_1 = UserModel_1_1;
            },
            function (Rule_1_1) {
                Rule_1 = Rule_1_1;
            },
            function (Action_1_1) {
                Action_1 = Action_1_1;
            },
            function (RestDataStore_1_1) {
                RestDataStore_1 = RestDataStore_1_1;
            },
            function (DataStore_1_1) {
                DataStore_1 = DataStore_1_1;
            },
            function (ConditionGroup_1_1) {
                ConditionGroup_1 = ConditionGroup_1_1;
            },
            function (ConditionType_1_1) {
                ConditionType_1 = ConditionType_1_1;
            },
            function (Condition_1_1) {
                Condition_1 = Condition_1_1;
            },
            function (I18n_1_1) {
                I18n_1 = I18n_1_1;
            },
            function (Comparisons_1_1) {
                Comparisons_1 = Comparisons_1_1;
            },
            function (Inputs_1_1) {
                Inputs_1 = Inputs_1_1;
            },
            function (ActionType_1_1) {
                ActionType_1 = ActionType_1_1;
            }],
        execute: function() {
            browser_1.bootstrap(rule_engine_1.RuleEngineComponent, [ApiRoot_1.ApiRoot,
                I18n_1.I18nService,
                Comparisons_1.ComparisonService,
                Inputs_1.InputService,
                ActionType_1.ActionTypeService,
                UserModel_1.UserModel,
                Rule_1.RuleService,
                Action_1.ActionService,
                ConditionGroup_1.ConditionGroupService,
                Condition_1.ConditionService,
                ConditionType_1.ConditionTypeService,
                http_1.HTTP_PROVIDERS,
                new core_1.Provider(DataStore_1.DataStore, { useClass: RestDataStore_1.RestDataStore })
            ]);
        }
    }
});
//# sourceMappingURL=boot.js.map