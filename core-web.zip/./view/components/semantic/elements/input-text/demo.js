System.register(['angular2/bootstrap', 'angular2/core', 'angular2/common', './input-text'], function(exports_1) {
    var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
        var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
        if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
        else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
        return c > 3 && r && Object.defineProperty(target, key, r), r;
    };
    var __metadata = (this && this.__metadata) || function (k, v) {
        if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
    };
    var __param = (this && this.__param) || function (paramIndex, decorator) {
        return function (target, key) { decorator(target, key, paramIndex); }
    };
    var bootstrap_1, core_1, common_1, input_text_1;
    var Hero, HeroFormComponent, InputTextModel, App;
    function main() {
        var app = bootstrap_1.bootstrap(App);
        app.then(function (appRef) {
            console.log("Bootstrapped App: ", appRef);
        }).catch(function (e) {
            console.log("Error bootstrapping app: ", e);
            throw e;
        });
        return app;
    }
    exports_1("main", main);
    return {
        setters:[
            function (bootstrap_1_1) {
                bootstrap_1 = bootstrap_1_1;
            },
            function (core_1_1) {
                core_1 = core_1_1;
            },
            function (common_1_1) {
                common_1 = common_1_1;
            },
            function (input_text_1_1) {
                input_text_1 = input_text_1_1;
            }],
        execute: function() {
            Hero = (function () {
                function Hero(id, name, inputname, power, alterEgo) {
                    this.id = id;
                    this.name = name;
                    this.inputname = inputname;
                    this.power = power;
                    this.alterEgo = alterEgo;
                    console.log("New Hero", this.inputname, ' ==> ', inputname);
                }
                return Hero;
            })();
            exports_1("Hero", Hero);
            HeroFormComponent = (function () {
                function HeroFormComponent() {
                    this.powers = ['Really Smart', 'Super Flexible',
                        'Super Hot', 'Weather Changer'];
                    this.model = new Hero(18, 'Dr IQ', "def", this.powers[0], 'Chuck Overstreet');
                    this.submitted = false;
                }
                HeroFormComponent.prototype.onSubmit = function () {
                    this.submitted = true;
                };
                Object.defineProperty(HeroFormComponent.prototype, "diagnostic", {
                    // TODO: Remove this when we're done
                    get: function () {
                        return JSON.stringify(this.model);
                    },
                    enumerable: true,
                    configurable: true
                });
                HeroFormComponent = __decorate([
                    core_1.Component({
                        selector: 'hero-form',
                        directives: [input_text_1.InputText, common_1.CORE_DIRECTIVES, common_1.FORM_DIRECTIVES],
                        styles: ["\n  input.ng-valid[required], input.ng-valid[required] {\n  border-left: 5px solid #42A948; /* green */\n}\n.ng-invalid {\n  border-left: 5px solid #a94442; /* red */\n}"],
                        template: "<div flex layout=\"row\" layout-align=\"center center\">\n  <div flex=\"40\" layout=\"row\" layout-wrap layout-align=\"center center\">\n    <form (ngSubmit)=\"onSubmit()\" #hf=\"ngForm\">\n      <div flex=\"100\" layout=\"row\">{{diagnostic}}</div>\n      <div flex=\"100\" layout-wrap layout=\"row\" class=\"ui attached segment\">\n        <label flex=\"100\" for=\"name\">Name</label>\n        <input flex=\"100\" type=\"text\" required [(ngModel)]=\"model.name\" ngControl=\"name\" #name=\"ngForm\" #spy>\n        <div flex=\"50\" [hidden]=\"hf.form.valid\" class=\"name red basic label\">Name is required</div>\n      </div>\n      <div flex=\"100\" layout-wrap layout=\"row\" class=\"ui attached segment\">\n        <label flex=\"100\" for=\"name\">Text-Input Name</label>\n        <cw-input-text flex=\"100\" [name]=\"model.inputname.name\" required [(ngModel)]=\"model.inputname\" ngControl=\"inputname\" #inputname=\"ngForm\"></cw-input-text>\n        <div flex=\"50\" [hidden]=\"inputname.valid\" [class.ui]=\"!inputname.valid\" class=\"inputname red basic label\">Input-Name is\n          required\n        </div>\n      </div>\n      <div flex=\"100\" layout-wrap layout=\"row\" class=\"ui attached segment\">\n        <label flex=\"100\" for=\"alterEgo\">Alter Ego</label>\n        <input flex=\"100\" type=\"text\" class=\"ui  icon input\" [(ngModel)]=\"model.alterEgo\" ngControl=\"alter-ego\">\n      </div>\n      <div flex=\"100\" layout=\"row\" layout-wrap class=\"ui attached segment\">\n        <label flex=\"100\" for=\"power\">Hero Power</label>\n        <select flex=\"100\" class=\"ui icon input\" required [(ngModel)]=\"model.power\" ngControl=\"power\" #power=\"ngForm\">\n          <option *ngFor=\"#p of powers\" [value]=\"p\">{{p}}</option>\n        </select>\n        <div flex=\"100\" [hidden]=\"power.valid\" [class.ui]=\"!power.valid\" class=\"red basic label\"> Power is required</div>\n      </div>\n      <button type=\"submit\" class=\"btn btn-default\" [disabled]=\"!hf.form.valid\">Submit</button>\n    </form>\n  </div>\n</div>\n  "
                    }), 
                    __metadata('design:paramtypes', [])
                ], HeroFormComponent);
                return HeroFormComponent;
            })();
            exports_1("HeroFormComponent", HeroFormComponent);
            InputTextModel = (function () {
                function InputTextModel(name, placeholder, disabled, icon) {
                    if (name === void 0) { name = null; }
                    if (placeholder === void 0) { placeholder = ''; }
                    if (disabled === void 0) { disabled = null; }
                    if (icon === void 0) { icon = ''; }
                    this.name = !!name ? name : "field-" + new Date().getTime() + Math.floor(Math.random() * 1000);
                    this.placeholder = placeholder;
                    this.disabled = disabled;
                    this.icon = icon || '';
                    if (this.icon.indexOf(' ') == -1 && this.icon.length > 0) {
                        this.icon = (this.icon + ' icon').trim();
                    }
                }
                return InputTextModel;
            })();
            App = (function () {
                function App(id) {
                    this.initDemoValue();
                    this.initDemoDisabled();
                    this.initDemoIcon();
                }
                App.prototype.initDemoValue = function () {
                    var model = new InputTextModel();
                    model.name = "field-" + new Date().getTime() + Math.floor(Math.random() * 1000);
                    model.value = "Costa Rica";
                    this.demoValue = model;
                };
                App.prototype.initDemoDisabled = function () {
                    var model = new InputTextModel();
                    model.name = "field-" + new Date().getTime() + Math.floor(Math.random() * 1000);
                    model.disabled = true;
                    model.placeholder = "Disabled";
                    this.demoDisabled = model;
                };
                App.prototype.initDemoIcon = function () {
                    var model = new InputTextModel();
                    model.name = "field-" + new Date().getTime() + Math.floor(Math.random() * 1000);
                    model.icon = "icon circular search link";
                    model.placeholder = "Icon";
                    this.demoIcon = model;
                };
                App.prototype.customChange = function (event) {
                    console.log("Value of field: " + event.target.value);
                };
                App = __decorate([
                    core_1.Component({
                        selector: 'demo'
                    }),
                    core_1.View({
                        directives: [input_text_1.InputText, HeroFormComponent],
                        template: "\n  <div style=\"margin-top:5em;margin-bottom:5em\">\n    <hero-form></hero-form>\n  </div>\n  <div flex layout=\"row\" layout-wrap>\n  <div flex=\"33\">\n    <h4 class=\"ui top attached inverted header\">Default</h4>\n    <div class=\"ui attached segment\">\n      <cw-input-text></cw-input-text>\n    </div>\n  </div>\n  <div flex=\"33\">\n    <h4 class=\"ui top attached inverted header\">Value</h4>\n    <div class=\"ui attached segment\">\n      <cw-input-text [value]=\"demoValue.value\"></cw-input-text>\n    </div>\n  </div>\n  <div flex=\"33\">\n    <h4 class=\"ui top attached inverted header\">Disabled</h4>\n    <div class=\"ui attached segment\">\n      <cw-input-text [disabled]=\"demoDisabled.disabled\" [value]=\"demoDisabled.value\"></cw-input-text>\n    </div>\n  </div>\n  <div flex=\"33\">\n    <h4 class=\"ui top attached inverted header\">Icon</h4>\n    <div class=\"ui attached segment\">\n      <cw-input-text [model]=\"demoIcon\"></cw-input-text>\n    </div>\n  </div>\n</div>\n\n  "
                    }),
                    __param(0, core_1.Attribute('id')), 
                    __metadata('design:paramtypes', [String])
                ], App);
                return App;
            })();
        }
    }
});
//# sourceMappingURL=demo.js.map