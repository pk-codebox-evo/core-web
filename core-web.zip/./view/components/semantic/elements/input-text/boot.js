System.register(['angular2/platform/browser', './demo'], function(exports_1) {
    var browser_1, demo_1;
    return {
        setters:[
            function (browser_1_1) {
                browser_1 = browser_1_1;
            },
            function (demo_1_1) {
                demo_1 = demo_1_1;
            }],
        execute: function() {
            browser_1.bootstrap(demo_1.App);
        }
    }
});
//# sourceMappingURL=boot.js.map