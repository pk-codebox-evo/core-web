System.register(['angular2/core', 'angular2/common', 'angular2/src/facade/lang'], function(exports_1) {
    var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
        var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
        if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
        else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
        return c > 3 && r && Object.defineProperty(target, key, r), r;
    };
    var __metadata = (this && this.__metadata) || function (k, v) {
        if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
    };
    var core_1, common_1, lang_1;
    var CW_TEXT_VALUE_ACCESSOR, InputDate;
    return {
        setters:[
            function (core_1_1) {
                core_1 = core_1_1;
            },
            function (common_1_1) {
                common_1 = common_1_1;
            },
            function (lang_1_1) {
                lang_1 = lang_1_1;
            }],
        execute: function() {
            CW_TEXT_VALUE_ACCESSOR = lang_1.CONST_EXPR(new core_1.Provider(common_1.NG_VALUE_ACCESSOR, { useExisting: core_1.forwardRef(function () { return InputDate; }), multi: true }));
            /**
             * Angular 2 wrapper around Semantic UI Input Element.
             * @see http://semantic-ui.com/elements/input.html
             */
            InputDate = (function () {
                function InputDate(_renderer, _elementRef) {
                    var _this = this;
                    this._renderer = _renderer;
                    this._elementRef = _elementRef;
                    this.onChange = function (_) {
                        _this.change.emit(_);
                    };
                    this.onTouched = function () {
                    };
                    this.value = InputDate.DEFAULT_VALUE;
                    this.placeholder = "";
                    this.disabled = false;
                    this.focused = false;
                    this.required = false;
                    this.change = new core_1.EventEmitter();
                    this.blur = new core_1.EventEmitter();
                    this.focus = new core_1.EventEmitter();
                }
                InputDate.prototype.ngOnChanges = function (change) {
                    if (change.value && change.value.currentValue === null) {
                        this.value = InputDate.DEFAULT_VALUE;
                    }
                    if (change.placeholder && !change.placeholder.currentValue) {
                        this.placeholder = "Enter an ISO DateTime";
                    }
                    if (change.focused) {
                        var f = change.focused.currentValue === true || change.focused.currentValue == 'true';
                        if (f) {
                            var el = this._elementRef.nativeElement;
                            el.children[0].children[0].focus();
                        }
                        this.focused = false;
                    }
                };
                InputDate.prototype.onBlur = function (value) {
                    this.onTouched();
                    this.blur.emit(value);
                };
                InputDate.prototype.onFocus = function (value) {
                    this.focus.emit(value);
                };
                InputDate.prototype.writeValue = function (value) {
                    this.value = lang_1.isBlank(value) ? '' : value;
                    console.log("writing value: ", value, " ==> ", this.value);
                };
                InputDate.prototype.registerOnChange = function (fn) {
                    var _this = this;
                    this.onChange = function (_) {
                        console.log("Value changed: ", _);
                        fn(_);
                        _this.change.emit(_);
                    };
                };
                InputDate.prototype.registerOnTouched = function (fn) {
                    this.onTouched = function () {
                        console.log("Touched");
                        fn();
                    };
                };
                InputDate._defaultValue = function () {
                    var d = new Date();
                    var off = d.getTimezoneOffset();
                    d.setHours(0);
                    d.setMinutes(0);
                    d.setSeconds(0);
                    d.setMilliseconds(0);
                    d.setMonth(d.getMonth() + 1);
                    d.setDate(1);
                    var r = d.toISOString();
                    r = r.substring(0, r.indexOf('T') + 1);
                    r = r + "00:00:00";
                    return r;
                };
                InputDate.DEFAULT_VALUE = InputDate._defaultValue();
                __decorate([
                    core_1.Input(), 
                    __metadata('design:type', String)
                ], InputDate.prototype, "value", void 0);
                __decorate([
                    core_1.Input(), 
                    __metadata('design:type', String)
                ], InputDate.prototype, "placeholder", void 0);
                __decorate([
                    core_1.Input(), 
                    __metadata('design:type', String)
                ], InputDate.prototype, "icon", void 0);
                __decorate([
                    core_1.Input(), 
                    __metadata('design:type', Boolean)
                ], InputDate.prototype, "disabled", void 0);
                __decorate([
                    core_1.Input(), 
                    __metadata('design:type', Boolean)
                ], InputDate.prototype, "focused", void 0);
                __decorate([
                    core_1.Input(), 
                    __metadata('design:type', Boolean)
                ], InputDate.prototype, "required", void 0);
                __decorate([
                    core_1.Input(), 
                    __metadata('design:type', String)
                ], InputDate.prototype, "errorMessage", void 0);
                __decorate([
                    core_1.Output(), 
                    __metadata('design:type', core_1.EventEmitter)
                ], InputDate.prototype, "change", void 0);
                __decorate([
                    core_1.Output(), 
                    __metadata('design:type', core_1.EventEmitter)
                ], InputDate.prototype, "blur", void 0);
                __decorate([
                    core_1.Output(), 
                    __metadata('design:type', core_1.EventEmitter)
                ], InputDate.prototype, "focus", void 0);
                InputDate = __decorate([
                    core_1.Component({
                        selector: 'cw-input-date',
                        changeDetection: core_1.ChangeDetectionStrategy.OnPush,
                        bindings: [CW_TEXT_VALUE_ACCESSOR]
                    }),
                    core_1.View({
                        template: "\n<div class=\"ui fluid input\" [ngClass]=\"{disabled: disabled, icon: icon, required: required}\">\n  <input type=\"datetime-local\" [value]=\"value\" [placeholder]=\"placeholder\" [disabled]=\"disabled\"\n    [required]=\"required\"\n    (input)=\"onChange($event.target.value)\"\n    (change)=\"$event.stopPropagation(); onChange($event.target.value)\"\n    (blur)=\"$event.stopPropagation(); onBlur($event.target.value)\"\n    (focus)=\"onFocus($event.target.value)\">\n  <i [ngClass]=\"icon\" *ngIf=\"icon\"></i>\n</div>\n  ",
                        directives: [common_1.CORE_DIRECTIVES]
                    }), 
                    __metadata('design:paramtypes', [core_1.Renderer, core_1.ElementRef])
                ], InputDate);
                return InputDate;
            })();
            exports_1("InputDate", InputDate);
        }
    }
});
//# sourceMappingURL=input-date.js.map