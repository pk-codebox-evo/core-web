System.register(['angular2/core', 'angular2/common', './rule-condition-component', '../../../api/persistence/ApiRoot', "../../../api/rule-engine/ConditionGroup", "../../../api/rule-engine/Condition", "../../../api/rule-engine/Rule", "../../../api/rule-engine/ServerSideFieldModel"], function(exports_1) {
    var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
        var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
        if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
        else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
        return c > 3 && r && Object.defineProperty(target, key, r), r;
    };
    var __metadata = (this && this.__metadata) || function (k, v) {
        if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
    };
    var core_1, common_1, rule_condition_component_1, ApiRoot_1, ConditionGroup_1, Condition_1, Rule_1, ServerSideFieldModel_1;
    var ConditionGroupComponent;
    return {
        setters:[
            function (core_1_1) {
                core_1 = core_1_1;
            },
            function (common_1_1) {
                common_1 = common_1_1;
            },
            function (rule_condition_component_1_1) {
                rule_condition_component_1 = rule_condition_component_1_1;
            },
            function (ApiRoot_1_1) {
                ApiRoot_1 = ApiRoot_1_1;
            },
            function (ConditionGroup_1_1) {
                ConditionGroup_1 = ConditionGroup_1_1;
            },
            function (Condition_1_1) {
                Condition_1 = Condition_1_1;
            },
            function (Rule_1_1) {
                Rule_1 = Rule_1_1;
            },
            function (ServerSideFieldModel_1_1) {
                ServerSideFieldModel_1 = ServerSideFieldModel_1_1;
            }],
        execute: function() {
            ConditionGroupComponent = (function () {
                function ConditionGroupComponent(apiRoot, ruleService, groupService, conditionService) {
                    this.change = new core_1.EventEmitter();
                    this.remove = new core_1.EventEmitter();
                    this.apiRoot = apiRoot;
                    this._groupService = groupService;
                    this._conditionService = conditionService;
                    this.groupCollapsed = false;
                    this.conditions = [];
                    this.groupIndex = 0;
                    this.rsrc = ruleService.rsrc;
                }
                ConditionGroupComponent.prototype.ngOnChanges = function (change) {
                    var _this = this;
                    if (change.group) {
                        var group = change.group.currentValue;
                        var groupKeys = Object.keys(group.conditions);
                        if (groupKeys.length === 0) {
                            this.addCondition();
                        }
                        else {
                            this._conditionService.listForGroup(group).subscribe(function (conditions) {
                                console.log("ConditionGroupComponent", "list for group", conditions.length, groupKeys.length, conditions);
                                _this.conditions = conditions;
                                _this.sort();
                            });
                        }
                    }
                };
                ConditionGroupComponent.prototype.addCondition = function () {
                    console.log('Adding condition to ConditionsGroup');
                    var condition = new Condition_1.ConditionModel(null, new ServerSideFieldModel_1.ServerSideTypeModel());
                    condition.priority = this.conditions.length ? this.conditions[this.conditions.length - 1].priority + 1 : 1;
                    condition.owningGroup = this.group;
                    condition.operator = 'AND';
                    this.conditions.push(condition);
                };
                ConditionGroupComponent.prototype.sort = function () {
                    this.conditions.sort(function (a, b) {
                        return a.priority - b.priority;
                    });
                };
                ConditionGroupComponent.prototype._addCondition = function (condition) {
                    if (condition.isValid()) {
                        this._conditionService.add(condition);
                    }
                };
                ConditionGroupComponent.prototype.toggleGroupOperator = function () {
                    this.group.operator = this.group.operator === "AND" ? "OR" : "AND";
                    if (this.group.isPersisted()) {
                        this._groupService.save(this.group);
                    }
                };
                ConditionGroupComponent.prototype.onConditionChange = function (condition) {
                    var _this = this;
                    if (condition.isValid()) {
                        if (condition.isPersisted()) {
                            this._conditionService.save(condition);
                        }
                        else {
                            if (!this.group.isPersisted()) {
                                this._groupService.add(this.group, function (foo) {
                                    _this._conditionService.add(condition, function () {
                                        _this.group.conditions[condition.key] = true;
                                    });
                                });
                            }
                            else {
                                this._conditionService.add(condition, function () {
                                    _this.group.conditions[condition.key] = true;
                                });
                            }
                        }
                    }
                };
                ConditionGroupComponent.prototype.onConditionRemove = function (conditionModel) {
                    var _this = this;
                    this._conditionService.remove(conditionModel, function () {
                        _this.conditions = _this.conditions.filter(function (aryModel) {
                            return aryModel.key != conditionModel.key;
                        });
                        if (_this.conditions.length === 0) {
                            _this.remove.emit(_this.group);
                        }
                    });
                };
                __decorate([
                    core_1.Input(), 
                    __metadata('design:type', ConditionGroup_1.ConditionGroupModel)
                ], ConditionGroupComponent.prototype, "group", void 0);
                __decorate([
                    core_1.Input(), 
                    __metadata('design:type', Number)
                ], ConditionGroupComponent.prototype, "groupIndex", void 0);
                __decorate([
                    core_1.Output(), 
                    __metadata('design:type', core_1.EventEmitter)
                ], ConditionGroupComponent.prototype, "change", void 0);
                __decorate([
                    core_1.Output(), 
                    __metadata('design:type', core_1.EventEmitter)
                ], ConditionGroupComponent.prototype, "remove", void 0);
                ConditionGroupComponent = __decorate([
                    core_1.Component({
                        selector: 'condition-group'
                    }),
                    core_1.View({
                        template: "<div class=\"cw-rule-group\">\n  <div class=\"cw-condition-group-separator\" *ngIf=\"groupIndex === 0\">\n    {{rsrc.inputs.group.whenConditions.label}}\n  </div>\n  <div class=\"cw-condition-group-separator\" *ngIf=\"groupIndex !== 0\">\n    <div class=\"ui basic icon buttons\">\n      <button class=\"ui small button cw-group-operator\" (click)=\"toggleGroupOperator()\">\n        <div>{{group.operator}}</div>\n      </button>\n    </div>\n    <span flex class=\"cw-header-text\">{{rsrc.inputs.group.whenFurtherConditions.label}}</span>\n  </div>\n  <div flex layout=\"column\" class=\"cw-conditions\">\n    <div layout=\"row\"\n         class=\"cw-condition-row\"\n         *ngFor=\"var condition of conditions; var i=index\">\n      <rule-condition flex layout=\"row\"\n                      [condition]=\"condition\"\n                      [index]=\"i\"\n                      (remove)=\"onConditionRemove($event)\"\n                      (change)=\"onConditionChange($event)\"></rule-condition>\n      <div class=\"cw-btn-group cw-add-btn\">\n        <div class=\"ui basic icon buttons\" *ngIf=\"i === (conditions.length - 1)\">\n          <button class=\"cw-button-add-item ui button\" arial-label=\"Add Condition\" (click)=\"addCondition();\" [disabled]=\"!condition.isPersisted()\">\n            <i class=\"plus icon\" aria-hidden=\"true\"></i>\n          </button>\n        </div>\n      </div>\n    </div>\n  </div>\n</div>\n\n",
                        directives: [common_1.CORE_DIRECTIVES, rule_condition_component_1.ConditionComponent]
                    }), 
                    __metadata('design:paramtypes', [ApiRoot_1.ApiRoot, Rule_1.RuleService, ConditionGroup_1.ConditionGroupService, Condition_1.ConditionService])
                ], ConditionGroupComponent);
                return ConditionGroupComponent;
            })();
            exports_1("ConditionGroupComponent", ConditionGroupComponent);
        }
    }
});
//# sourceMappingURL=rule-condition-group-component.js.map