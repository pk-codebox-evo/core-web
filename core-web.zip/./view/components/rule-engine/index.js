System.register(["thirdparty/semantic/dist/semantic.css!", "jquery/jquery", "thirdparty/semantic/dist/semantic.js", "angular-material/angular-material.layouts.css!", "./styles/rule-engine.css!", './rule-engine'], function(exports_1) {
    function exportStar_1(m) {
        var exports = {};
        for(var n in m) {
            if (n !== "default") exports[n] = m[n];
        }
        exports_1(exports);
    }
    return {
        setters:[
            function (_1) {},
            function (_2) {},
            function (_3) {},
            function (_4) {},
            function (_5) {},
            function (rule_engine_1_1) {
                exportStar_1(rule_engine_1_1);
            }],
        execute: function() {
        }
    }
});
//# sourceMappingURL=index.js.map