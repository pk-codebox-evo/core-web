System.register(['angular2/core', 'angular2/common', './condition-types/serverside-condition/serverside-condition', "../../../api/rule-engine/Condition", '../../../view/components/semantic/modules/dropdown/dropdown', "../../../api/rule-engine/ConditionType", "../../../api/rule-engine/ServerSideFieldModel", "../../../api/system/locale/I18n"], function(exports_1) {
    var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
        var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
        if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
        else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
        return c > 3 && r && Object.defineProperty(target, key, r), r;
    };
    var __metadata = (this && this.__metadata) || function (k, v) {
        if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
    };
    var core_1, common_1, serverside_condition_1, Condition_1, dropdown_1, ConditionType_1, ServerSideFieldModel_1, I18n_1;
    var ConditionComponent;
    return {
        setters:[
            function (core_1_1) {
                core_1 = core_1_1;
            },
            function (common_1_1) {
                common_1 = common_1_1;
            },
            function (serverside_condition_1_1) {
                serverside_condition_1 = serverside_condition_1_1;
            },
            function (Condition_1_1) {
                Condition_1 = Condition_1_1;
            },
            function (dropdown_1_1) {
                dropdown_1 = dropdown_1_1;
            },
            function (ConditionType_1_1) {
                ConditionType_1 = ConditionType_1_1;
            },
            function (ServerSideFieldModel_1_1) {
                ServerSideFieldModel_1 = ServerSideFieldModel_1_1;
            },
            function (I18n_1_1) {
                I18n_1 = I18n_1_1;
            }],
        execute: function() {
            ConditionComponent = (function () {
                function ConditionComponent(conditionService, typeService, resources) {
                    var _this = this;
                    this.change = new core_1.EventEmitter();
                    this.remove = new core_1.EventEmitter();
                    this._conditionService = conditionService;
                    this._typeService = typeService;
                    this._types = {};
                    this.condition = new Condition_1.ConditionModel(null, new ServerSideFieldModel_1.ServerSideTypeModel());
                    this.index = 0;
                    typeService.list().subscribe(function (types) {
                        _this.typeDropdown = {
                            placeholder: resources.get("api.sites.ruleengine.rules.inputs.condition.type.placeholder"),
                            options: []
                        };
                        types.forEach(function (type) {
                            _this._types[type.key] = type;
                            var opt = { value: type.key, label: resources.get(type.i18nKey + '.name', type.i18nKey) };
                            _this.typeDropdown.options.push(opt);
                        });
                    });
                }
                ConditionComponent.prototype.ngOnChanges = function (change) {
                    console.log("ConditionComponent", "ngOnChanges", change);
                    if (change.condition) {
                        this.condition = change.condition.currentValue;
                        if (this.typeDropdown && this.condition.type) {
                            this.typeDropdown.value = this.condition.type.key;
                        }
                    }
                };
                ConditionComponent.prototype.onTypeChange = function (value) {
                    this.condition.type = this._types[value];
                    this.change.emit(this.condition);
                };
                ConditionComponent.prototype.toggleOperator = function () {
                    this.condition.operator = this.condition.operator === 'AND' ? 'OR' : 'AND';
                    this.change.emit(this.condition);
                };
                ConditionComponent.prototype.onConditionChange = function (condition) {
                    this.change.emit(condition);
                };
                ConditionComponent.prototype.removeCondition = function () {
                    this.remove.emit(this.condition);
                };
                __decorate([
                    core_1.Input(), 
                    __metadata('design:type', Condition_1.ConditionModel)
                ], ConditionComponent.prototype, "condition", void 0);
                __decorate([
                    core_1.Input(), 
                    __metadata('design:type', Number)
                ], ConditionComponent.prototype, "index", void 0);
                __decorate([
                    core_1.Output(), 
                    __metadata('design:type', core_1.EventEmitter)
                ], ConditionComponent.prototype, "change", void 0);
                __decorate([
                    core_1.Output(), 
                    __metadata('design:type', core_1.EventEmitter)
                ], ConditionComponent.prototype, "remove", void 0);
                ConditionComponent = __decorate([
                    core_1.Component({
                        selector: 'rule-condition',
                        properties: ["condition", "index"]
                    }),
                    core_1.View({
                        template: "\n<div *ngIf=\"typeDropdown != null && condition.type != null\" flex layout=\"row\" class=\"cw-condition cw-entry\">\n  <div class=\"cw-btn-group cw-condition-toggle\">\n    <button class=\"ui basic button cw-button-toggle-operator\" aria-label=\"Swap And/Or\" (click)=\"toggleOperator()\" *ngIf=\"index !== 0\">\n      {{condition.operator}}\n    </button>\n  </div>\n  <cw-input-dropdown\n      flex=\"25\"\n      layout=\"row\"\n      class=\"cw-type-dropdown\"\n      [value]=\"condition.type.key\"\n      placeholder=\"{{typeDropdown.placeholder | async}}\"\n      (change)=\"onTypeChange($event)\">\n       <cw-input-option\n          *ngFor=\"#opt of typeDropdown.options\"\n          [value]=\"opt.value\"\n          [label]=\"opt.label | async\"\n          icon=\"{{opt.icon}}\"></cw-input-option>\n  </cw-input-dropdown>\n  <div flex=\"75\" class=\"cw-condition-row-main\" [ngSwitch]=\"condition.type?.key\">\n    <template [ngSwitchWhen]=\"'NoSelection'\">\n      <div class=\"cw-condition-component\"></div>\n    </template>\n    <template ngSwitchDefault>\n      <cw-serverside-condition class=\"cw-condition-component\"\n                               [model]=\"condition\"\n                               [paramDefs]=\"condition.type.parameters\"\n                               (change)=\"onConditionChange($event)\">\n      </cw-serverside-condition>\n    </template>\n  </div>\n</div>\n<div class=\"cw-btn-group cw-delete-btn\">\n  <div class=\"ui basic icon buttons\">\n    <button class=\"ui button\" aria-label=\"Delete Condition\" (click)=\"removeCondition()\">\n      <i class=\"trash icon\"></i>\n    </button>\n  </div>\n</div>\n",
                        directives: [common_1.CORE_DIRECTIVES,
                            serverside_condition_1.ServersideCondition,
                            dropdown_1.Dropdown,
                            dropdown_1.InputOption
                        ]
                    }), 
                    __metadata('design:paramtypes', [Condition_1.ConditionService, ConditionType_1.ConditionTypeService, I18n_1.I18nService])
                ], ConditionComponent);
                return ConditionComponent;
            })();
            exports_1("ConditionComponent", ConditionComponent);
        }
    }
});
//# sourceMappingURL=rule-condition-component.js.map