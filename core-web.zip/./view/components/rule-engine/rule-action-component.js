System.register(['angular2/core', 'angular2/common', "../../../api/rule-engine/ActionType", "../../../api/rule-engine/Action", "../semantic/modules/dropdown/dropdown", "../../../api/system/locale/I18n", "./condition-types/serverside-condition/serverside-condition"], function(exports_1) {
    var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
        var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
        if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
        else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
        return c > 3 && r && Object.defineProperty(target, key, r), r;
    };
    var __metadata = (this && this.__metadata) || function (k, v) {
        if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
    };
    var core_1, common_1, ActionType_1, Action_1, dropdown_1, I18n_1, serverside_condition_1;
    var RuleActionComponent;
    return {
        setters:[
            function (core_1_1) {
                core_1 = core_1_1;
            },
            function (common_1_1) {
                common_1 = common_1_1;
            },
            function (ActionType_1_1) {
                ActionType_1 = ActionType_1_1;
            },
            function (Action_1_1) {
                Action_1 = Action_1_1;
            },
            function (dropdown_1_1) {
                dropdown_1 = dropdown_1_1;
            },
            function (I18n_1_1) {
                I18n_1 = I18n_1_1;
            },
            function (serverside_condition_1_1) {
                serverside_condition_1 = serverside_condition_1_1;
            }],
        execute: function() {
            RuleActionComponent = (function () {
                function RuleActionComponent(actionService, typeService, resources) {
                    var _this = this;
                    this.change = new core_1.EventEmitter();
                    this.remove = new core_1.EventEmitter();
                    this._types = {};
                    this._actionService = actionService;
                    this._typeService = typeService;
                    this.index = 0;
                    typeService.list().subscribe(function (types) {
                        _this.typeDropdown = {
                            value: "",
                            placeholder: resources.get("api.sites.ruleengine.rules.inputs.action.type.placeholder"),
                            options: []
                        };
                        types.forEach(function (type) {
                            _this._types[type.key] = type;
                            var opt = { value: type.key, label: resources.get(type.i18nKey + '.name', type.i18nKey) };
                            _this.typeDropdown.options.push(opt);
                        });
                    });
                }
                RuleActionComponent.prototype.ngOnChanges = function (change) {
                    if (change.action) {
                        this.action = change.action.currentValue;
                        if (this.typeDropdown && this.action.type) {
                            if (this.action.type.key != 'NoSelection') {
                                this.typeDropdown.value = this.action.type.key;
                            }
                        }
                    }
                };
                RuleActionComponent.prototype.onTypeChange = function (value) {
                    this.action.type = this._types[value];
                    // required to force change detection on child that doesn't reference type.
                    this.action = new Action_1.ActionModel(this.action.key, this.action.type, this.action.owningRule, this.action.priority);
                    this.change.emit(this.action);
                };
                RuleActionComponent.prototype.onActionChange = function (event) {
                    console.log("RuleActionComponent", "onActionChange");
                    this.change.emit(this.action);
                };
                RuleActionComponent.prototype.removeAction = function () {
                    this.remove.emit(this.action);
                };
                __decorate([
                    core_1.Input(), 
                    __metadata('design:type', Action_1.ActionModel)
                ], RuleActionComponent.prototype, "action", void 0);
                __decorate([
                    core_1.Input(), 
                    __metadata('design:type', Number)
                ], RuleActionComponent.prototype, "index", void 0);
                __decorate([
                    core_1.Output(), 
                    __metadata('design:type', core_1.EventEmitter)
                ], RuleActionComponent.prototype, "change", void 0);
                __decorate([
                    core_1.Output(), 
                    __metadata('design:type', core_1.EventEmitter)
                ], RuleActionComponent.prototype, "remove", void 0);
                RuleActionComponent = __decorate([
                    core_1.Component({
                        selector: 'rule-action',
                        template: "<div *ngIf=\"typeDropdown != null\" flex layout=\"row\" class=\"cw-rule-action cw-entry\">\n  <div flex=\"25\" layout=\"row\" class=\"cw-row-start-area\">\n    <cw-input-dropdown\n      flex\n      class=\"cw-type-dropdown\"\n      [value]=\"typeDropdown.value\"\n      placeholder=\"{{typeDropdown.placeholder | async}}\"\n      (change)=\"onTypeChange($event)\">\n        <cw-input-option\n        *ngFor=\"#opt of typeDropdown.options\"\n        [value]=\"opt.value\"\n        [label]=\"opt.label | async\"\n        icon=\"{{opt.icon}}\"></cw-input-option>\n    </cw-input-dropdown>\n  </div>\n  <cw-serverside-condition flex=\"75\"\n                           class=\"cw-condition-component\"\n                           [componentInstance]=\"action\"\n                           (change)=\"onActionChange($event)\">\n  </cw-serverside-condition>\n  <div class=\"cw-btn-group cw-delete-btn\">\n    <div class=\"ui basic icon buttons\">\n      <button class=\"ui button\" aria-label=\"Delete Action\" (click)=\"removeAction()\" [disabled]=\"!action.isPersisted()\">\n        <i class=\"trash icon\"></i>\n      </button>\n    </div>\n  </div>\n</div>", directives: [common_1.CORE_DIRECTIVES,
                            serverside_condition_1.ServersideCondition,
                            dropdown_1.Dropdown,
                            dropdown_1.InputOption
                        ]
                    }), 
                    __metadata('design:paramtypes', [Action_1.ActionService, ActionType_1.ActionTypeService, I18n_1.I18nService])
                ], RuleActionComponent);
                return RuleActionComponent;
            })();
            exports_1("RuleActionComponent", RuleActionComponent);
        }
    }
});
//# sourceMappingURL=rule-action-component.js.map