System.register(['angular2/core', 'angular2/common', './rule-action-component', './rule-condition-group-component', '../../../view/components/input/toggle/InputToggle', "../../../api/rule-engine/Rule", "../../../api/rule-engine/Action", "../../../api/rule-engine/ConditionGroup", "../semantic/modules/dropdown/dropdown", "../semantic/elements/input-text/input-text", "../../../api/rule-engine/ServerSideFieldModel", "../../../api/system/locale/I18n"], function(exports_1) {
    var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
        var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
        if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
        else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
        return c > 3 && r && Object.defineProperty(target, key, r), r;
    };
    var __metadata = (this && this.__metadata) || function (k, v) {
        if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
    };
    var core_1, common_1, rule_action_component_1, rule_condition_group_component_1, InputToggle_1, Rule_1, Action_1, ConditionGroup_1, dropdown_1, input_text_1, ServerSideFieldModel_1, I18n_1;
    var I8N_BASE, rsrc, RuleComponent;
    return {
        setters:[
            function (core_1_1) {
                core_1 = core_1_1;
            },
            function (common_1_1) {
                common_1 = common_1_1;
            },
            function (rule_action_component_1_1) {
                rule_action_component_1 = rule_action_component_1_1;
            },
            function (rule_condition_group_component_1_1) {
                rule_condition_group_component_1 = rule_condition_group_component_1_1;
            },
            function (InputToggle_1_1) {
                InputToggle_1 = InputToggle_1_1;
            },
            function (Rule_1_1) {
                Rule_1 = Rule_1_1;
            },
            function (Action_1_1) {
                Action_1 = Action_1_1;
            },
            function (ConditionGroup_1_1) {
                ConditionGroup_1 = ConditionGroup_1_1;
            },
            function (dropdown_1_1) {
                dropdown_1 = dropdown_1_1;
            },
            function (input_text_1_1) {
                input_text_1 = input_text_1_1;
            },
            function (ServerSideFieldModel_1_1) {
                ServerSideFieldModel_1 = ServerSideFieldModel_1_1;
            },
            function (I18n_1_1) {
                I18n_1 = I18n_1_1;
            }],
        execute: function() {
            I8N_BASE = 'api.sites.ruleengine';
            rsrc = {
                fireOn: {
                    EVERY_PAGE: 'Every Page',
                    ONCE_PER_VISIT: 'Once per visit',
                    ONCE_PER_VISITOR: 'Once per visitor',
                    EVERY_REQUEST: 'Every Request'
                }
            };
            RuleComponent = (function () {
                function RuleComponent(elementRef, ruleService, actionService, groupService, resources) {
                    this.change = new core_1.EventEmitter();
                    this.remove = new core_1.EventEmitter();
                    this.elementRef = elementRef;
                    this.actionService = actionService;
                    this.ruleService = ruleService;
                    this._groupService = groupService;
                    this.resources = resources;
                    this._rsrcCache = {};
                    this.groups = [];
                    this.actions = [];
                    this.hidden = false;
                    this.collapsed = false;
                    this.fireOn = {
                        value: 'EVERY_PAGE',
                        placeholder: this.rsrc('inputs.fireOn.placeholder', "Select One"),
                        options: [
                            { value: 'EVERY_PAGE', label: this.rsrc('inputs.fireOn.options.EveryPage') },
                            { value: 'ONCE_PER_VISIT', label: this.rsrc('inputs.fireOn.options.OncePerVisit') },
                            { value: 'ONCE_PER_VISITOR', label: this.rsrc('inputs.fireOn.options.OncePerVisitor') },
                            { value: 'EVERY_REQUEST', label: this.rsrc('inputs.fireOn.options.EveryRequest') }
                        ]
                    };
                }
                RuleComponent.prototype.rsrc = function (subkey, defVal) {
                    if (defVal === void 0) { defVal = null; }
                    var msgObserver = this._rsrcCache[subkey];
                    if (!msgObserver) {
                        msgObserver = this.resources.get(I8N_BASE + '.rules.' + subkey, defVal);
                        this._rsrcCache[subkey] = msgObserver.map(function (v) {
                            return v;
                        });
                    }
                    return msgObserver;
                };
                RuleComponent.prototype.ngOnChanges = function (change) {
                    var _this = this;
                    if (change.rule) {
                        var rule = change.rule.currentValue;
                        this.rule = rule;
                        if (rule.isPersisted()) {
                            this._groupService.list(rule).subscribe(function (groups) {
                                _this.groups = groups || [];
                                if (_this.groups.length === 0) {
                                    _this.addGroup();
                                }
                                else {
                                    _this.sort();
                                }
                            });
                            this.actionService.list(rule).subscribe(function (actions) {
                                _this.actions = actions || [];
                                if (_this.actions.length === 0) {
                                    _this.addAction();
                                }
                                else {
                                    _this.sort();
                                }
                            });
                            this.fireOn.value = rule.fireOn;
                            this.collapsed = rule.isPersisted();
                        }
                        else {
                            this.addGroup();
                            this.addAction();
                        }
                    }
                };
                RuleComponent.prototype.sort = function () {
                    this.groups.sort(function (a, b) {
                        return a.priority - b.priority;
                    });
                    this.actions.sort(function (a, b) {
                        return a.priority - b.priority;
                    });
                };
                RuleComponent.prototype.toggleCollapsed = function () {
                    this.collapsed = !this.collapsed;
                };
                RuleComponent.prototype.onFireOnChange = function (value) {
                    this.rule.fireOn = value;
                    this.change.emit(this.rule);
                };
                RuleComponent.prototype.handleRuleNameChange = function (name) {
                    console.log("handleRuleNameChange");
                    this.rule.name = name;
                    this.change.emit(this.rule);
                };
                RuleComponent.prototype.handleEnabledToggle = function (enabled) {
                    console.log("RuleComponent", "handleEnabledToggle", enabled);
                    this.rule.enabled = enabled;
                    this.change.emit(this.rule);
                };
                RuleComponent.prototype.addAction = function () {
                    var priority = this.actions.length ? this.actions[this.actions.length - 1].priority + 1 : 1;
                    this.actions.push(new Action_1.ActionModel(null, new ServerSideFieldModel_1.ServerSideTypeModel(), this.rule, priority));
                    this.sort();
                };
                RuleComponent.prototype.onActionChange = function (action) {
                    if (action.isValid()) {
                        if (!action.isPersisted()) {
                            action.owningRule = this.rule;
                            this.actionService.add(action);
                        }
                        else {
                            this.actionService.save(action);
                        }
                    }
                };
                RuleComponent.prototype.onActionRemove = function (action) {
                    if (action.isPersisted()) {
                        this.actionService.remove(action);
                    }
                    this.actions = this.actions.filter(function (aryAction) {
                        return aryAction.key != action.key;
                    });
                    if (this.actions.length === 0) {
                        this.addAction();
                    }
                };
                RuleComponent.prototype.addGroup = function () {
                    var priority = this.groups.length ? this.groups[this.groups.length - 1].priority + 1 : 1;
                    var group = new ConditionGroup_1.ConditionGroupModel(null, this.rule, 'AND', priority);
                    this.groups.push(group);
                    this.sort();
                };
                RuleComponent.prototype.onConditionGroupChange = function (group) {
                };
                RuleComponent.prototype.onConditionGroupRemove = function (group) {
                    this._groupService.remove(group);
                    this.groups = this.groups.filter(function (aryGroup) {
                        return aryGroup.key != group.key;
                    });
                    if (this.groups.length === 0) {
                        this.addGroup();
                    }
                };
                RuleComponent.prototype.removeRule = function (event) {
                    event.stopPropagation();
                    if ((event.altKey && event.shiftKey) || confirm('Are you sure you want delete this rule?')) {
                        this.remove.emit(this.rule);
                    }
                };
                __decorate([
                    core_1.Input(), 
                    __metadata('design:type', Rule_1.RuleModel)
                ], RuleComponent.prototype, "rule", void 0);
                __decorate([
                    core_1.Input(), 
                    __metadata('design:type', Boolean)
                ], RuleComponent.prototype, "hidden", void 0);
                __decorate([
                    core_1.Output(), 
                    __metadata('design:type', core_1.EventEmitter)
                ], RuleComponent.prototype, "change", void 0);
                __decorate([
                    core_1.Output(), 
                    __metadata('design:type', core_1.EventEmitter)
                ], RuleComponent.prototype, "remove", void 0);
                RuleComponent = __decorate([
                    core_1.Component({
                        selector: 'rule'
                    }),
                    core_1.View({
                        template: "<div flex layout=\"column\" class=\"cw-rule\" [class.cw-hidden]=\"hidden\" [class.cw-disabled]=\"!rule.enabled\">\n  <div flex layout=\"row\" class=\"cw-header\" *ngIf=\"!hidden\" (click)=\"toggleCollapsed()\">\n    <div flex=\"70\" layout=\"row\" layout-align=\"start center\" class=\"cw-header-info\" *ngIf=\"!hidden\">\n      <i flex=\"none\" class=\"caret icon cw-rule-caret large\" [class.right]=\"collapsed\" [class.down]=\"!collapsed\" aria-hidden=\"true\"></i>\n      <cw-input-text flex=\"70\"\n                     class=\"cw-rule-name-input\"\n                     (blur)=\"handleRuleNameChange($event)\"\n                     (focus)=\"collapsed = false\"\n                     focused=\"{{rule.key == null}}\"\n                     (click)=\"$event.stopPropagation()\"\n                     name=\"rule-{{rule.key}}-name\"\n                     placeholder=\"{{rsrc('inputs.name.placeholder') | async}}\"\n                     [value]=\"rule.name\">\n      </cw-input-text>\n      <span class=\"cw-fire-on-label\">{{rsrc('inputs.fireOn.label') | async}}</span>\n      <cw-input-dropdown flex=\"none\"\n                         class=\"cw-fire-on-dropdown\"\n                         [value]=\"fireOn.value\"\n                         placeholder=\"{{fireOn.placeholder | async}}\"\n                         (change)=\"onFireOnChange($event)\"\n                         (click)=\"$event.stopPropagation()\">\n        <cw-input-option\n            *ngFor=\"#opt of fireOn.options\"\n            [value]=\"opt.value\"\n            [label]=\"opt.label | async\"\n            icon=\"{{opt.icon}}\"></cw-input-option>\n      </cw-input-dropdown>\n    </div>\n    <div flex=\"30\" layout=\"row\" layout-align=\"end center\" class=\"cw-header-actions\" *ngIf=\"!hidden\">\n      <cw-toggle-input class=\"cw-input\"\n                       [on-text]=\"rsrc('inputs.onOff.on.label') | async\"\n                       [off-text]=\"rsrc('inputs.onOff.off.label') | async\"\n                       [value]=\"rule.enabled\"\n                       (change)=\"handleEnabledToggle($event)\"\n                       (click)=\"$event.stopPropagation()\">\n      </cw-toggle-input>\n      <div class=\"cw-btn-group\">\n        <div class=\"ui basic icon buttons\">\n          <button class=\"ui button cw-delete-rule\" aria-label=\"Delete Rule\" (click)=\"removeRule($event)\">\n            <i class=\"trash icon\"></i>\n          </button>\n          <button class=\"ui button cw-add-group\" arial-label=\"Add Group\" (click)=\"addGroup(); collapsed=false; $event.stopPropagation()\" [disabled]=\"!rule.isPersisted()\">\n            <i class=\"plus icon\" aria-hidden=\"true\"></i>\n          </button>\n        </div>\n      </div>\n    </div>\n  </div>\n  <div flex class=\"cw-accordion-body\" [class.cw-hidden]=\"collapsed\">\n    <condition-group layout=\"row\" *ngFor=\"var group of groups; var i=index\"\n                     [rule]=\"rule\"\n                     [group]=\"group\"\n                     [groupIndex]=\"i\"\n                     (remove)=\"onConditionGroupRemove($event)\"\n                     (change)=\"onConditionGroupChange($event)\"></condition-group>\n    <div flex layout=\"column\" class=\"cw-action-group\">\n      <div flex class=\"cw-action-separator\">\n        {{rsrc('inputs.action.firesActions') | async}}\n      </div>\n      <div flex layout=\"column\" class=\"cw-rule-actions\">\n        <div flex layout=\"row\" class=\"cw-action-row\" *ngFor=\"var ruleAction of actions; #i=index\">\n          <rule-action flex [action]=\"ruleAction\" [index]=\"i\" (change)=\"onActionChange($event)\" (remove)=\"onActionRemove($event)\"></rule-action>\n          <div class=\"cw-btn-group cw-add-btn\">\n            <div class=\"ui basic icon buttons\" *ngIf=\"i === (actions.length - 1)\">\n              <button class=\"cw-button-add-item ui button\" arial-label=\"Add Action\" (click)=\"addAction();\" [disabled]=\"!ruleAction.isPersisted()\">\n                <i class=\"plus icon\" aria-hidden=\"true\"></i>\n              </button>\n            </div>\n          </div>\n        </div>\n      </div>\n    </div>\n  </div>\n</div>\n",
                        directives: [common_1.CORE_DIRECTIVES, InputToggle_1.InputToggle, rule_action_component_1.RuleActionComponent, rule_condition_group_component_1.ConditionGroupComponent, input_text_1.InputText, dropdown_1.Dropdown, dropdown_1.InputOption]
                    }), 
                    __metadata('design:paramtypes', [core_1.ElementRef, Rule_1.RuleService, Action_1.ActionService, ConditionGroup_1.ConditionGroupService, I18n_1.I18nService])
                ], RuleComponent);
                return RuleComponent;
            })();
            exports_1("RuleComponent", RuleComponent);
        }
    }
});
//# sourceMappingURL=rule-component.js.map