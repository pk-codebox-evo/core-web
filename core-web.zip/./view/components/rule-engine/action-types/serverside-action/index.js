System.register(['babel/polyfill', 'es6-shim', "bootstrap/css/bootstrap.css!", 'zone.js', 'reflect-metadata', './demo'], function(exports_1) {
    var App;
    return {
        setters:[
            function (_1) {},
            function (_2) {},
            function (_3) {},
            function (_4) {},
            function (_5) {},
            function (App_1) {
                App = App_1;
            }],
        execute: function() {
            App.main().then(function () {
                console.log("Loaded Demo.");
            });
            console.log("Loading Demo.");
        }
    }
});
//# sourceMappingURL=index.js.map