System.register(['angular2/core', 'angular2/common', "../../../semantic/elements/input-text/input-text", "../../../../../api/rule-engine/Action"], function(exports_1) {
    var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
        var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
        if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
        else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
        return c > 3 && r && Object.defineProperty(target, key, r), r;
    };
    var __metadata = (this && this.__metadata) || function (k, v) {
        if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
    };
    var core_1, common_1, input_text_1, Action_1;
    var ServersideAction;
    return {
        setters:[
            function (core_1_1) {
                core_1 = core_1_1;
            },
            function (common_1_1) {
                common_1 = common_1_1;
            },
            function (input_text_1_1) {
                input_text_1 = input_text_1_1;
            },
            function (Action_1_1) {
                Action_1 = Action_1_1;
            }],
        execute: function() {
            ServersideAction = (function () {
                function ServersideAction() {
                    this.change = new core_1.EventEmitter();
                    this._inputs = [];
                }
                ServersideAction.prototype.ngOnChanges = function (change) {
                };
                ServersideAction.prototype._updateInputs = function () {
                    var _this = this;
                    this._inputs = [];
                    var paramDefs = this.model.type.parameters;
                    Object.keys(paramDefs).forEach(function (paramKey) {
                        var paramDef = paramDefs[paramKey];
                        _this._inputs.push({ name: paramKey, i18nKey: paramDef.key, value: _this.model.getParameter(paramKey) });
                    });
                };
                //set model(model:ActionModel) {
                //  this._model = model;
                // @todo ggranum
                //this._model.onChange.subscribe((event) => {
                //  if(event.type === 'key' || event.type === 'actionType'){
                //     this._updateInputs()
                //  }
                //})
                //this._updateInputs()
                //}
                //
                //get model():ActionModel {
                //  return this._model
                //}
                ServersideAction.prototype.handleParamValueChange = function (paramKey, event) {
                    this.model.setParameter(paramKey, event.target.value);
                };
                __decorate([
                    core_1.Input(), 
                    __metadata('design:type', Action_1.ActionModel)
                ], ServersideAction.prototype, "model", void 0);
                __decorate([
                    core_1.Output(), 
                    __metadata('design:type', core_1.EventEmitter)
                ], ServersideAction.prototype, "change", void 0);
                ServersideAction = __decorate([
                    core_1.Component({
                        selector: 'cw-serverside-action',
                    }),
                    core_1.View({
                        template: "<div flex layout=\"row\" layout-align=\"start center\" class=\"cw-action-component-body\">\n  <cw-input-text *ngFor=\"var input of _inputs\"\n                 flex\n                 class=\"cw-input\"\n                 (change)=\"handleParamValueChange(input.name, $event)\"\n                 [name]=\"input.name\"\n                 [placeholder]=\"input.i18nKey\"\n                 [value]=\"input.value\">\n  </cw-input-text>\n</div>",
                        directives: [common_1.CORE_DIRECTIVES, input_text_1.InputText]
                    }), 
                    __metadata('design:paramtypes', [])
                ], ServersideAction);
                return ServersideAction;
            })();
            exports_1("ServersideAction", ServersideAction);
        }
    }
});
//# sourceMappingURL=serverside-action.js.map