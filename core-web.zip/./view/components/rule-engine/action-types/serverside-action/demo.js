System.register(['angular2/bootstrap', 'angular2/core', './serverside-action'], function(exports_1) {
    var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
        var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
        if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
        else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
        return c > 3 && r && Object.defineProperty(target, key, r), r;
    };
    var __metadata = (this && this.__metadata) || function (k, v) {
        if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
    };
    var __param = (this && this.__param) || function (paramIndex, decorator) {
        return function (target, key) { decorator(target, key, paramIndex); }
    };
    var bootstrap_1, core_1, serverside_action_1;
    var App;
    function main() {
        var app = bootstrap_1.bootstrap(App);
        app.then(function (appRef) {
            console.log("Bootstrapped App: ", appRef);
        }).catch(function (e) {
            console.log("Error bootstrapping app: ", e);
            throw e;
        });
        return app;
    }
    exports_1("main", main);
    return {
        setters:[
            function (bootstrap_1_1) {
                bootstrap_1 = bootstrap_1_1;
            },
            function (core_1_1) {
                core_1 = core_1_1;
            },
            function (serverside_action_1_1) {
                serverside_action_1 = serverside_action_1_1;
            }],
        execute: function() {
            App = (function () {
                function App(id) {
                    this.demo = {
                        '1': {},
                        '2': {},
                        '3': {
                            headerKeyValue: 'Content-Type',
                            comparatorValue: 'startsWith',
                            comparisonValues: []
                        },
                        '4': {
                            headerKeyValue: 'Accept-Language',
                            comparatorValue: 'contains',
                            comparisonValues: ['en', 'enUS']
                        }
                    };
                }
                App.prototype.updateConditionlet = function (demoId, event) {
                    console.log("Updated: ", demoId, event);
                    this.demo[demoId][event.valueField] = event.value[event.valueField];
                };
                App = __decorate([
                    core_1.Component({
                        selector: 'cw-request-header-demo'
                    }),
                    core_1.View({
                        directives: [serverside_action_1.ServersideAction],
                        template: "\n    <div class=\"panel panel-default\">\n      <div class=\"panel-heading\">1) No values set.</div>\n      <div class=\"panel-body\">\n          <cw-request-header-condition></cw-request-header-condition>\n      </div>\n    </div>\n    <div class=\"panel panel-default\">\n      <div class=\"panel-heading\">2) With initial value set for header-key</div>\n      <div class=\"panel-body\">\n        <cw-request-header-condition header-key-value=\"User-Agent\"></cw-request-header-condition>\n      </div>\n    </div>\n    <div class=\"panel panel-default\">\n      <div class=\"panel-heading\">3) With initial value set for header-key and comparator-value</div>\n      <div class=\"panel-body\">\n        <div class=\"row\">\n          <cw-request-header-condition class=\"col-sm-12\"\n          [header-key-value]=\"demo['3'].headerKeyValue\"\n          [comparator-value]=\"demo['3'].comparatorValue\"\n          (change)=\"updateConditionlet(3, $event)\"\n          ></cw-request-header-condition>\n        </div>\n        <div class=\"row\">\n          <div class=\"col-sm-4\">{{demo['3'].headerKeyValue}}</div><div class=\"col-sm-3\">{{demo['3'].comparatorValue}}</div><div class=\"col-sm-4\">{{demo['3'].comparisonValues}}</div>\n        </div>\n      </div>\n    </div>\n    <div class=\"panel panel-default\">\n      <div class=\"panel-heading\">4) With initial value set for all values.</div>\n        <div class=\"panel-body\">\n        <div class=\"row\">\n          <cw-request-header-condition class=\"col-sm-12\"\n          [header-key-value]=\"demo['4'].headerKeyValue\"\n          [comparator-value]=\"demo['4'].comparatorValue\"\n          [comparison-values]=\"demo['4'].comparisonValues\"\n          (change)=\"updateConditionlet(4, $event)\"\n          ></cw-request-header-condition>\n        </div>\n        <div class=\"row\">\n          <div class=\"col-sm-4\">{{demo['4'].headerKeyValue}}</div><div class=\"col-sm-3\">{{demo['4'].comparatorValue}}</div><div class=\"col-sm-4\">{{demo['4'].comparisonValues}}</div>\n        </div>\n      </div>\n    </div>\n\n  "
                    }),
                    __param(0, core_1.Attribute('id')), 
                    __metadata('design:paramtypes', [String])
                ], App);
                return App;
            })();
        }
    }
});
//# sourceMappingURL=demo.js.map