var __extends = (this && this.__extends) || function (d, b) {
    for (var p in b) if (b.hasOwnProperty(p)) d[p] = b[p];
    function __() { this.constructor = d; }
    d.prototype = b === null ? Object.create(b) : (__.prototype = b.prototype, new __());
};
/**
 *  Imports are not working for local class files. Until Protractor is updated or another fix is found, all e2e tests will have to be implemented in this file.
 */
/* Begin paste of CwProtractor.ts file:  */
var TestUtil = (function () {
    function TestUtil() {
    }
    // A Protracterized httpGet() promise [curtesy of Leo Galluci ,
    // http://stackoverflow.com/questions/25137881/how-to-use-protractor-to-get-the-response-status-code-and-response-text
    TestUtil.httpGet = function (siteUrl) {
        //noinspection TypeScriptUnresolvedFunction
        var http = require('http');
        var defer = protractor.promise.defer();
        http.get(siteUrl, function (response) {
            var bodyString = '';
            response.setEncoding('utf8');
            response.on("data", function (chunk) {
                bodyString += chunk;
            });
            response.on('end', function () {
                defer.fulfill({
                    response: response,
                    statusCode: response.statusCode,
                    bodyString: bodyString
                });
            });
        }).on('error', function (e) {
            defer.reject("Got http.get error: " + e.message);
        });
        return defer.promise;
    };
    return TestUtil;
})();
var Page = (function () {
    function Page(url, title) {
        this.url = url;
        this.title = title;
    }
    Page.prototype.navigateTo = function () {
        browser.get(this.url);
        expect(browser.getTitle()).toEqual(this.title);
        return this;
    };
    Page.logBrowserConsole = function () {
        browser.manage().logs().get('browser').then(function (browserLog) {
            //noinspection TypeScriptUnresolvedFunction
            console.log('log: ' + require('util').inspect(browserLog));
        });
    };
    return Page;
})();
var TestButton = (function () {
    function TestButton(el) {
        this.el = el;
    }
    TestButton.prototype.click = function () {
        this.el.click();
    };
    return TestButton;
})();
var TestInputComponent = (function () {
    function TestInputComponent(el) {
        this.el = el;
    }
    return TestInputComponent;
})();
var TestInputText = (function (_super) {
    __extends(TestInputText, _super);
    function TestInputText(el) {
        _super.call(this, el);
        this.valueInput = this.el.element(by.tagName('INPUT'));
        this.icon = this.el.element(by.tagName('I'));
    }
    TestInputText.prototype.focus = function () {
        return this.valueInput.click();
    };
    TestInputText.prototype.placeholder = function () {
        return this.valueInput.getAttribute('placeholder');
    };
    TestInputText.prototype.getValue = function () {
        return this.valueInput.getAttribute('value');
    };
    TestInputText.prototype.setValue = function (value) {
        return this.valueInput.sendKeys(value);
    };
    return TestInputText;
})(TestInputComponent);
var TestInputDropdown = (function (_super) {
    __extends(TestInputDropdown, _super);
    function TestInputDropdown(root) {
        _super.call(this, root);
        this.search = root.element(by.css('cw-input-dropdown INPUT.search'));
        this.valueInput = root.element(by.css('cw-input-dropdown INPUT[type="hidden"]'));
        this.valueDisplay = root.element(by.css('cw-input-dropdown DIV.text'));
        this.menu = root.element(by.css('[class~="menu"]'));
        this.items = this.menu.all(by.css('[class~="item"]'));
    }
    TestInputDropdown.prototype.setSearch = function (value) {
        return this.search.sendKeys(value);
    };
    TestInputDropdown.prototype.getValueText = function () {
        return this.valueDisplay.getText();
    };
    return TestInputDropdown;
})(TestInputComponent);
var TestInputToggle = (function (_super) {
    __extends(TestInputToggle, _super);
    function TestInputToggle(root) {
        _super.call(this, root);
        this.valueInput = root.element(by.tagName('INPUT'));
        this.button = root.element(by.css('.ui.toggle'));
    }
    TestInputToggle.prototype.toggle = function () {
        return this.button.click();
    };
    TestInputToggle.prototype.setValue = function (enabled) {
        var _this = this;
        return this.value().then(function (b) {
            if (b !== enabled) {
                return _this.toggle();
            }
        });
    };
    TestInputToggle.prototype.value = function () {
        return this.valueInput.getAttribute('value').then(function (v) {
            return v === 'true';
        });
    };
    TestInputToggle.prototype.getValueText = function () {
        return this.valueInput.getText();
    };
    return TestInputToggle;
})(TestInputComponent);
/* End paste of CwProtractor.ts file:  */
var RulePage = (function (_super) {
    __extends(RulePage, _super);
    function RulePage(locale) {
        if (locale === void 0) { locale = null; }
        _super.call(this, 'http://localhost:9000/build/index.html' + (locale != null ? '?locale=' + locale : ''), '(Dev) dotCMS Core-Web');
        this.filterBox = element(by.css('.filter.icon + INPUT'));
        this.addRuleButton = new TestButton(element(by.css('.cw-button-add')));
        this.rules = element.all(by.tagName('rule'));
    }
    RulePage.prototype.ruleCount = function () {
        return this.rules.count();
    };
    return RulePage;
})(Page);
var RobotsTxtPage = (function (_super) {
    __extends(RobotsTxtPage, _super);
    function RobotsTxtPage() {
        _super.call(this, 'http://localhost:8080/robots.txt', '');
    }
    RobotsTxtPage.prototype.getResponseHeader = function (key) {
        var defer = protractor.promise.defer();
        TestUtil.httpGet(this.url).then(function (result) {
            var resp = result.response;
            var headers = resp.headers;
            console.log('Header ', key, ' is ', headers[key]);
            defer.fulfill(headers[key]);
        });
        return defer;
    };
    return RobotsTxtPage;
})(Page);
var TestRuleComponent = (function () {
    function TestRuleComponent(root) {
        this.el = root;
        this.mainBody = root.element(by.css('.cw-accordion-body'));
        this.header = root.element(by.css('.cw-header'));
        this.expandoCaret = this.header.element(by.css('.cw-rule-caret'));
        this.name = new TestInputText(root.element(by.css('.cw-rule-name-input')));
        this.fireOn = new TestInputDropdown(root.element(by.css('.cw-fire-on-dropdown')));
        this.toggleEnable = new TestInputToggle(root.element(by.tagName('cw-toggle-input')));
        this.remove = new TestButton(root.element(by.css('.cw-delete-rule')));
        this.addGroup = new TestButton(root.element(by.css('.cw-add-group')));
        this.conditionGroupEls = root.all(by.tagName('condition-group'));
        this.actionEls = root.all(by.tagName('rule-action'));
    }
    TestRuleComponent.prototype.isShowingBody = function () {
        return this.mainBody.getAttribute('class').then(function (v) {
            return v == null ? false : v.indexOf('cw-hidden') == -1;
        });
    };
    TestRuleComponent.prototype.expand = function () {
        var _this = this;
        return this.isShowingBody().then(function (yup) {
            if (!yup) {
                return _this.expandoCaret.click();
            }
        });
    };
    TestRuleComponent.prototype.firstGroup = function () {
        return new TestConditionGroupComponent(this.conditionGroupEls.first());
    };
    TestRuleComponent.prototype.firstAction = function () {
        return new TestActionComponent(this.actionEls.first());
    };
    return TestRuleComponent;
})();
var TestConditionGroupComponent = (function () {
    function TestConditionGroupComponent(el) {
        this.el = el;
        this.conditionEls = el.all(by.tagName('rule-condition'));
    }
    TestConditionGroupComponent.prototype.first = function () {
        return new TestConditionComponent(this.conditionEls.first());
    };
    return TestConditionGroupComponent;
})();
var TestRuleInputRow = (function () {
    function TestRuleInputRow(el) {
        this.el = el;
        this.typeSelect = new TestInputDropdown(el.element(by.css('.cw-type-dropdown')));
        this.parameterEls = this.el.all(by.css('.cw-input'));
    }
    TestRuleInputRow.prototype.parameters = function () {
        var _this = this;
        return new Promise(function (accept, reject) {
            var ary = [];
            var proms = [];
            _this.parameterEls.each(function (el, idx) {
                var promise = new Promise(function (a, r) {
                    el.getTagName().then(function (name) {
                        var comp = TestRuleInputRow.inputFromElName(el, name);
                        console.log("TestRuleInputRow", "effff", comp);
                        ary.push(comp);
                        a(comp);
                    });
                });
                proms.push(promise);
            });
            Promise.all(proms).then(function (x) {
                console.log('yay', ary);
                accept(ary);
            });
        });
    };
    TestRuleInputRow.inputFromElName = function (el, name) {
        console.log("TestRuleInputRow", "inputFromElName", name);
        var component;
        if (name == 'cw-input-text') {
            component = new TestInputText(el);
        }
        else if (name == 'cw-input-dropdown') {
            component = new TestInputDropdown(el);
        }
        return component;
    };
    return TestRuleInputRow;
})();
var TestParameter = (function () {
    function TestParameter(el) {
        this.el = el;
    }
    return TestParameter;
})();
var TestConditionComponent = (function (_super) {
    __extends(TestConditionComponent, _super);
    function TestConditionComponent(el) {
        _super.call(this, el);
        this.compareDD = new TestInputDropdown(el.element(by.css('.cw-comparator-selector')));
    }
    return TestConditionComponent;
})(TestRuleInputRow);
var TestRequestHeaderCondition = (function (_super) {
    __extends(TestRequestHeaderCondition, _super);
    function TestRequestHeaderCondition(el) {
        _super.call(this, el);
        this.headerKeyTF = new TestInputText(this.parameterEls.first());
        this.headerValueTF = new TestInputText(this.parameterEls.last());
    }
    return TestRequestHeaderCondition;
})(TestConditionComponent);
var TestActionComponent = (function (_super) {
    __extends(TestActionComponent, _super);
    function TestActionComponent(el) {
        _super.call(this, el);
    }
    return TestActionComponent;
})(TestRuleInputRow);
var TestResponseHeaderAction = (function (_super) {
    __extends(TestResponseHeaderAction, _super);
    function TestResponseHeaderAction(el) {
        _super.call(this, el);
        this.headerKeyDD = new TestInputDropdown(this.parameterEls.first());
        this.headerValueTF = new TestInputText(this.parameterEls.last());
    }
    return TestResponseHeaderAction;
})(TestActionComponent);
describe('The Rules Engine', function () {
    var rulePage;
    beforeEach(function () {
        rulePage = new RulePage();
        rulePage.navigateTo();
    });
    it('should have a title.', function () {
        expect(browser.getTitle()).toEqual(rulePage.title);
    });
    it('should have a filter box.', function () {
        rulePage.filterBox.sendKeys("Hello");
        expect(rulePage.filterBox.getAttribute('value')).toEqual('Hello');
    });
    it('should have translations for the filter box placeholder text.', function () {
        rulePage = new RulePage("es").navigateTo();
        expect(rulePage.filterBox.getAttribute('placeholder')).toEqual('Empieza a escribir para filtrar reglas...');
    });
    it('should have an Add Rule button..', function () {
        expect(rulePage.addRuleButton.el).toBeDefined("Add rule button should exist.");
    });
    it('should have an Add Rule button..', function () {
        expect(rulePage.addRuleButton.el).toBeDefined("Add rule button should exist.");
    });
    it('should add a rule when add rule button is clicked.', function () {
        var count1 = rulePage.ruleCount();
        rulePage.addRuleButton.click();
        rulePage.ruleCount().then(function (count2) {
            expect(count1).toEqual(count2 - 1, "Should have added 1 rule.");
        });
        rulePage.navigateTo();
        rulePage.ruleCount().then(function (count3) {
            expect(count1).toEqual(count3, "The rule should not be persisted unless a name was typed.");
        });
    });
    it('should save a rule when a name is typed', function () {
        var count1 = rulePage.ruleCount();
        rulePage.addRuleButton.click();
        var rule = new TestRuleComponent(rulePage.rules.first());
        expect(rule.name.getValue()).toEqual('', "Rule should have been added to the top of the list.");
        var name = "e2e-" + new Date().getTime();
        rule.name.setValue(name);
        rule.fireOn.el.click();
        browser.sleep(250); // async save
        rulePage.navigateTo(); // reload the page
        rulePage.ruleCount().then(function (count2) {
            expect(count1).toEqual(count2 - 1, "The rule should still exist.");
        });
        expect(rule.name.getValue()).toEqual(name, "Rule should still exist, and should still be first.");
    });
    it('should save the fire-on value when changed.', function () {
        var rule = new TestRuleComponent(rulePage.rules.first());
        rule.fireOn.setSearch('every r');
        rule.name.el.click();
        browser.sleep(250); // async save
        rulePage.navigateTo(); // reload the page
        expect(rule.fireOn.getValueText()).toEqual('Every Request', "FireOn value should have been saved and restored.");
    });
    it('should save the enabled value when changed.', function () {
        var rule = new TestRuleComponent(rulePage.rules.first());
        rule.toggleEnable.value().then(function (value) {
            rule.toggleEnable.toggle();
            browser.sleep(500); // async save
            rulePage.navigateTo(); // reload the page
            expect(rule.toggleEnable.value()).toEqual(!value, "Enabled state should have been toggled.");
        });
    });
    it('should expand when the expando icon is clicked.', function () {
        var rule = new TestRuleComponent(rulePage.rules.first());
        rule.expand();
        expect(rule.isShowingBody()).toEqual(true);
    });
    it('should expand when the name field is focused.', function () {
        var rule = new TestRuleComponent(rulePage.rules.first());
        rule.expand();
        expect(rule.isShowingBody()).toEqual(true);
    });
    it('should save a valid condition.', function () {
        rulePage.addRuleButton.click();
        var rule = new TestRuleComponent(rulePage.rules.first());
        var name = "e2e-" + new Date().getTime();
        rule.name.setValue(name);
        rule.fireOn.el.click();
        var conditionDef = new TestRequestHeaderCondition(rule.firstGroup().conditionEls.first());
        conditionDef.typeSelect.setSearch("Request Hea").then(function () {
            rule.fireOn.el.click().then(function () {
                conditionDef.compareDD.setSearch("Is");
                conditionDef.headerValueTF.setValue("AbcDef");
                rule.fireOn.el.click();
                browser.sleep(250); // async save
                rulePage.navigateTo(); // reload the page
                rule.expand().then(function () {
                    expect(rule.firstGroup().first().typeSelect.getValueText()).toEqual("Request Header Value", "Should have persisted.");
                });
            });
        });
        //expect(rule.toggleEnable.value()).toEqual(!value, "Enabled state should have been toggled.")
    });
    it('should save a valid Response Header action.', function () {
        rulePage.addRuleButton.click();
        var rule = new TestRuleComponent(rulePage.rules.first());
        var name = "e2e-" + new Date().getTime();
        rule.name.setValue(name);
        rule.fireOn.el.click();
        var actionDef = new TestRequestHeaderCondition(rule.actionEls.first());
        actionDef.typeSelect.setSearch("Set Response").then(function () {
            rule.fireOn.el.click().then(function () {
                actionDef.headerKeyTF.setValue("key-AbcDef");
                actionDef.headerValueTF.setValue("value-AbcDef");
                rule.fireOn.el.click();
                browser.sleep(500); // async save
                rulePage.navigateTo(); // reload the page
                rule.expand().then(function () {
                    expect(rule.firstAction().typeSelect.getValueText()).toEqual("Set Response Header", "Should have persisted.");
                });
            });
        });
        //expect(rule.toggleEnable.value()).toEqual(!value, "Enabled state should have been toggled.")
    });
    it('should fire when enabled with no condition and one Set Response Header action.', function () {
        rulePage.addRuleButton.click();
        var rule = new TestRuleComponent(rulePage.rules.first());
        var name = "e2e-" + new Date().getTime();
        rule.name.setValue(name);
        rule.fireOn.el.click();
        var actionDef = new TestRequestHeaderCondition(rule.actionEls.first());
        actionDef.typeSelect.setSearch("Set Response").then(function () {
            rule.fireOn.el.click().then(function () {
                var name = 'e2e-header-key-' + new Date().getTime();
                actionDef.headerKeyTF.setValue(name);
                actionDef.headerValueTF.setValue("value-AbcDef");
                rule.fireOn.setSearch("Every Req");
                rule.toggleEnable.setValue(true);
                rule.fireOn.el.click();
                browser.sleep(250).then(function () {
                    var robots = new RobotsTxtPage();
                    var respName = robots.getResponseHeader(name);
                    browser.driver.wait(respName, 1000, 'bummer');
                    expect(respName).toEqual("value-AbcDef");
                });
            });
        });
    });
});
//# sourceMappingURL=rule-engine.e2e.js.map