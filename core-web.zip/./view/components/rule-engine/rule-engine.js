System.register(['angular2/core', 'angular2/common', './rule-component', "../../../api/rule-engine/Rule", "../../../api/system/locale/I18n", "../../../api/util/CwFilter"], function(exports_1) {
    var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
        var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
        if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
        else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
        return c > 3 && r && Object.defineProperty(target, key, r), r;
    };
    var __metadata = (this && this.__metadata) || function (k, v) {
        if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
    };
    var core_1, common_1, rule_component_1, Rule_1, I18n_1, CwFilter_1;
    var I8N_BASE, RuleEngineComponent;
    return {
        setters:[
            function (core_1_1) {
                core_1 = core_1_1;
            },
            function (common_1_1) {
                common_1 = common_1_1;
            },
            function (rule_component_1_1) {
                rule_component_1 = rule_component_1_1;
            },
            function (Rule_1_1) {
                Rule_1 = Rule_1_1;
            },
            function (I18n_1_1) {
                I18n_1 = I18n_1_1;
            },
            function (CwFilter_1_1) {
                CwFilter_1 = CwFilter_1_1;
            }],
        execute: function() {
            I8N_BASE = 'api.sites.ruleengine';
            /**
             *
             */
            RuleEngineComponent = (function () {
                function RuleEngineComponent(ruleService, resources) {
                    var _this = this;
                    this.resources = resources;
                    resources.get(I8N_BASE).subscribe(function (rsrc) {
                    });
                    this.ruleService = ruleService;
                    this.filterText = "";
                    this.rules = [];
                    this._rsrcCache = {};
                    this.ruleService.list().subscribe(function (rules) {
                        _this.rules = rules;
                        _this.sort();
                    });
                    this.status = null;
                    this.getFilteredRulesStatus();
                }
                RuleEngineComponent.prototype.rsrc = function (subkey) {
                    var x = this._rsrcCache[subkey];
                    if (!x) {
                        x = this.resources.get(I8N_BASE + '.rules.' + subkey);
                        this._rsrcCache[subkey] = x;
                    }
                    return x;
                };
                RuleEngineComponent.prototype.sort = function () {
                    this.rules.sort(function (a, b) {
                        return b.priority - a.priority;
                    });
                };
                RuleEngineComponent.prototype.onRuleChange = function (rule) {
                    if (rule.isValid()) {
                        if (rule.isPersisted()) {
                            this.ruleService.save(rule);
                        }
                        else {
                            this.ruleService.add(rule);
                        }
                    }
                    this.getFilteredRulesStatus();
                };
                RuleEngineComponent.prototype.onRuleRemove = function (rule) {
                    if (rule.isPersisted()) {
                        this.ruleService.remove(rule);
                    }
                    this.rules = this.rules.filter(function (arrayRule) {
                        return arrayRule.key !== rule.key;
                    });
                    this.getFilteredRulesStatus();
                };
                RuleEngineComponent.prototype.addRule = function () {
                    var rule = new Rule_1.RuleModel(null);
                    rule.priority = this.rules.length ? this.rules[0].priority + 1 : 1;
                    this.rules.unshift(rule);
                    this.sort();
                };
                RuleEngineComponent.prototype.getFilteredRulesStatus = function () {
                    this.activeRules = 0;
                    for (var i = 0; i < this.rules.length; i++) {
                        if (this.rules[i].enabled) {
                            this.activeRules++;
                        }
                    }
                };
                RuleEngineComponent.prototype.setFieldFilter = function (field, value) {
                    if (value === void 0) { value = null; }
                    // remove old status
                    var re = new RegExp(field + ':[\\w]*');
                    this.filterText = this.filterText.replace(re, ''); // whitespace issues: "blah:foo enabled:false mahRule"
                    if (value !== null) {
                        this.filterText = field + ':' + value + ' ' + this.filterText;
                    }
                };
                RuleEngineComponent.prototype.isFilteringField = function (field, value) {
                    if (value === void 0) { value = null; }
                    var isFiltering;
                    if (value === null) {
                        var re = new RegExp(field + ':[\\w]*');
                        isFiltering = this.filterText.match(re) != null;
                    }
                    else {
                        isFiltering = this.filterText.indexOf(field + ':' + value) >= 0;
                    }
                    return isFiltering;
                };
                RuleEngineComponent.prototype.isFiltered = function (rule) {
                    return CwFilter_1.CwFilter.isFiltered(rule, this.filterText);
                };
                RuleEngineComponent = __decorate([
                    core_1.Component({
                        selector: 'cw-rule-engine'
                    }),
                    core_1.View({
                        template: "<div flex layout=\"column\" class=\"cw-rule-engine\">\n  <div flex layout=\"column\" class=\"cw-header\">\n    <div flex layout=\"row\" layout-align=\"space-between center\">\n      <div flex layout=\"row\" layout-align=\"space-between center\" class=\"ui icon input\">\n        <i class=\"filter icon\"></i>\n        <input class=\"cw-rule-filter\" type=\"text\" placeholder=\"{{rsrc('inputs.filter.placeholder') | async}}\" [value]=\"filterText\" (keyup)=\"filterText = $event.target.value\">\n      </div>\n      <div flex=\"2\"></div>\n      <button class=\"ui button cw-button-add\" aria-label=\"Create a new rule\" (click)=\"addRule()\">\n        <i class=\"plus icon\" aria-hidden=\"true\"></i>{{rsrc('inputs.addRule.label') | async}}\n      </button>\n    </div>\n    <div class=\"cw-filter-links\">\n      <span>{{rsrc('inputs.filter.status.show.label') | async}}:</span>\n      <a href=\"javascript:void(0)\" [ngClass]=\"{'active': !isFilteringField('enabled'),'cw-filter-link': true}\" (click)=\"setFieldFilter('enabled',null)\">{{rsrc('inputs.filter.status.all.label') | async}}</a>\n      <span>&#124;</span>\n      <a href=\"javascript:void(0)\" [ngClass]=\"{'active': isFilteringField('enabled',true),'cw-filter-link': true}\" (click)=\"setFieldFilter('enabled',true)\">{{rsrc('inputs.filter.status.active.label') | async}}</a>\n      <span>&#124;</span>\n      <a href=\"javascript:void(0)\" [ngClass]=\"{'active': isFilteringField('enabled',false),'cw-filter-link': true}\" (click)=\"setFieldFilter('enabled',false)\">{{rsrc('inputs.filter.status.inactive.label') | async}}</a>\n    </div>\n  </div>\n\n  <rule flex layout=\"row\" *ngFor=\"var r of rules\" [rule]=\"r\" [hidden]=\"isFiltered(r) == true\"\n        (change)=\"onRuleChange($event)\"\n        (remove)=\"onRuleRemove($event)\"></rule>\n</div>\n\n",
                        directives: [common_1.CORE_DIRECTIVES, rule_component_1.RuleComponent]
                    }), 
                    __metadata('design:paramtypes', [Rule_1.RuleService, I18n_1.I18nService])
                ], RuleEngineComponent);
                return RuleEngineComponent;
            })();
            exports_1("RuleEngineComponent", RuleEngineComponent);
        }
    }
});
//# sourceMappingURL=rule-engine.js.map