System.register(['angular2/core', 'angular2/common', '../../../../../view/components/semantic/modules/dropdown/dropdown', "../../../semantic/elements/input-text/input-text", "../../../semantic/elements/input-date/input-date", "../../../../../api/rule-engine/ServerSideFieldModel", "../../../../../api/system/locale/I18n", "../../../../../api/util/ObservableHack", "../../../semantic/modules/restdropdown/RestDropdown"], function(exports_1) {
    var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
        var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
        if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
        else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
        return c > 3 && r && Object.defineProperty(target, key, r), r;
    };
    var __metadata = (this && this.__metadata) || function (k, v) {
        if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
    };
    var core_1, common_1, dropdown_1, input_text_1, input_date_1, ServerSideFieldModel_1, I18n_1, ObservableHack_1, RestDropdown_1;
    var ServersideCondition;
    return {
        setters:[
            function (core_1_1) {
                core_1 = core_1_1;
            },
            function (common_1_1) {
                common_1 = common_1_1;
            },
            function (dropdown_1_1) {
                dropdown_1 = dropdown_1_1;
            },
            function (input_text_1_1) {
                input_text_1 = input_text_1_1;
            },
            function (input_date_1_1) {
                input_date_1 = input_date_1_1;
            },
            function (ServerSideFieldModel_1_1) {
                ServerSideFieldModel_1 = ServerSideFieldModel_1_1;
            },
            function (I18n_1_1) {
                I18n_1 = I18n_1_1;
            },
            function (ObservableHack_1_1) {
                ObservableHack_1 = ObservableHack_1_1;
            },
            function (RestDropdown_1_1) {
                RestDropdown_1 = RestDropdown_1_1;
            }],
        execute: function() {
            ServersideCondition = (function () {
                function ServersideCondition(resources) {
                    this._resources = resources;
                    this.change = new core_1.EventEmitter();
                    this._inputs = [];
                }
                ServersideCondition.prototype.setVisible = function (value, input) {
                    if (value && input && input.name === 'comparison') {
                        var idx = this._inputs.indexOf(input);
                        var comparisonObj = input.options.filter(function (e) { return e.value == value; })[0];
                        if (comparisonObj && comparisonObj.value) {
                            for (var i = idx + 1; i < this._inputs.length; i++) {
                                this._inputs[i].visible = (i <= idx + comparisonObj.rightHandArgCount);
                            }
                        }
                    }
                };
                ServersideCondition.prototype.ngOnChanges = function (change) {
                    var _this = this;
                    if (change.paramDefs) {
                        var prevPriority = 0;
                        this._inputs = [];
                        var comparison;
                        Object.keys(this.paramDefs).forEach(function (key) {
                            var paramDef = _this.model.getParameterDef(key);
                            var param = _this.model.getParameter(key);
                            if (paramDef.priority > (prevPriority + 1)) {
                                _this._inputs.push({ type: 'spacer', flex: 40 });
                            }
                            prevPriority = paramDef.priority;
                            var input = _this.getInputFor(paramDef.inputType.type, param, paramDef);
                            if (input.name === 'comparison') {
                                comparison = input;
                            }
                            _this._inputs.push(input);
                        });
                        this._inputs.forEach(function (input) {
                            _this.setVisible(input.value, comparison);
                        });
                    }
                };
                ServersideCondition.prototype.getInputFor = function (type, param, paramDef) {
                    var i18nBaseKey = paramDef.i18nBaseKey || this.model.type.i18nKey;
                    /* Save a potentially large number of requests by loading parent key: */
                    this._resources.get(i18nBaseKey).subscribe(function () { });
                    var input;
                    if (type === 'text' || type === 'number') {
                        input = this.getTextInput(param, paramDef, i18nBaseKey);
                    }
                    else if (type === 'datetime') {
                        input = this.getDateTimeInput(param, paramDef, i18nBaseKey);
                    }
                    else if (type === 'restDropdown') {
                        input = this.getRestDropdownInput(param, paramDef, i18nBaseKey);
                    }
                    else if (type === 'dropdown') {
                        input = this.getDropdownInput(param, paramDef, i18nBaseKey);
                    }
                    input.type = type;
                    return input;
                };
                ServersideCondition.prototype.getTextInput = function (param, paramDef, i18nBaseKey) {
                    var rsrcKey = i18nBaseKey + '.inputs.' + paramDef.key;
                    var placeholderKey = rsrcKey + '.placeholder';
                    return {
                        name: param.key,
                        placeholder: this._resources.get(placeholderKey, paramDef.key),
                        value: this.model.getParameterValue(param.key),
                        required: paramDef.inputType.dataType['minLength'] > 0,
                        visible: true,
                    };
                };
                ;
                ServersideCondition.prototype.getDateTimeInput = function (param, paramDef, i18nBaseKey) {
                    var rsrcKey = i18nBaseKey + '.inputs.' + paramDef.key;
                    return {
                        name: param.key,
                        value: this.model.getParameterValue(param.key),
                        required: paramDef.inputType.dataType['minLength'] > 0,
                        visible: true
                    };
                };
                ServersideCondition.prototype.getRestDropdownInput = function (param, paramDef, i18nBaseKey) {
                    var inputType = paramDef.inputType;
                    var rsrcKey = i18nBaseKey + '.inputs.' + paramDef.key;
                    var placeholderKey = rsrcKey + '.placeholder';
                    var currentValue = this.model.getParameterValue(param.key);
                    var input = {
                        value: currentValue,
                        name: param.key,
                        placeholder: this._resources.get(placeholderKey, paramDef.key),
                        optionUrl: inputType.optionUrl,
                        optionValueField: inputType.optionValueField,
                        optionLabelField: inputType.optionLabelField,
                        minSelections: inputType.minSelections,
                        maxSelections: inputType.maxSelections,
                        required: inputType.minSelections > 0,
                        allowAdditions: inputType.allowAdditions,
                        visible: true,
                    };
                    if (!input.value) {
                        input.value = inputType.selected != null ? inputType.selected : '';
                    }
                    return input;
                };
                ServersideCondition.prototype.getDropdownInput = function (param, paramDef, i18nBaseKey) {
                    var _this = this;
                    var inputType = paramDef.inputType;
                    var opts = [];
                    var options = inputType.options;
                    var rsrcKey = i18nBaseKey + '.inputs.' + paramDef.key;
                    var placeholderKey = rsrcKey + '.placeholder';
                    if (param.key == 'comparison') {
                        rsrcKey = 'api.sites.ruleengine.rules.inputs.comparison';
                    }
                    else {
                        rsrcKey = rsrcKey + '.options';
                    }
                    var currentValue = this.model.getParameterValue(param.key);
                    var needsCustomAttribute = currentValue != null;
                    Object.keys(options).forEach(function (key) {
                        var option = options[key];
                        if (needsCustomAttribute && key == currentValue) {
                            needsCustomAttribute = false;
                        }
                        var labelKey = rsrcKey + '.' + option.i18nKey;
                        // hack for country - @todo ggranum: kill 'name' on locale?
                        if (param.key === 'country') {
                            labelKey = i18nBaseKey + '.' + option.i18nKey + '.name';
                        }
                        opts.push({
                            value: key,
                            label: _this._resources.get(labelKey, option.i18nKey),
                            icon: option.icon,
                            rightHandArgCount: option.rightHandArgCount
                        });
                    });
                    if (needsCustomAttribute) {
                        opts.push({
                            value: currentValue,
                            label: ObservableHack_1.ObservableHack.of(currentValue)
                        });
                    }
                    var input = {
                        value: currentValue,
                        name: param.key,
                        placeholder: this._resources.get(placeholderKey, paramDef.key),
                        options: opts,
                        minSelections: inputType.minSelections,
                        maxSelections: inputType.maxSelections,
                        required: inputType.minSelections > 0,
                        allowAdditions: inputType.allowAdditions,
                        visible: true,
                    };
                    if (!input.value) {
                        input.value = inputType.selected != null ? inputType.selected : '';
                    }
                    return input;
                };
                ServersideCondition.prototype.handleParamValueChange = function (value, input) {
                    this.model.setParameter(input.name, value);
                    this.change.emit(this.model);
                };
                __decorate([
                    core_1.Input(), 
                    __metadata('design:type', ServerSideFieldModel_1.ServerSideFieldModel)
                ], ServersideCondition.prototype, "model", void 0);
                __decorate([
                    core_1.Input(), 
                    __metadata('design:type', Object)
                ], ServersideCondition.prototype, "paramDefs", void 0);
                __decorate([
                    core_1.Output(), 
                    __metadata('design:type', core_1.EventEmitter)
                ], ServersideCondition.prototype, "change", void 0);
                ServersideCondition = __decorate([
                    core_1.Component({
                        selector: 'cw-serverside-condition'
                    }),
                    core_1.View({
                        directives: [common_1.CORE_DIRECTIVES, RestDropdown_1.RestDropdown, dropdown_1.Dropdown, dropdown_1.InputOption, input_text_1.InputText, input_date_1.InputDate],
                        template: "<div flex layout=\"row\" class=\"cw-condition-component-body\">\n  <template ngFor #input [ngForOf]=\"_inputs\" #islast=\"last\">\n    <div *ngIf=\"input.type == 'spacer'\" flex class=\"cw-input cw-input-placeholder\">&nbsp;</div>\n    <cw-input-dropdown *ngIf=\"input.type == 'dropdown'\"\n                       flex\n                       class=\"cw-input\"\n                       [value]=\"input.value\"\n                       placeholder=\"{{input.placeholder | async}}\"\n                       [required]=\"input.required\"\n                       [allowAdditions]=\"input.allowAdditions\"\n                       [class.cw-comparator-selector]=\"input.name == 'comparison'\"\n                       [class.cw-last]=\"islast\"\n                       [hidden]=\"!input.visible\"\n                       (change)=\"setVisible($event, input); handleParamValueChange($event, input)\">\n                       <cw-input-option\n            *ngFor=\"#opt of input.options\"\n            [value]=\"opt.value\"\n            [label]=\"opt.label | async\"\n            icon=\"{{opt.icon}}\"></cw-input-option>\n    </cw-input-dropdown>\n\n    <cw-input-rest-dropdown *ngIf=\"input.type == 'restDropdown'\"\n                       flex\n                       class=\"cw-input\"\n                       [value]=\"input.value\"\n                       placeholder=\"{{input.placeholder | async}}\"\n                       optionUrl=\"{{input.optionUrl}}\"\n                       optionValueField=\"{{input.optionValueField}}\"\n                       optionLabelField=\"{{input.optionLabelField}}\"\n                       [required]=\"input.required\"\n                       [allowAdditions]=\"input.allowAdditions\"\n                       [class.cw-comparator-selector]=\"input.name == 'comparison'\"\n                       [class.cw-last]=\"islast\"\n                       (change)=\"handleParamValueChange($event, input)\">\n    </cw-input-rest-dropdown>\n\n    <cw-input-text *ngIf=\"input.type == 'text' || input.type == 'number'\"\n                   flex\n                   class=\"cw-input\"\n                   [class.cw-last]=\"islast\"\n                   [required]=\"input.required\"\n                   [name]=\"input.name\"\n                   [placeholder]=\"input.placeholder | async\"\n                   [value]=\"input.value\"\n                   [type]=\"input.type\"\n                   [hidden]=\"!input.visible\"\n                   (blur)=\"handleParamValueChange($event, input)\"></cw-input-text>\n\n    <cw-input-date *ngIf=\"input.type == 'datetime' \"\n                    flex\n                    layout-fill\n                    class=\"cw-input\"\n                    [class.cw-last]=\"islast\"\n                    [required]=\"input.required\"\n                    [name]=\"input.name\"\n                    [placeholder]=\"input.placeholder | async\"\n                    type=\"datetime-local\"\n                    [hidden]=\"!input.visible\"\n                    [value]=\"input.value\"\n                    (blur)=\"handleParamValueChange($event, input)\"></cw-input-date>\n  </template>\n</div>"
                    }), 
                    __metadata('design:paramtypes', [I18n_1.I18nService])
                ], ServersideCondition);
                return ServersideCondition;
            })();
            exports_1("ServersideCondition", ServersideCondition);
        }
    }
});
//# sourceMappingURL=serverside-condition.js.map