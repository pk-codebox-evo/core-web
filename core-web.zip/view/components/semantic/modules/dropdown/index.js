require('babel/polyfill');
require('es6-shim');
require("thirdparty/semantic/dist/semantic.min.css!");
require('zone.js');
require('reflect-metadata');
var App = require('./demo');
App.main().then(function () {
    console.log("Loaded Demo.");
});
console.log("Loading Demo.");
