var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") return Reflect.decorate(decorators, target, key, desc);
    switch (arguments.length) {
        case 2: return decorators.reduceRight(function(o, d) { return (d && d(o)) || o; }, target);
        case 3: return decorators.reduceRight(function(o, d) { return (d && d(target, key)), void 0; }, void 0);
        case 4: return decorators.reduceRight(function(o, d) { return (d && d(target, key, o)) || o; }, desc);
    }
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
var __param = (this && this.__param) || function (paramIndex, decorator) {
    return function (target, key) { decorator(target, key, paramIndex); }
};
var angular2_1 = require('angular2/angular2');
//import * as Rx from '../../../../../../node_modules/angular2/node_modules/@reactivex/rxjs/src/Rx.KitchenSink'
/**
 * Angular 2 wrapper around Semantic UI Dropdown Module.
 * @see http://semantic-ui.com/modules/dropdown.html#/usage
 * Comments for event handlers, etc, copied directly from semantic-ui documentation.
 *
 * @todo ggranum: Extract semantic UI components into a separate github repo and include them via npm.
 */
var $ = window['$'];
var DO_NOT_SEARCH_ON_THESE_KEY_EVENTS = {
    8: 'backspace',
    188: 'comma',
    46: 'deleteKey',
    13: 'enter',
    27: 'escape',
    33: 'pageUp',
    34: 'pageDown',
    37: 'leftArrow',
    38: 'upArrow',
    39: 'rightArrow',
    40: 'downArrow',
};
/**
 *
 */
var DropdownOption = (function () {
    function DropdownOption(valueId, value, label, icon) {
        if (value === void 0) { value = null; }
        if (label === void 0) { label = null; }
        if (icon === void 0) { icon = null; }
        this.id = valueId;
        this.value = value || valueId;
        this.label = label || valueId;
        this.icon = icon || '';
        if (!this.icon.includes(' ') && this.icon.length > 0) {
            this.icon = (this.icon + ' icon').trim();
        }
    }
    return DropdownOption;
})();
exports.DropdownOption = DropdownOption;
var DropdownModel = (function () {
    function DropdownModel(name, placeholder, selected, options) {
        if (name === void 0) { name = null; }
        if (placeholder === void 0) { placeholder = ''; }
        if (selected === void 0) { selected = []; }
        if (options === void 0) { options = []; }
        this.name = !!name ? name : "field-" + new Date().getTime() + Math.floor(Math.random() * 1000);
        this.placeholder = placeholder;
        this.selected = selected;
        this.options = options;
        this.settings = {};
        this._optionChange = new angular2_1.EventEmitter();
        this.onOptionChange = Rx.Observable.from(this._optionChange.toRx()).share();
    }
    DropdownModel.prototype.addOptions = function (options) {
        var _this = this;
        options.forEach(function (option) {
            _this.options.push(option);
        });
        this._optionChange.next({ type: 'add', target: this, value: options });
    };
    DropdownModel.prototype.selectedValues = function () {
        var _this = this;
        return this.selected.map(function (selectedId) {
            var ddOpt = _this.options.filter(function (opt) { return (opt.id == selectedId); })[0];
            if (ddOpt) {
                // if not, then 'selected' is a value that isn't in the list!
                return ddOpt.value;
            }
        });
    };
    return DropdownModel;
})();
exports.DropdownModel = DropdownModel;
var Dropdown = (function () {
    function Dropdown(elementRef) {
        this.elementRef = elementRef;
        this.change = new angular2_1.EventEmitter();
        this.model = new DropdownModel();
        this.updateView = false;
    }
    Object.defineProperty(Dropdown.prototype, "model", {
        get: function () {
            return this._model;
        },
        set: function (model) {
            var _this = this;
            if (this.optionWatch) {
                this.optionWatch.unsubscribe();
                this.optionWatch = null;
            }
            this._model = model;
            this.optionWatch = this._model.onOptionChange.subscribe(function () {
                _this.updateView = true;
            });
        },
        enumerable: true,
        configurable: true
    });
    Dropdown.prototype.afterViewInit = function () {
        if (this.model.options.length > 0) {
            this.initDropdown();
        } // else 'wait for options to be set'
    };
    Dropdown.prototype.afterViewChecked = function () {
        if (this.updateView === true) {
            this.updateView = false;
            this.initDropdown();
        }
    };
    Dropdown.prototype.initDropdown = function () {
        var _this = this;
        var self = this;
        var config = {
            onChange: function (value, text, $choice) {
                return _this.onChange(value, text, $choice);
            },
            onAdd: function (addedValue, addedText, $addedChoice) {
                return _this.onAdd(addedValue, addedText, $addedChoice);
            },
            onRemove: function (removedValue, removedText, $removedChoice) {
                return _this.onRemove(removedValue, removedText, $removedChoice);
            },
            onLabelCreate: function (value, text) {
                var $label = this;
                return self.onLabelCreate($label, value, text);
            },
            onLabelSelect: function ($selectedLabels) {
                return _this.onLabelSelect($selectedLabels);
            },
            onNoResults: function (searchValue) {
                return _this.onNoResults(searchValue);
            },
            onShow: function () {
                return _this.onShow();
            },
            onHide: function () {
                return _this.onHide();
            }
        };
        if (this.model.settings.maxSelections) {
            config.maxSelections = this.model.settings.maxSelections;
        }
        var el = this.elementRef.nativeElement;
        var $dropdown = $(el).children('.ui.dropdown');
        $dropdown.dropdown(config);
        this._applyArrowNavFix($dropdown);
    };
    /**
     * Fixes an issue with up and down arrows triggering a search in the dropdown, which auto selects the first result
     * after a short buffering period.
     * @param $dropdown The JQuery dropdown element, after calling #.dropdown(config).
     * @private
     */
    Dropdown.prototype._applyArrowNavFix = function ($dropdown) {
        var $searchField = $dropdown.children('input.search');
        $searchField.on('keyup', function (event) {
            if (DO_NOT_SEARCH_ON_THESE_KEY_EVENTS[event.keyCode]) {
                event.stopPropagation();
            }
        });
    };
    ;
    /**
     * Is called after a dropdown value changes. Receives the name and value of selection and the active menu element
     * @param value
     * @param text
     * @param $choice
     */
    Dropdown.prototype.onChange = function (value, text, $choice) {
        this.model.selected = [value];
        this.change.next({ type: 'toggle', target: this, value: value });
        console.log('onChange', value, text, " Selected: ", this.model.selected);
    };
    /**
     * Is called after a dropdown selection is added using a multiple select dropdown, only receives the added value
     * @param addedValue
     * @param addedText
     * @param $addedChoice
     */
    Dropdown.prototype.onAdd = function (addedValue, addedText, $addedChoice) {
    };
    /**
     * Is called after a dropdown selection is removed using a multiple select dropdown, only receives the removed value
     * @param removedValue
     * @param removedText
     * @param $removedChoice
     */
    Dropdown.prototype.onRemove = function (removedValue, removedText, $removedChoice) {
    };
    /**
     * Allows you to modify a label before it is added. Expects $label to be returned.
     * @param $label
     * @param value
     * @param text
     */
    Dropdown.prototype.onLabelCreate = function ($label, value, text) {
        return $label;
    };
    /**
     * Is called after a label is selected by a user
     * @param $selectedLabels
     */
    Dropdown.prototype.onLabelSelect = function ($selectedLabels) {
    };
    /**
     * Is called after a dropdown is searched with no matching values
     * @param searchValue
     */
    Dropdown.prototype.onNoResults = function (searchValue) {
    };
    /**
     * Is called before a dropdown is shown. If false is returned, dropdown will not be shown.
     */
    Dropdown.prototype.onShow = function () {
    };
    /**
     * Is called before a dropdown is hidden. If false is returned, dropdown will not be hidden.
     */
    Dropdown.prototype.onHide = function () {
    };
    Dropdown = __decorate([
        angular2_1.Component({
            selector: 'cw-input-dropdown',
            properties: [
                'model',
            ], events: [
                "change"
            ]
        }),
        angular2_1.View({
            template: "\n<div class=\"ui fluid selection dropdown search\" [ng-class]=\"{multiple: model.settings.maxSelections}\" tabindex=\"0\">\n  <input type=\"hidden\" [name]=\"model.name\" [value]=\"model.selected.join(',')\" >\n  <i class=\"dropdown icon\"></i>\n  <div class=\"default text\">{{model.placeholder}}</div>\n  <div class=\"menu\" tabindex=\"-1\">\n    <div *ng-for=\"var opt of model.options\" class=\"item\" [attr.data-value]=\"opt.id\" [attr.data-text]=\"opt.label\">\n      <i [ng-class]=\"opt.icon\" ></i>\n      {{opt.label}}\n    </div>\n  </div>\n</div>\n  ",
            directives: [angular2_1.NgClass, angular2_1.NgFor]
        }),
        __param(0, angular2_1.ElementRef), 
        __metadata('design:paramtypes', [angular2_1.ElementRef])
    ], Dropdown);
    return Dropdown;
})();
exports.Dropdown = Dropdown;
//# sourceMappingURL=dropdown.js.map