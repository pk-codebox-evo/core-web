/// <reference path="../../../../../thirdparty/angular2/bundles/typings/angular2/angular2.d.ts" />
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") return Reflect.decorate(decorators, target, key, desc);
    switch (arguments.length) {
        case 2: return decorators.reduceRight(function(o, d) { return (d && d(o)) || o; }, target);
        case 3: return decorators.reduceRight(function(o, d) { return (d && d(target, key)), void 0; }, void 0);
        case 4: return decorators.reduceRight(function(o, d) { return (d && d(target, key, o)) || o; }, desc);
    }
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
var __param = (this && this.__param) || function (paramIndex, decorator) {
    return function (target, key) { decorator(target, key, paramIndex); }
};
var angular2_1 = require('angular2/angular2');
var dropdown_1 = require('./dropdown');
var App = (function () {
    function App(id) {
        this.initDemo2();
        this.initDemo3();
        this.initDemo4();
    }
    App.prototype.initDemo2 = function () {
        var model = new dropdown_1.DropdownModel();
        model.name = "field-" + new Date().getTime() + Math.floor(Math.random() * 1000);
        model.placeholder = "Gender";
        var opts = [
            new dropdown_1.DropdownOption('M', 100, 'Male', 'male'),
            new dropdown_1.DropdownOption('F', 42, 'Female', 'female')
        ];
        model.options = opts;
        this.demo2 = model;
    };
    App.prototype.initDemo3 = function () {
        var model = new dropdown_1.DropdownModel(null, "Color", ["Y"], [
            new dropdown_1.DropdownOption('R', { x: 'red' }, 'Red', 'asterisk'),
            new dropdown_1.DropdownOption('Y', 'yellow', 'Yellow', 'certificate'),
            new dropdown_1.DropdownOption('G', 92, 'Green', 'circle'),
            new dropdown_1.DropdownOption('B', 'blue', 'Blue', 'square'),
            new dropdown_1.DropdownOption('P', 'purple', 'Purple', 'cube')]);
        model.settings.maxSelections = 2;
        this.demo3 = model;
    };
    App.prototype.initDemo4 = function () {
        var model = new dropdown_1.DropdownModel(null, "Color", [], [
            new dropdown_1.DropdownOption('R', 'red', 'Red', 'asterisk'),
            new dropdown_1.DropdownOption('Y', 'yellow', 'Yellow', 'certificate'),
            new dropdown_1.DropdownOption('G', 'green', 'Green', 'circle'),
            new dropdown_1.DropdownOption('B', 'blue', 'Blue', 'square'),
            new dropdown_1.DropdownOption('P', 'purple', 'Purple', 'cube')]);
        model.settings.maxSelections = 4;
        this.demo4 = {
            model: model,
            selected: []
        };
    };
    App.prototype.demo4OnChange = function (event) {
        var dd = event.target.model;
        this.demo4.selected = dd.selected.join(',');
        console.log(dd);
    };
    App = __decorate([
        angular2_1.Component({
            selector: 'demo'
        }),
        angular2_1.View({
            directives: [dropdown_1.Dropdown],
            template: "<div class=\"ui three column grid\">\n  <div class=\"column\">\n    <h4 class=\"ui top attached inverted header\">Default</h4>\n    <div class=\"ui attached segment\">\n      <cw-input-dropdown></cw-input-dropdown>\n    </div>\n  </div>\n  <div class=\"column\">\n    <h4 class=\"ui top attached inverted header\">Simple select, no default selection.</h4>\n    <div class=\"ui attached segment\">\n      <cw-input-dropdown [model]=\"demo2\"></cw-input-dropdown>\n    </div>\n  </div>\n  <div class=\"column\">\n    <h4 class=\"ui top attached inverted header\">Select Multiple, 'Yellow' selected by default.</h4>\n    <div class=\"ui attached segment\">\n      <cw-input-dropdown [model]=\"demo3\" ></cw-input-dropdown>\n    </div>\n  </div>\n  <div class=\"column\">\n    <h4 class=\"ui top attached inverted header\">Change the Text</h4>\n    <div class=\"ui attached segment\">\n      <cw-input-dropdown [model]=\"demo4.model\" (change)=\"demo4OnChange($event)\"></cw-input-dropdown>\n      <div>Selected Ids: <em>{{demo4.selected}}</em></div>\n    </div>\n  </div>\n  <div class=\"column\">\n    <h4 class=\"ui top attached inverted header\">Notify on change</h4>\n    <div class=\"ui buttom attached segment\">\n      <!--<cw-input-dropdown [value]=\"changeDemoValue\" (change)=\"changeDemoValue = $event\"></cw-input-dropdown>-->\n      <!--<span> The value is: {{changeDemoValue}}</span>-->\n    </div>\n  </div>\n</div>\n  "
        }),
        __param(0, angular2_1.Attribute('id')), 
        __metadata('design:paramtypes', [String])
    ], App);
    return App;
})();
function main() {
    var app = angular2_1.bootstrap(App);
    app.then(function (appRef) {
        console.log("Bootstrapped App: ", appRef);
    }).catch(function (e) {
        console.log("Error bootstrapping app: ", e);
        throw e;
    });
    return app;
}
exports.main = main;
//# sourceMappingURL=demo.js.map