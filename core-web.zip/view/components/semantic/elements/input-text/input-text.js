var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") return Reflect.decorate(decorators, target, key, desc);
    switch (arguments.length) {
        case 2: return decorators.reduceRight(function(o, d) { return (d && d(o)) || o; }, target);
        case 3: return decorators.reduceRight(function(o, d) { return (d && d(target, key)), void 0; }, void 0);
        case 4: return decorators.reduceRight(function(o, d) { return (d && d(target, key, o)) || o; }, desc);
    }
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
var __param = (this && this.__param) || function (paramIndex, decorator) {
    return function (target, key) { decorator(target, key, paramIndex); }
};
var angular2_1 = require('angular2/angular2');
/**
 * Angular 2 wrapper around Semantic UI Input Element.
 * @see http://semantic-ui.com/elements/input.html
 */
var InputTextModel = (function () {
    function InputTextModel(name, placeholder, value, disabled, icon) {
        if (name === void 0) { name = null; }
        if (placeholder === void 0) { placeholder = ''; }
        if (value === void 0) { value = null; }
        if (disabled === void 0) { disabled = null; }
        if (icon === void 0) { icon = ''; }
        this.name = !!name ? name : "field-" + new Date().getTime() + Math.floor(Math.random() * 1000);
        this.placeholder = placeholder;
        this.value = value;
        this.disabled = disabled;
        this.icon = icon || '';
        if (!this.icon.includes(' ') && this.icon.length > 0) {
            this.icon = (this.icon + ' icon').trim();
        }
    }
    InputTextModel.prototype.validate = function (value) { };
    ;
    return InputTextModel;
})();
exports.InputTextModel = InputTextModel;
var InputText = (function () {
    function InputText(elementRef) {
        this.elementRef = elementRef;
        this.change = new angular2_1.EventEmitter();
        this._model = new InputTextModel();
        this.errorMessage = null;
    }
    Object.defineProperty(InputText.prototype, "model", {
        get: function () {
            return this._model;
        },
        set: function (model) {
            this._model = model;
        },
        enumerable: true,
        configurable: true
    });
    InputText.prototype.inputChange = function (event) {
        try {
            this.errorMessage = null;
            this._model.value = event.target.value;
            //Check if the validate function exists in this model.
            if (typeof this._model.validate == 'function') {
                this._model.validate(event.target.value);
            }
        }
        catch (err) {
            this.errorMessage = err.toString();
        }
    };
    InputText = __decorate([
        angular2_1.Component({
            selector: 'cw-input-text',
            properties: [
                'model',
            ], events: [
                "change"
            ]
        }),
        angular2_1.View({
            template: "\n<div class=\"ui fluid input\" [ng-class]=\"{disabled: model.disabled, error: errorMessage, icon: model.icon}\">\n  <input type=\"text\" [name]=\"model.name\" [value]=\"model.value\" [placeholder]=\"model.placeholder\" (change)=\"inputChange($event)\">\n  <i [ng-class]=\"model.icon\" *ng-if=\"model.icon\"></i>\n  <div class=\"ui small red message\" *ng-if=\"errorMessage\">{{errorMessage}}</div>\n</div>\n  ",
            directives: [angular2_1.NgClass, angular2_1.NgIf]
        }),
        __param(0, angular2_1.ElementRef), 
        __metadata('design:paramtypes', [angular2_1.ElementRef])
    ], InputText);
    return InputText;
})();
exports.InputText = InputText;
//# sourceMappingURL=input-text.js.map