var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") return Reflect.decorate(decorators, target, key, desc);
    switch (arguments.length) {
        case 2: return decorators.reduceRight(function(o, d) { return (d && d(o)) || o; }, target);
        case 3: return decorators.reduceRight(function(o, d) { return (d && d(target, key)), void 0; }, void 0);
        case 4: return decorators.reduceRight(function(o, d) { return (d && d(target, key, o)) || o; }, desc);
    }
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
var __param = (this && this.__param) || function (paramIndex, decorator) {
    return function (target, key) { decorator(target, key, paramIndex); }
};
var angular2_1 = require('angular2/angular2');
var input_text_1 = require('./input-text');
var App = (function () {
    function App(id) {
        this.initDemoValue();
        this.initDemoDisabled();
        this.initDemoError();
        this.initDemoIcon();
    }
    App.prototype.initDemoValue = function () {
        var model = new input_text_1.InputTextModel();
        model.name = "field-" + new Date().getTime() + Math.floor(Math.random() * 1000);
        model.value = "Costa Rica";
        this.demoValue = model;
    };
    App.prototype.initDemoDisabled = function () {
        var model = new input_text_1.InputTextModel();
        model.name = "field-" + new Date().getTime() + Math.floor(Math.random() * 1000);
        model.disabled = "true";
        model.placeholder = "Disabled";
        this.demoDisabled = model;
    };
    App.prototype.initDemoError = function () {
        var model = new input_text_1.InputTextModel();
        model.name = "field-" + new Date().getTime() + Math.floor(Math.random() * 1000);
        model.value = "Required Field";
        model.validate = function (newValue) {
            if (!newValue) {
                throw new Error("Required Field");
            }
        };
        this.demoError = model;
    };
    App.prototype.initDemoIcon = function () {
        var model = new input_text_1.InputTextModel();
        model.name = "field-" + new Date().getTime() + Math.floor(Math.random() * 1000);
        model.icon = "icon circular search link";
        model.placeholder = "Icon";
        this.demoIcon = model;
    };
    App.prototype.customChange = function (event) {
        console.log("Value of field: " + event.target.value);
    };
    App = __decorate([
        angular2_1.Component({
            selector: 'demo'
        }),
        angular2_1.View({
            directives: [input_text_1.InputText],
            template: "<div class=\"ui three column grid\">\n  <div class=\"column\">\n    <h4 class=\"ui top attached inverted header\">Default</h4>\n    <div class=\"ui attached segment\">\n      <cw-input-text></cw-input-text>\n    </div>\n  </div>\n  <div class=\"column\">\n    <h4 class=\"ui top attached inverted header\">Value</h4>\n    <div class=\"ui attached segment\">\n      <cw-input-text [model]=\"demoValue\"></cw-input-text>\n    </div>\n  </div>\n  <div class=\"column\">\n    <h4 class=\"ui top attached inverted header\">Disabled</h4>\n    <div class=\"ui attached segment\">\n      <cw-input-text [model]=\"demoDisabled\"></cw-input-text>\n    </div>\n  </div>\n  <div class=\"column\">\n    <h4 class=\"ui top attached inverted header\">Error</h4>\n    <div class=\"ui attached segment\">\n      <cw-input-text [model]=\"demoError\" (change)=\"customChange($event)\"></cw-input-text>\n    </div>\n  </div>\n  <div class=\"column\">\n    <h4 class=\"ui top attached inverted header\">Icon</h4>\n    <div class=\"ui attached segment\">\n      <cw-input-text [model]=\"demoIcon\"></cw-input-text>\n    </div>\n  </div>\n</div>\n  "
        }),
        __param(0, angular2_1.Attribute('id')), 
        __metadata('design:paramtypes', [String])
    ], App);
    return App;
})();
function main() {
    var app = angular2_1.bootstrap(App);
    app.then(function (appRef) {
        console.log("Bootstrapped App: ", appRef);
    }).catch(function (e) {
        console.log("Error bootstrapping app: ", e);
        throw e;
    });
    return app;
}
exports.main = main;
//# sourceMappingURL=demo.js.map