var App = require('view/components/semantic/elements/input-text/demo');
App.main().then(function () {
    console.log("Loaded Demo.");
});
console.log("Loading Demo.");
//# sourceMappingURL=index.js.map