var App = require('./demo');
App.main().then(function () {
    console.log("Loaded Demo.");
});
console.log("Loading Demo.");
