var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") return Reflect.decorate(decorators, target, key, desc);
    switch (arguments.length) {
        case 2: return decorators.reduceRight(function(o, d) { return (d && d(o)) || o; }, target);
        case 3: return decorators.reduceRight(function(o, d) { return (d && d(target, key)), void 0; }, void 0);
        case 4: return decorators.reduceRight(function(o, d) { return (d && d(target, key, o)) || o; }, desc);
    }
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
var __param = (this && this.__param) || function (paramIndex, decorator) {
    return function (target, key) { decorator(target, key, paramIndex); }
};
var angular2_1 = require('angular2/angular2');
var InputToggle = (function () {
    function InputToggle(value, onText, offText) {
        this.value = (value !== 'false');
        this.onText = onText || 'On';
        this.offText = offText || 'Off';
        this.toggle = new angular2_1.EventEmitter();
    }
    Object.defineProperty(InputToggle.prototype, "value", {
        get: function () {
            return this._value;
        },
        set: function (value) {
            this._value = value === true;
        },
        enumerable: true,
        configurable: true
    });
    InputToggle.prototype.updateValue = function (value) {
        console.log('input value changed: [from / to]', this.value, value);
        this.value = value;
        this.toggle.next({ type: 'toggle', target: this, value: value });
    };
    InputToggle = __decorate([
        angular2_1.Component({
            selector: 'cw-toggle-input',
            properties: [
                'value',
                'onText',
                'offText'
            ], events: [
                "toggle" // 'change' is fired by the input component.
            ]
        }),
        angular2_1.View({
            template: "<style>\n  .ui.toggle.checkbox label {\n    float: left\n  }\n\n  .on-label, .off-label {\n    position: absolute;\n    top: 0;\n    padding-top: .3em;\n    font-weight: 900;\n    font-size: 75%;\n    z-index: 2;\n  }\n\n  .on-label {\n    left: .75em;\n    color: white;\n  }\n\n  .off-label {\n    right: .75em;\n    color:#555;\n  }\n\n  .off .on-label, .on .off-label {\n    display: none;\n  }\n\n</style>\n  <span class=\"ui toggle fitted checkbox\" [class.on]=\"value === true\" [class.off]=\"value === false\">\n    <input type=\"checkbox\" [value]=\"value\" [checked]=\"value\" (change)=\"updateValue($event.target.checked)\">\n    <label></label>\n    <span class=\"on-label\">{{onText}}</span>\n    <span class=\"off-label\">{{offText}}</span>\n  </span>\n  "
        }),
        __param(0, angular2_1.Attribute('value')),
        __param(1, angular2_1.Attribute('onText')),
        __param(2, angular2_1.Attribute('offText')), 
        __metadata('design:paramtypes', [String, String, String])
    ], InputToggle);
    return InputToggle;
})();
exports.InputToggle = InputToggle;
//# sourceMappingURL=InputToggle.js.map