var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") return Reflect.decorate(decorators, target, key, desc);
    switch (arguments.length) {
        case 2: return decorators.reduceRight(function(o, d) { return (d && d(o)) || o; }, target);
        case 3: return decorators.reduceRight(function(o, d) { return (d && d(target, key)), void 0; }, void 0);
        case 4: return decorators.reduceRight(function(o, d) { return (d && d(target, key, o)) || o; }, desc);
    }
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
var __param = (this && this.__param) || function (paramIndex, decorator) {
    return function (target, key) { decorator(target, key, paramIndex); }
};
var angular2_1 = require('angular2/angular2');
var browser_conditionlet_1 = require('./conditionlets/browser-conditionlet/browser-conditionlet');
var request_header_conditionlet_1 = require('./conditionlets/request-header-conditionlet/request-header-conditionlet');
var country_condition_1 = require('./conditionlets/country/country-condition');
var Condition_1 = require("../../../api/rule-engine/Condition");
var dropdown_1 = require('../../../view/components/semantic/modules/dropdown/dropdown');
var ConditionTypes_1 = require("../../../api/rule-engine/ConditionTypes");
var ConditionTypes_2 = require("../../../api/rule-engine/ConditionTypes");
var ConditionComponent = (function () {
    function ConditionComponent(typesProvider, conditionServce) {
        var _this = this;
        this.conditionServce = conditionServce;
        this.typesProvider = typesProvider;
        this.conditionTypesDropdown = new dropdown_1.DropdownModel('conditionType', "Select a Condition");
        var condition = new Condition_1.ConditionModel();
        condition.conditionType = new ConditionTypes_2.ConditionTypeModel();
        this.condition = condition;
        this.parameterValues = {};
        this.index = 0;
        typesProvider.promise.then(function () {
            var opts = [];
            typesProvider.ary.forEach(function (type) {
                opts.push(new dropdown_1.DropdownOption(type.id));
            });
            _this.conditionTypesDropdown.addOptions(opts);
        });
    }
    Object.defineProperty(ConditionComponent.prototype, "condition", {
        get: function () {
            return this._condition;
        },
        set: function (condition) {
            var _this = this;
            this._condition = condition;
            if (this._condition.conditionType) {
                this.conditionTypesDropdown.selected = [this._condition.conditionType.id];
            }
            this._condition.onChange.subscribe(function (event) {
                if (event.target.isValid() && event.target.isPersisted()) {
                    _this.conditionServce.save(event.target);
                }
                if (_this._condition.conditionType) {
                    _this.conditionTypesDropdown.selected = [_this._condition.conditionType.id];
                }
            });
            this.parameterValues = this.condition.parameters;
        },
        enumerable: true,
        configurable: true
    });
    ConditionComponent.prototype.handleConditionTypeChange = function (event) {
        this.condition.conditionType = this.typesProvider.getType(event.target.model.selected[0]);
        this.condition.clearParameters();
    };
    ConditionComponent.prototype.toggleOperator = function () {
        this.condition.operator = this.condition.operator === 'AND' ? 'OR' : 'AND';
    };
    ConditionComponent.prototype.removeCondition = function () {
        this.conditionServce.remove(this._condition);
    };
    ConditionComponent.prototype.conditionChanged = function (event) {
        var _this = this;
        if (event.type == 'comparisonChange') {
            this.condition.comparison = event.value;
        }
        else if (event.type == 'parameterValueChange') {
            event.value.forEach(function (param) {
                _this.condition.setParameter(param.key, param.value);
            });
        }
    };
    ConditionComponent = __decorate([
        angular2_1.Component({
            selector: 'rule-condition',
            properties: ["condition", "index"]
        }),
        angular2_1.View({
            template: "<div flex layout-fill layout=\"row\" layout-align=\"space-between-center\" class=\"cw-condition cw-entry\">\n  <div flex=\"30\" layout=\"row\" layout-align=\"end-center\" class=\"cw-row-start-area\">\n    <div flex class=\"cw-btn-group cw-condition-toggle\">\n        <button flex class=\"ui basic button cw-button-toggle-operator\" aria-label=\"Swap And/Or\" (click)=\"toggleOperator()\" *ng-if=\"index !== 0\">\n          {{condition.operator}}\n        </button>\n    </div>\n    <cw-input-dropdown class=\"cw-condition-type-dropdown\" [model]=\"conditionTypesDropdown\" (change)=\"handleConditionTypeChange($event)\"></cw-input-dropdown>\n  </div>\n  <div flex=\"60\" class=\"cw-condition-row-main\">\n    <cw-request-header-conditionlet\n        class=\"cw-condition-component\"\n        *ng-if=\"condition.conditionType?.id == 'UsersBrowserHeaderConditionlet'\"\n        [comparator-value]=\"condition.comparison\"\n        [parameter-values]=\"parameterValues\"\n        (change)=\"conditionChanged($event)\">\n    </cw-request-header-conditionlet>\n    <cw-country-condition\n        class=\"cw-condition-component\"\n        *ng-if=\"condition.conditionType?.id == 'UsersCountryConditionlet'\"\n        [comparator-value]=\"condition.comparison\"\n        [parameter-values]=\"parameterValues\"\n        (change)=\"conditionChanged($event)\">\n    </cw-country-condition>\n    <div class=\"cw-condition-component\" *ng-if=\"condition.conditionType.id == 'NoSelection'\"></div>\n  </div>\n  <div flex=\"5\" layout=\"row\" layout-align=\"end-center\">\n    <div flex class=\"cw-btn-group cw-condition-buttons\">\n      <div class=\"ui basic icon buttons\">\n        <button class=\"ui button\" aria-label=\"Delete Condition\" (click)=\"removeCondition()\" [disabled]=\"!condition.isPersisted()\">\n          <i class=\"trash icon\"></i>\n        </button>\n      </div>\n    </div>\n  </div>\n</div>\n",
            directives: [angular2_1.NgIf, angular2_1.NgFor,
                request_header_conditionlet_1.RequestHeaderConditionlet,
                country_condition_1.CountryCondition,
                browser_conditionlet_1.BrowserConditionlet,
                dropdown_1.Dropdown
            ]
        }),
        __param(0, angular2_1.Inject(ConditionTypes_1.ConditionTypesProvider)),
        __param(1, angular2_1.Inject(Condition_1.ConditionService)), 
        __metadata('design:paramtypes', [ConditionTypes_1.ConditionTypesProvider, Condition_1.ConditionService])
    ], ConditionComponent);
    return ConditionComponent;
})();
exports.ConditionComponent = ConditionComponent;
//# sourceMappingURL=rule-condition-component.js.map