var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") return Reflect.decorate(decorators, target, key, desc);
    switch (arguments.length) {
        case 2: return decorators.reduceRight(function(o, d) { return (d && d(o)) || o; }, target);
        case 3: return decorators.reduceRight(function(o, d) { return (d && d(target, key)), void 0; }, void 0);
        case 4: return decorators.reduceRight(function(o, d) { return (d && d(target, key, o)) || o; }, desc);
    }
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
var __param = (this && this.__param) || function (paramIndex, decorator) {
    return function (target, key) { decorator(target, key, paramIndex); }
};
var angular2_1 = require('angular2/angular2');
var serverside_condition_1 = require('./condition-types/serverside-condition/serverside-condition');
var request_header_condition_1 = require('./condition-types/request-header/request-header-condition');
var country_condition_1 = require('./condition-types/country/country-condition');
var Condition_1 = require("../../../api/rule-engine/Condition");
var dropdown_1 = require('../../../view/components/semantic/modules/dropdown/dropdown');
var ConditionType_1 = require("../../../api/rule-engine/ConditionType");
var ConditionComponent = (function () {
    function ConditionComponent(typeService, conditionService) {
        var _this = this;
        this._conditionService = conditionService;
        this.typeService = typeService;
        this.conditionTypesDropdown = new dropdown_1.DropdownModel('conditionType', "Select a Condition");
        var condition = new Condition_1.ConditionModel();
        condition.conditionType = new ConditionType_1.ConditionTypeModel();
        this.condition = condition;
        this.parameterValues = {};
        this.index = 0;
        /* Note that 'typeService.list()' was called earlier, and the following observer relies on that fact. */
        typeService.onAdd.subscribe(function (conditionType) {
            _this.conditionTypesDropdown.addOptions([new dropdown_1.DropdownOption(conditionType.key, conditionType)]);
        });
    }
    Object.defineProperty(ConditionComponent.prototype, "condition", {
        get: function () {
            return this._condition;
        },
        set: function (condition) {
            var _this = this;
            this._condition = condition;
            if (this._condition.conditionType) {
                this.conditionTypesDropdown.selected = [this._condition.conditionType.key];
            }
            this._condition.onChange.subscribe(function (event) {
                if (event.target.isValid() && event.target.isPersisted()) {
                    _this._conditionService.save(event.target);
                }
                if (_this._condition.conditionType) {
                    debugger;
                    _this.conditionTypesDropdown.selected = [_this._condition.conditionType.key];
                }
            });
            this.parameterValues = this.condition.parameters;
        },
        enumerable: true,
        configurable: true
    });
    ConditionComponent.prototype.handleConditionTypeChange = function (event) {
        this.condition.conditionType = event.target.model.selectedValues()[0];
        this.condition.clearParameters();
    };
    ConditionComponent.prototype.toggleOperator = function () {
        this.condition.operator = this.condition.operator === 'AND' ? 'OR' : 'AND';
    };
    ConditionComponent.prototype.removeCondition = function () {
        this._conditionService.remove(this._condition);
    };
    ConditionComponent.prototype.conditionChanged = function (event) {
        var _this = this;
        if (event.type == 'comparisonChange') {
            this.condition.comparison = event.value;
        }
        else if (event.type == 'parameterValueChange') {
            event.value.forEach(function (param) {
                _this.condition.setParameter(param.key, param.value);
            });
        }
    };
    ConditionComponent = __decorate([
        angular2_1.Component({
            selector: 'rule-condition',
            properties: ["condition", "index"]
        }),
        angular2_1.View({
            template: "<div flex layout-fill layout=\"row\" layout-align=\"space-between-center\" class=\"cw-condition cw-entry\">\n  <div flex=\"30\" layout=\"row\" layout-align=\"end-center\" class=\"cw-row-start-area\">\n    <div flex class=\"cw-btn-group cw-condition-toggle\">\n      <button flex class=\"ui basic button cw-button-toggle-operator\" aria-label=\"Swap And/Or\" (click)=\"toggleOperator()\" *ng-if=\"index !== 0\">\n        {{condition.operator}}\n      </button>\n    </div>\n    <cw-input-dropdown class=\"cw-condition-type-dropdown\" [model]=\"conditionTypesDropdown\" (change)=\"handleConditionTypeChange($event)\"></cw-input-dropdown>\n  </div>\n  <div flex=\"65\" layout-fill class=\"cw-condition-row-main\" [ng-switch]=\"condition.conditionType?.key\">\n    <template [ng-switch-when]=\"'UsersBrowserHeaderConditionlet'\">\n      <cw-request-header-condition\n          class=\"cw-condition-component\"\n          [comparator-value]=\"condition.comparison\"\n          [parameter-values]=\"parameterValues\"\n          (change)=\"conditionChanged($event)\">\n      </cw-request-header-condition>\n    </template>\n    <template [ng-switch-when]=\"'UsersCountryConditionlet'\">\n      <cw-country-condition\n          class=\"cw-condition-component\"\n          [comparator-value]=\"condition.comparison\"\n          [parameter-values]=\"parameterValues\"\n          (change)=\"conditionChanged($event)\">\n      </cw-country-condition>\n\n    </template>\n    <template [ng-switch-when]=\"'NoSelection'\">\n      <div class=\"cw-condition-component\"></div>\n    </template>\n    <template ng-switch-default>\n      <cw-serverside-condition class=\"cw-condition-component\"\n                               [model]=\"condition\"\n                               (change)=\"conditionChanged($event)\">\n      </cw-serverside-condition>\n    </template>\n  </div>\n  <div flex=\"5\" layout=\"row\" layout-align=\"end-center\">\n    <div flex class=\"cw-btn-group cw-condition-buttons\">\n      <div class=\"ui basic icon buttons\">\n        <button class=\"ui button\" aria-label=\"Delete Condition\" (click)=\"removeCondition()\" [disabled]=\"!condition.isPersisted()\">\n          <i class=\"trash icon\"></i>\n        </button>\n      </div>\n    </div>\n  </div>\n</div>\n",
            directives: [angular2_1.NgIf, angular2_1.NgFor, angular2_1.NgSwitch, angular2_1.NgSwitchWhen, angular2_1.NgSwitchDefault,
                serverside_condition_1.ServersideCondition,
                request_header_condition_1.RequestHeaderCondition,
                country_condition_1.CountryCondition,
                dropdown_1.Dropdown,
            ]
        }),
        __param(0, angular2_1.Inject(ConditionType_1.ConditionTypeService)),
        __param(1, angular2_1.Inject(Condition_1.ConditionService)), 
        __metadata('design:paramtypes', [ConditionType_1.ConditionTypeService, Condition_1.ConditionService])
    ], ConditionComponent);
    return ConditionComponent;
})();
exports.ConditionComponent = ConditionComponent;
//# sourceMappingURL=rule-condition-component.js.map