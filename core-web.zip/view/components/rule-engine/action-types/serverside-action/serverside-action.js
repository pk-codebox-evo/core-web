var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") return Reflect.decorate(decorators, target, key, desc);
    switch (arguments.length) {
        case 2: return decorators.reduceRight(function(o, d) { return (d && d(o)) || o; }, target);
        case 3: return decorators.reduceRight(function(o, d) { return (d && d(target, key)), void 0; }, void 0);
        case 4: return decorators.reduceRight(function(o, d) { return (d && d(target, key, o)) || o; }, desc);
    }
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
var angular2_1 = require('angular2/angular2');
var input_text_1 = require("../../../semantic/elements/input-text/input-text");
var ServersideAction = (function () {
    function ServersideAction() {
        this.change = new angular2_1.EventEmitter();
        this._inputs = [];
    }
    ServersideAction.prototype._updateInputs = function () {
        var _this = this;
        this._inputs = [];
        var paramDefs = this._model.actionType.parameters;
        Object.keys(paramDefs).forEach(function (paramKey) {
            var paramDef = paramDefs[paramKey];
            _this._inputs.push(new input_text_1.InputTextModel(paramKey, paramDef.i18nKey, _this._model.getParameter(paramKey)));
        });
    };
    Object.defineProperty(ServersideAction.prototype, "model", {
        get: function () {
            return this._model;
        },
        set: function (model) {
            var _this = this;
            this._model = model;
            this._model.onChange.subscribe(function (event) {
                if (event.type === 'key' || event.type === 'actionType') {
                    _this._updateInputs();
                }
            });
            this._updateInputs();
        },
        enumerable: true,
        configurable: true
    });
    ServersideAction.prototype.handleParamValueChange = function (paramKey, event) {
        this.model.setParameter(paramKey, event.target.value);
    };
    ServersideAction = __decorate([
        angular2_1.Component({
            selector: 'cw-serverside-action',
            properties: [
                "model"
            ],
            events: [
                "change"
            ]
        }),
        angular2_1.View({
            directives: [angular2_1.NgFor, input_text_1.InputText],
            template: "<div flex layout=\"row\" layout-align=\"start-center\" class=\"cw-action-component-body\">\n  <cw-input-text *ng-for=\"var input of _inputs\"\n                 flex\n                 class=\"cw-input\"\n                 (change)=\"handleParamValueChange(input.name, $event)\"\n                 [model]=\"input\">\n  </cw-input-text>\n</div>"
        }), 
        __metadata('design:paramtypes', [])
    ], ServersideAction);
    return ServersideAction;
})();
exports.ServersideAction = ServersideAction;
//# sourceMappingURL=serverside-action.js.map