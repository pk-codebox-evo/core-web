var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") return Reflect.decorate(decorators, target, key, desc);
    switch (arguments.length) {
        case 2: return decorators.reduceRight(function(o, d) { return (d && d(o)) || o; }, target);
        case 3: return decorators.reduceRight(function(o, d) { return (d && d(target, key)), void 0; }, void 0);
        case 4: return decorators.reduceRight(function(o, d) { return (d && d(target, key, o)) || o; }, desc);
    }
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
var __param = (this && this.__param) || function (paramIndex, decorator) {
    return function (target, key) { decorator(target, key, paramIndex); }
};
var angular2_1 = require('angular2/angular2');
//import * as Rx from '../../../../node_modules/angular2/node_modules/@reactivex/rxjs/src/Rx.KitchenSink'
var ApiRoot_1 = require('../../../api/persistence/ApiRoot');
var ActionType_1 = require('../../../api/rule-engine/ActionType');
var UserModel_1 = require("../../../api/auth/UserModel");
var I18NCountryProvider_1 = require('../../../api/system/locale/I18NCountryProvider');
var rule_component_1 = require('./rule-component');
var Rule_1 = require("../../../api/rule-engine/Rule");
var Action_1 = require("../../../api/rule-engine/Action");
var RestDataStore_1 = require("../../../api/persistence/RestDataStore");
var DataStore_1 = require("../../../api/persistence/DataStore");
var ConditionGroup_1 = require("../../../api/rule-engine/ConditionGroup");
var ConditionType_1 = require("../../../api/rule-engine/ConditionType");
var Condition_1 = require("../../../api/rule-engine/Condition");
/**
 *
 */
var RuleEngineComponent = (function () {
    function RuleEngineComponent(conditionTypeService, ruleService) {
        var _this = this;
        conditionTypeService.list(); // load types early in a single place rather than calling list repeatedly.
        this.ruleService = ruleService;
        this.filterText = "";
        this.rules = [];
        this.ruleService.onAdd.subscribe(function (rule) {
            _this.handleAdd(rule);
        }, function (err) {
            _this.handleAddError(err);
        });
        this.ruleService.onRemove.subscribe(function (rule) {
            _this.handleRemove(rule);
        }, function (err) {
            _this.handleRemoveError(err);
        });
        this.ruleService.list();
    }
    RuleEngineComponent.prototype.handleAdd = function (rule) {
        var _this = this;
        if (rule === this.ruleStub) {
            this.stubWatch.unsubscribe();
            this.stubWatch = null;
            this.ruleStub = null;
        }
        else {
            this.rules.push(rule);
            rule.onChange.subscribe(function (event) {
                _this.handleRuleChange(event);
            });
        }
    };
    RuleEngineComponent.prototype.handleRuleChange = function (event) {
        if (event.target.valid) {
            this.ruleService.save(event.target);
        }
    };
    RuleEngineComponent.prototype.handleRemove = function (rule) {
        this.rules = this.rules.filter(function (arrayRule) {
            return arrayRule.key !== rule.key;
        });
        // @todo ggranum: we're leaking Subscribers here, sadly. Might cause issues for long running edit sessions.
    };
    RuleEngineComponent.prototype.handleAddError = function (err) {
        console.log('Could not add rule: ', err.message, err);
    };
    RuleEngineComponent.prototype.handleRemoveError = function (err) {
        console.log('Something went wrong: ' + err.message);
    };
    RuleEngineComponent.prototype.addRule = function () {
        var _this = this;
        this.ruleStub = new Rule_1.RuleModel();
        this.rules.push(this.ruleStub);
        this.stubWatch = this.ruleStub.onValidityChange.subscribe(function (event) {
            if (event.target.valid) {
                _this.ruleService.save(_this.ruleStub);
            }
        });
    };
    RuleEngineComponent = __decorate([
        angular2_1.Component({
            selector: 'cw-rule-engine'
        }),
        angular2_1.View({
            template: "<div flex layout=\"column\" class=\"cw-rule-engine\">\n  <div flex layout=\"row\" layout-align=\"space-between center\" class=\"cw-header\">\n    <div flex layout=\"row\" layout-align=\"space-between center\" class=\"ui icon input\">\n      <i class=\"filter icon\"></i>\n      <input type=\"text\" placeholder=\"Start typing to filter rules...\" [value]=\"filterText\" (keyup)=\"filterText = $event.target.value\">\n    </div>\n    <div flex=\"2\"></div>\n    <button  class=\"ui button cw-button-add\" aria-label=\"Create a new Rule\" (click)=\"addRule()\" [disabled]=\"ruleStub != null\">\n      <i class=\"plus icon\" aria-hidden=\"true\"></i>Add Rule\n    </button>\n  </div>\n  <rule flex layout=\"row\" *ng-for=\"var r of rules\" [rule]=\"r\" [hidden]=\"!(filterText == '' || r.name.toLowerCase().includes(filterText?.toLowerCase()))\"></rule>\n</div>\n\n",
            directives: [rule_component_1.RuleComponent, angular2_1.NgFor, angular2_1.NgIf]
        }),
        __param(0, angular2_1.Inject(ConditionType_1.ConditionTypeService)),
        __param(1, angular2_1.Inject(Rule_1.RuleService)), 
        __metadata('design:paramtypes', [ConditionType_1.ConditionTypeService, Rule_1.RuleService])
    ], RuleEngineComponent);
    return RuleEngineComponent;
})();
exports.RuleEngineComponent = RuleEngineComponent;
var RuleEngineApp = (function () {
    function RuleEngineApp() {
    }
    RuleEngineApp.main = function () {
        var app = angular2_1.bootstrap(RuleEngineComponent, [ApiRoot_1.ApiRoot,
            ActionType_1.ActionTypesProvider,
            UserModel_1.UserModel,
            I18NCountryProvider_1.I18NCountryProvider,
            Rule_1.RuleService,
            Action_1.ActionService,
            ConditionGroup_1.ConditionGroupService,
            Condition_1.ConditionService,
            ConditionType_1.ConditionTypeService,
            new angular2_1.Provider(DataStore_1.DataStore, { useClass: RestDataStore_1.RestDataStore })
        ]);
        app.then(function (appRef) {
            console.log("Bootstrapped App: ", appRef);
        }).catch(function (e) {
            console.log("Error bootstrapping app: ", e);
            throw e;
        });
        return app;
    };
    return RuleEngineApp;
})();
exports.RuleEngineApp = RuleEngineApp;
//# sourceMappingURL=rule-engine.js.map