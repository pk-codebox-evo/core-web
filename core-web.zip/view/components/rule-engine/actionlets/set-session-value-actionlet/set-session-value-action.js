var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") return Reflect.decorate(decorators, target, key, desc);
    switch (arguments.length) {
        case 2: return decorators.reduceRight(function(o, d) { return (d && d(o)) || o; }, target);
        case 3: return decorators.reduceRight(function(o, d) { return (d && d(target, key)), void 0; }, void 0);
        case 4: return decorators.reduceRight(function(o, d) { return (d && d(target, key, o)) || o; }, desc);
    }
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
var __param = (this && this.__param) || function (paramIndex, decorator) {
    return function (target, key) { decorator(target, key, paramIndex); }
};
/**
 * Set a value on to the active session, using the supplied key.
 *
 *
 *
 * ## POSIX Utility Argument Syntax (http://pubs.opengroup.org/onlinepubs/9699919799/basedefs/V1_chap12.html)
 * ```
 * cw-set-session-value-action [-k session_key] [value]
 *   -k          The key under which the specified value will be made available on the Session.
 *   value       The value which will be set on the session. Currently only allows static string values. Dynamic lookup TBD.
 * ```
 *
 * ## UI Layout
 *
 * Conceptually the action type is made up of two fields:
 * ```
 * <div>
 *   <input name="session_key" required="true"/>
 *   <input name="value" required="true" />
 * </div>
 * ```
 * ### Fields
 *
 * #### `session_key`
 * The `session_key` is a simple text input field. The value specified must be a valid Session Key as specified by the Java Servlet specification.
 *
 * #### `value`
 * A static string value. May be a number, blank, or any value representable by text.
 *
 *
 * ------------------------ Discussion ------------------------
 *
 * --------------------------
 */
var angular2_1 = require('angular2/angular2');
var input_text_1 = require('../../../semantic/elements/input-text/input-text');
var SetSessionValueAction = (function () {
    function SetSessionValueAction(sessionKey, sessionValue) {
        if (sessionKey === void 0) { sessionKey = ''; }
        if (sessionValue === void 0) { sessionValue = ''; }
        this.paramKeys = ["sessionKey", "sessionValue"];
        this.params = {
            "sessionKey": sessionKey,
            "sessionValue": sessionValue
        };
        this.configChange = new angular2_1.EventEmitter();
        this.setSessionKeyInputTextModel = new input_text_1.InputTextModel();
        this.setSessionValueInputTextModel = new input_text_1.InputTextModel();
        this.setSessionKeyInputTextModel.placeholder = "Enter a session key";
        this.setSessionValueInputTextModel.placeholder = "Enter a value";
    }
    Object.defineProperty(SetSessionValueAction.prototype, "action", {
        set: function (action) {
            var _this = this;
            this.params = {};
            this.paramKeys.forEach(function (key) {
                _this.params[key] = action.getParameter(key);
            });
            this.setSessionKeyInputTextModel.value = action.getParameter('sessionKey');
            this.setSessionValueInputTextModel.value = action.getParameter('sessionValue');
        },
        enumerable: true,
        configurable: true
    });
    SetSessionValueAction.prototype.updateParamValue = function (key, event) {
        var value = event.target['value'];
        this.params[key] = value;
        this.configChange.next({ type: 'actionParameterChanged', target: this, params: this.params });
        if (key == 'sessionKey')
            this.setSessionKeyInputTextModel.value = value;
        if (key == 'sessionValue')
            this.setSessionValueInputTextModel.value = value;
    };
    SetSessionValueAction = __decorate([
        angular2_1.Component({
            selector: 'cw-set-session-value-action',
            properties: [
                "sessionKey", "sessionValue", "action"
            ],
            events: [
                "configChange"
            ]
        }),
        angular2_1.View({
            directives: [angular2_1.NgFor, input_text_1.InputText],
            template: "<div flex=\"grow\" layout=\"row\" layout-align=\"space-around-center\">\n  <cw-input-text flex\n      (change)=\"updateParamValue('sessionKey', $event)\"\n      [model]=\"setSessionKeyInputTextModel\">\n  </cw-input-text>\n  <cw-input-text flex\n      (change)=\"updateParamValue('sessionValue', $event)\"\n      [model]=\"setSessionValueInputTextModel\">\n  </cw-input-text>\n</div>\n  "
        }),
        __param(0, angular2_1.Attribute('sessionKey')),
        __param(1, angular2_1.Attribute('sessionValue')), 
        __metadata('design:paramtypes', [String, String])
    ], SetSessionValueAction);
    return SetSessionValueAction;
})();
exports.SetSessionValueAction = SetSessionValueAction;
//# sourceMappingURL=set-session-value-action.js.map