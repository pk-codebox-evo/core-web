var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") return Reflect.decorate(decorators, target, key, desc);
    switch (arguments.length) {
        case 2: return decorators.reduceRight(function(o, d) { return (d && d(o)) || o; }, target);
        case 3: return decorators.reduceRight(function(o, d) { return (d && d(target, key)), void 0; }, void 0);
        case 4: return decorators.reduceRight(function(o, d) { return (d && d(target, key, o)) || o; }, desc);
    }
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
var __param = (this && this.__param) || function (paramIndex, decorator) {
    return function (target, key) { decorator(target, key, paramIndex); }
};
var angular2_1 = require('angular2/angular2');
//import * as Rx from '../../../../node_modules/angular2/node_modules/@reactivex/rxjs/src/Rx.KitchenSink'
var rule_action_component_1 = require('./rule-action-component');
var rule_condition_group_component_1 = require('./rule-condition-group-component');
var InputToggle_1 = require('../../../view/components/input/toggle/InputToggle');
var Rule_1 = require("../../../api/rule-engine/Rule");
var Action_1 = require("../../../api/rule-engine/Action");
var ConditionGroup_1 = require("../../../api/rule-engine/ConditionGroup");
var dropdown_1 = require("../semantic/modules/dropdown/dropdown");
var input_text_1 = require("../semantic/elements/input-text/input-text");
var rsrc = {
    fireOn: {
        EVERY_PAGE: 'Every Page',
        ONCE_PER_VISIT: 'Once per visit',
        ONCE_PER_VISITOR: 'Once per visitor',
        EVERY_REQUEST: 'Every Request'
    }
};
var fireOn = [
    new dropdown_1.DropdownOption('EVERY_PAGE', 'EVERY_PAGE', 'Every Page'),
    new dropdown_1.DropdownOption('ONCE_PER_VISIT', 'ONCE_PER_VISIT', 'Once per visit'),
    new dropdown_1.DropdownOption('ONCE_PER_VISITOR', 'ONCE_PER_VISITOR', 'Once per visitor'),
    new dropdown_1.DropdownOption('EVERY_REQUEST', 'EVERY_REQUEST', 'Every Request'),
];
var RuleComponent = (function () {
    function RuleComponent(elementRef, ruleService, actionService, conditionGroupService) {
        this.elementRef = elementRef;
        this.actionService = actionService;
        this.ruleService = ruleService;
        this.groupService = conditionGroupService;
        this.groups = [];
        this.actions = [];
        this.hidden = false;
        this.collapsed = false;
        this.fireOnDropdown = new dropdown_1.DropdownModel('fireOn', "Select One", ['EVERY_PAGE'], fireOn);
        this.ruleNameInputTextModel = new input_text_1.InputTextModel();
        this.ruleNameInputTextModel.placeholder = "Describe the rule";
        this.ruleNameInputTextModel.validate = function (newValue) {
            if (!newValue) {
                throw new Error("Required Field");
            }
        };
    }
    RuleComponent.prototype.onInit = function () {
        if (!this.rule.isPersisted()) {
            var el = this.elementRef.nativeElement;
            window.setTimeout(function () {
                var els = el.getElementsByClassName('cw-name');
                if (els[0]) {
                    els[0]['focus']();
                }
            }, 50); //avoid tick recursively error
        }
    };
    Object.defineProperty(RuleComponent.prototype, "rule", {
        get: function () {
            return this._rule;
        },
        set: function (rule) {
            var _this = this;
            if (!this.rule || this.rule.key !== rule.key) {
                this._rule = rule;
                this.groups = [];
                this.actions = [];
                this.actionService.onAdd.subscribe(function (action) { return _this.handleActionAdd(action); }, function (err) { return _this.handleActionAddError(err); });
                this.actionService.onRemove.subscribe(function (action) { return _this.handleActionRemove(action); }, function (err) { return _this.handleActionRemoveError(err); });
                this.groupService.onAdd.subscribe(function (group) { return _this.handleGroupAdd(group); }, function (err) { return _this.handleGroupAddError(err); });
                this.groupService.onRemove.subscribe(function (group) { return _this.handleGroupRemove(group); }, function (err) { return _this.handleGroupRemoveError(err); });
                this.actionService.list(this.rule);
                this.groupService.list(this.rule);
                this.ruleNameInputTextModel.value = rule.name;
                this.fireOnDropdown.selected = [rule.fireOn];
                if (Object.keys(rule.actions).length === 0) {
                    this.addAction();
                }
            }
        },
        enumerable: true,
        configurable: true
    });
    RuleComponent.prototype.toggleCollapsed = function () {
        console.log('eh?', this.collapsed);
        this.collapsed = !this.collapsed;
    };
    RuleComponent.prototype.handleFireOnDropdownChange = function (event) {
        this.rule.fireOn = event.value;
    };
    RuleComponent.prototype.handleRuleNameChange = function (name) {
        this.rule.name = name;
    };
    RuleComponent.prototype.addGroup = function () {
        var group = new ConditionGroup_1.ConditionGroupModel();
        group.owningRule = this._rule;
        group.priority = 10;
        group.operator = 'AND';
        this.groupService.add(group);
    };
    RuleComponent.prototype.addAction = function () {
        var _this = this;
        this.actionStub = new Action_1.ActionModel();
        this.actionStub.owningRule = this.rule;
        this.actions.push(this.actionStub);
        this.actionStubWatch = this.actionStub.onChange.subscribe(function (vcEvent) {
            if (vcEvent.target.valid) {
                _this.actionService.add(_this.actionStub);
            }
        });
    };
    RuleComponent.prototype.handleActionAdd = function (action) {
        if (action.owningRule.key === this.rule.key) {
            if (action == this.actionStub) {
                this.actionStub = null;
                this.actionStubWatch.unsubscribe();
            }
            else if (this.actions.indexOf(action) == -1) {
                this.actions.push(action);
            }
        }
    };
    RuleComponent.prototype.handleActionAddError = function (err) {
        console.log("Error: ", err);
        throw err;
    };
    RuleComponent.prototype.handleActionRemove = function (action) {
        this.actions = this.actions.filter(function (aryAction) {
            return aryAction.key != action.key;
        });
    };
    RuleComponent.prototype.handleActionRemoveError = function (err) {
        console.log("Error: ", err);
        throw err;
    };
    RuleComponent.prototype.handleGroupAdd = function (group) {
        if (group.owningRule.key === this.rule.key) {
            this.groups.push(group);
        }
    };
    RuleComponent.prototype.handleGroupAddError = function (err) {
        console.log("Error: ", err);
        throw err;
    };
    RuleComponent.prototype.handleGroupRemove = function (group) {
        this.groups = this.groups.filter(function (aryGroup) {
            return aryGroup.key != group.key;
        });
    };
    RuleComponent.prototype.handleGroupRemoveError = function (err) {
        console.log("Error: ", err);
        throw err;
    };
    RuleComponent.prototype.removeRule = function () {
        if (confirm('Are you sure you want delete this rule?')) {
            this.ruleService.remove(this.rule);
        }
    };
    RuleComponent = __decorate([
        angular2_1.Component({
            selector: 'rule',
            properties: ["rule", "hidden"]
        }),
        angular2_1.View({
            template: "<div flex layout=\"column\" class=\"cw-rule\" [class.cw-hidden]=\"hidden\">\n  <div flex=\"grow\" layout=\"row\" layout-align=\"space-between-center\" class=\"cw-header\" *ng-if=\"!hidden\" (click)=\"toggleCollapsed()\">\n    <div flex=\"70\" layout=\"row\" layout-align=\"start-center\" class=\"cw-header\" *ng-if=\"!hidden\">\n      <i flex=\"none\" class=\"caret icon cw-rule-caret\" [class.right]=\"collapsed\" [class.down]=\"!collapsed\" aria-hidden=\"true\"></i>\n      <cw-input-text flex=\"70\"\n                     (change)=\"handleRuleNameChange($event.target.value)\"\n                     (focus)=\"collapsed = false\"\n                     (click)=\"$event.stopPropagation()\"\n                     [model]=\"ruleNameInputTextModel\">\n      </cw-input-text>\n      <span class=\"cw-fire-on-label\">Fire On:</span>\n      <cw-input-dropdown flex=\"none\" class=\"cw-fire-on-dropdown\" [model]=\"fireOnDropdown\" (change)=\"handleFireOnDropdownChange($event)\" (click)=\"$event.stopPropagation()\"></cw-input-dropdown>\n    </div>\n    <div flex=\"30\" layout=\"row\" layout-align=\"end-center\" class=\"cw-header\" *ng-if=\"!hidden\">\n      <cw-toggle-input class=\"cw-input\"\n                       [value]=\"rule.enabled\"\n                       (toggle)=\"rule.enabled = $event.target.value\"\n                       (click)=\"$event.stopPropagation()\">\n      </cw-toggle-input>\n      <div class=\"cw-btn-group\">\n        <div class=\"ui basic icon buttons\">\n          <button class=\"ui button\" aria-label=\"Delete Rule\" (click)=\"removeRule()\">\n            <i class=\"trash icon\"></i>\n          </button>\n          <button class=\"ui button\" arial-label=\"Add Group\" (click)=\"addGroup(); collapsed=false; $event.stopPropagation()\">\n            <i class=\"plus icon\" aria-hidden=\"true\"></i>\n          </button>\n        </div>\n      </div>\n    </div>\n  </div>\n  <div flex layout=\"column\" class=\"cw-accordion-body\" [class.cw-hidden]=\"collapsed\">\n    <condition-group flex=\"grow\" layout=\"row\" *ng-for=\"var group of groups; var i=index\"\n                     [rule]=\"rule\"\n                     [group]=\"group\"\n                     [group-index]=\"i\"></condition-group>\n    <div flex layout=\"column\" layout-align=\"center-start\" class=\"cw-action-separator\">\n      This rule sets the following action(s)\n    </div>\n    <div flex=\"100\" layout=\"column\" class=\"cw-rule-actions\">\n      <div flex layout=\"row\" layout-align=\"space-between-center\" *ng-for=\"var action of actions; var i=index\">\n        <div flex layout=\"row\" layout-align=\"start-center\">\n          <rule-action flex [action]=\"action\"></rule-action>\n        </div>\n        <div flex=\"0\" layout=\"row\" layout-align=\"end-center\">\n          <div class=\"cw-spacer cw-add-condition\" *ng-if=\"i !== (actions.length - 1)\"></div>\n          <div class=\"cw-btn-group\" *ng-if=\"i === (actions.length - 1)\">\n            <div class=\"ui basic icon buttons\">\n              <button class=\"cw-button-add-item ui small basic button\" arial-label=\"Add Action\" (click)=\"addAction();\" [disabled]=\"!action.isPersisted()\">\n                <i class=\"plus icon\" aria-hidden=\"true\"></i>\n              </button>\n            </div>\n          </div>\n        </div>\n      </div>\n    </div>\n  </div>\n</div>\n\n",
            directives: [InputToggle_1.InputToggle, rule_action_component_1.RuleActionComponent, rule_condition_group_component_1.ConditionGroupComponent, angular2_1.NgIf, angular2_1.NgFor, input_text_1.InputText, dropdown_1.Dropdown]
        }),
        __param(1, angular2_1.Inject(Rule_1.RuleService)),
        __param(2, angular2_1.Inject(Action_1.ActionService)),
        __param(3, angular2_1.Inject(ConditionGroup_1.ConditionGroupService)), 
        __metadata('design:paramtypes', [angular2_1.ElementRef, Rule_1.RuleService, Action_1.ActionService, ConditionGroup_1.ConditionGroupService])
    ], RuleComponent);
    return RuleComponent;
})();
exports.RuleComponent = RuleComponent;
//# sourceMappingURL=rule-component.js.map