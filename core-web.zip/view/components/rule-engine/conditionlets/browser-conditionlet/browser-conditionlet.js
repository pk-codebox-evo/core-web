var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") return Reflect.decorate(decorators, target, key, desc);
    switch (arguments.length) {
        case 2: return decorators.reduceRight(function(o, d) { return (d && d(o)) || o; }, target);
        case 3: return decorators.reduceRight(function(o, d) { return (d && d(target, key)), void 0; }, void 0);
        case 4: return decorators.reduceRight(function(o, d) { return (d && d(target, key, o)) || o; }, desc);
    }
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
var __param = (this && this.__param) || function (paramIndex, decorator) {
    return function (target, key) { decorator(target, key, paramIndex); }
};
var angular2_1 = require('angular2/angular2');
/**
 * ------------------------ Discussion ------------------------
 * @todo ggranum: Delete this file, probably. Or define what this conditionlet is meant to do more clearly.
 *   Specific issues:
 *     1) what do we really want the user to select? Firefox vs Chrome vs Edge? Mobile versus Desktop versus tablet?
 *   any or all of these things can be obtain through the UA header. There is certainly a good argument to be made for
 *   making this easier for a limited subset of browsers. Which brings us to
 *     2) User defined values would be just about impossible to implement for this conditionlet without basically
 *   recreating the RequestHeaderConditionlet.
 *
 *
 *   Potential solution:
 *     Make this a simple "is/is not" and a select list that contains only the most 5 to 10 most common browser names.
 *       - "Browser name [is, is not] [ Chrome, Firefox, MSIE, Opera, Safari, Unrecognized ]"
 *     Create a second conditionlet for browser type
 *       - "Browser type [is, is not] [ Desktop, Tablet, Phone, Crawler, Unrecognized]"
 *
 * --------------------------
 *
 * Express a condition based on the simple name of the web browser, as found in the User-Agent request header.
 * @see: http://www.w3.org/Protocols/rfc2616/rfc2616-sec14.html#sec14.43
 * @see http://www.w3.org/Protocols/rfc2616/rfc2616-sec3.html#sec3.8
 *
 * A list of UA strings can be found at http://techpatterns.com/forums/about304.html
 *
 * Conditionlet Definition:
 *   allowMultipleSelections: true,
 *   allowUserDefinedValues: true
 *
 * Pre-populated values:
 *  [ ]
 *
 * "UsersBrowserConditionlet":{
 *   "id":"UsersBrowserConditionlet",
 *   "comparisons":[
 *     {
 *       "id":"is",
 *     },
 *     {
 *       "id":"startsWith",
 *     },
 *     {
 *       "id":"endsWith",
 *     },
 *     {
 *       "id":"contains",
 *     },
 *     {
 *       "id":"regex",
 *     }
 *   ]
 * }
 */
var BrowserConditionlet = (function () {
    function BrowserConditionlet(id) {
    }
    BrowserConditionlet = __decorate([
        angular2_1.Component({
            selector: 'cw-browser-conditionlet'
        }),
        angular2_1.View({
            directives: [angular2_1.NgFor],
            template: "\n    <div class=\"col-sm-5\">\n      <select class=\"form-control clause-selector\" [value]=\"conditionletDir.condition.comparison\" (change)=\"setComparison($event)\">\n        <option value=\"{{x.id}}\" *ng-for=\"var x of conditionletDir.conditionlet.comparisons\">{{x.label}}</option>\n      </select>\n    </div>\n    <div class=\"col-sm-2\">\n      <h4 class=\"separator\"></h4>\n    </div>\n    <div class=\"col-sm-5\">\n      <input type=\"text\" class=\"form-control condition-value\" [value]=\"conditionletDir.value\" (input)=\"setValue($event)\"/>\n    </div>\n  "
        }),
        __param(0, angular2_1.Attribute('id')), 
        __metadata('design:paramtypes', [String])
    ], BrowserConditionlet);
    return BrowserConditionlet;
})();
exports.BrowserConditionlet = BrowserConditionlet;
//# sourceMappingURL=browser-conditionlet.js.map