var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") return Reflect.decorate(decorators, target, key, desc);
    switch (arguments.length) {
        case 2: return decorators.reduceRight(function(o, d) { return (d && d(o)) || o; }, target);
        case 3: return decorators.reduceRight(function(o, d) { return (d && d(target, key)), void 0; }, void 0);
        case 4: return decorators.reduceRight(function(o, d) { return (d && d(target, key, o)) || o; }, desc);
    }
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
var angular2_1 = require('angular2/angular2');
var set_session_value_action_1 = require('./actionlets/set-session-value-actionlet/set-session-value-action');
var Action_1 = require("../../../api/rule-engine/Action");
var ActionType_1 = require("../../../api/rule-engine/ActionType");
var Action_2 = require("../../../api/rule-engine/Action");
var ActionType_2 = require("../../../api/rule-engine/ActionType");
var dropdown_1 = require("../semantic/modules/dropdown/dropdown");
var RuleActionComponent = (function () {
    function RuleActionComponent(typesProvider, actionService) {
        var _this = this;
        this.actionService = actionService;
        this.actionTypesDropdown = new dropdown_1.DropdownModel('actionType', "Select an Action", [], []);
        this.typesProvider = typesProvider;
        var action = new Action_1.ActionModel();
        action.actionType = new ActionType_2.ActionTypeModel();
        this.action = action;
        typesProvider.promise.then(function () {
            var opts = [];
            typesProvider.ary.forEach(function (type) {
                opts.push(new dropdown_1.DropdownOption(type.id));
            });
            _this.actionTypesDropdown.addOptions(opts);
        });
    }
    Object.defineProperty(RuleActionComponent.prototype, "action", {
        get: function () {
            return this._action;
        },
        set: function (action) {
            var _this = this;
            this._action = action;
            if (this._action.actionType) {
                this.actionTypesDropdown.selected = [this._action.actionType.id];
            }
            action.onChange.subscribe(function (self) {
                if (action.isValid() && action.isPersisted()) {
                    _this.actionService.save(action);
                }
                if (_this._action.actionType) {
                    _this.actionTypesDropdown.selected = [_this._action.actionType.id];
                }
            });
        },
        enumerable: true,
        configurable: true
    });
    RuleActionComponent.prototype.handleActionTypeChange = function (event) {
        this.action.actionType = this.typesProvider.getType(event.target.model.selected[0]);
        //this.action.clearParameters()
    };
    RuleActionComponent.prototype.actionConfigChanged = function (event) {
        var _this = this;
        if (event.type == 'actionParameterChanged') {
            Object.keys(event.params).forEach(function (key) {
                _this.action.setParameter(key, event.params[key]);
            });
        }
    };
    RuleActionComponent.prototype.removeAction = function () {
        this.actionService.remove(this.action);
    };
    RuleActionComponent = __decorate([
        angular2_1.Component({
            selector: 'rule-action',
            properties: ["action"]
        }),
        angular2_1.View({
            template: "<div flex layout=\"row\" layout-align=\"space-between-center\" class=\"cw-rule-action cw-entry\">\n<div flex=\"30\" layout=\"row\" layout-align=\"end-center\" class=\"cw-row-start-area\">\n    <cw-input-dropdown class=\"cw-action-type-dropdown\" [model]=\"actionTypesDropdown\" (change)=\"handleActionTypeChange($event)\"></cw-input-dropdown>\n  </div>\n\n\n  <cw-set-session-value-action flex=\"60\"\n                               *ng-if=\"action.actionType.id == 'SetSessionAttributeActionlet'\"\n                               [action]=\"action\"\n                               (config-change)=\"actionConfigChanged($event)\">\n\n  </cw-set-session-value-action>\n  <div flex=\"5\" class=\"cw-btn-group\">\n    <div class=\"ui basic icon buttons\">\n      <button class=\"ui button\" aria-label=\"Delete Action\" (click)=\"removeAction()\">\n        <i class=\"trash icon\"></i>\n      </button>\n    </div>\n  </div>\n</div>",
            directives: [angular2_1.NgIf, angular2_1.NgFor, set_session_value_action_1.SetSessionValueAction, dropdown_1.Dropdown],
        }), 
        __metadata('design:paramtypes', [ActionType_1.ActionTypesProvider, Action_2.ActionService])
    ], RuleActionComponent);
    return RuleActionComponent;
})();
exports.RuleActionComponent = RuleActionComponent;
//# sourceMappingURL=rule-action-component.js.map