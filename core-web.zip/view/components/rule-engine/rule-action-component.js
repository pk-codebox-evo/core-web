var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") return Reflect.decorate(decorators, target, key, desc);
    switch (arguments.length) {
        case 2: return decorators.reduceRight(function(o, d) { return (d && d(o)) || o; }, target);
        case 3: return decorators.reduceRight(function(o, d) { return (d && d(target, key)), void 0; }, void 0);
        case 4: return decorators.reduceRight(function(o, d) { return (d && d(target, key, o)) || o; }, desc);
    }
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
var angular2_1 = require('angular2/angular2');
var serverside_action_1 = require('./action-types/serverside-action/serverside-action');
var Action_1 = require("../../../api/rule-engine/Action");
var ActionType_1 = require("../../../api/rule-engine/ActionType");
var Action_2 = require("../../../api/rule-engine/Action");
var dropdown_1 = require("../semantic/modules/dropdown/dropdown");
var I18n_1 = require("../../../api/system/locale/I18n");
var RuleActionComponent = (function () {
    function RuleActionComponent(msgService, typeService, actionService) {
        var _this = this;
        this._msgService = msgService;
        this.actionService = actionService;
        this.actionTypesDropdown = new dropdown_1.DropdownModel('actionType', "Select an Action");
        this.typeService = typeService;
        var action = new Action_1.ActionModel();
        action.actionType = new ActionType_1.ActionTypeModel();
        this.action = action;
        typeService.onAdd.subscribe(function (actionType) {
            _this.actionTypesDropdown.addOptions([new dropdown_1.DropdownOption(actionType.key, actionType, actionType.rsrc.name)]);
        });
    }
    Object.defineProperty(RuleActionComponent.prototype, "action", {
        get: function () {
            return this._action;
        },
        set: function (action) {
            var _this = this;
            this._action = action;
            if (this._action.actionType && this._action.actionType.key != 'NoSelection') {
                this.actionTypesDropdown.selected = [this._action.actionType.key];
            }
            action.onChange.subscribe(function (self) {
                if (action.isValid() && action.isPersisted()) {
                    _this.actionService.save(action);
                }
                if (_this._action.actionType) {
                    _this.actionTypesDropdown.selected = [_this._action.actionType.key];
                }
            });
        },
        enumerable: true,
        configurable: true
    });
    RuleActionComponent.prototype.handleActionTypeChange = function (event) {
        this.action.clearParameters();
        this.action.actionType = event.target.model.selectedValues()[0];
        if (!this.action.isPersisted()) {
            this.actionService.add(this.action);
        }
    };
    RuleActionComponent.prototype.actionConfigChanged = function (event) {
        var _this = this;
        if (event.type == 'actionParameterChanged') {
            Object.keys(event.params).forEach(function (key) {
                _this.action.setParameter(key, event.params[key]);
            });
        }
    };
    RuleActionComponent.prototype.removeAction = function () {
        this.actionService.remove(this.action);
    };
    RuleActionComponent = __decorate([
        angular2_1.Component({
            selector: 'rule-action',
            properties: ["action"]
        }),
        angular2_1.View({
            template: "<div flex layout=\"row\" layout-align=\"space-between-center\" class=\"cw-rule-action cw-entry\">\n  <div flex=\"35\" layout=\"row\" layout-align=\"end-center\" class=\"cw-row-start-area\">\n    <cw-input-dropdown\n      class=\"cw-action-type-dropdown\"\n      [model]=\"actionTypesDropdown\"\n      (change)=\"handleActionTypeChange($event)\">\n      </cw-input-dropdown>\n  </div>\n\n\n  <cw-serverside-action flex layout-fill\n                        [model]=\"action\"\n                        (config-change)=\"actionConfigChanged($event)\">\n\n  </cw-serverside-action>\n  <div flex=\"5\" layout=\"row\" layout-align=\"end-center\" class=\"cw-btn-group\">\n    <div class=\"ui basic icon buttons\">\n      <button class=\"ui button\" aria-label=\"Delete Action\" (click)=\"removeAction()\" [disabled]=\"!_action.isPersisted()\">\n        <i class=\"trash icon\"></i>\n      </button>\n    </div>\n  </div>\n</div>",
            directives: [angular2_1.NgIf, angular2_1.NgFor, serverside_action_1.ServersideAction, dropdown_1.Dropdown],
        }), 
        __metadata('design:paramtypes', [I18n_1.I18nService, ActionType_1.ActionTypeService, Action_2.ActionService])
    ], RuleActionComponent);
    return RuleActionComponent;
})();
exports.RuleActionComponent = RuleActionComponent;
//# sourceMappingURL=rule-action-component.js.map