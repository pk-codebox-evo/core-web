var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") return Reflect.decorate(decorators, target, key, desc);
    switch (arguments.length) {
        case 2: return decorators.reduceRight(function(o, d) { return (d && d(o)) || o; }, target);
        case 3: return decorators.reduceRight(function(o, d) { return (d && d(target, key)), void 0; }, void 0);
        case 4: return decorators.reduceRight(function(o, d) { return (d && d(target, key, o)) || o; }, desc);
    }
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
var __param = (this && this.__param) || function (paramIndex, decorator) {
    return function (target, key) { decorator(target, key, paramIndex); }
};
var angular2_1 = require('angular2/angular2');
//import * as Rx from '../../../../node_modules/angular2/node_modules/@reactivex/rxjs/src/Rx.KitchenSink'
var rule_condition_component_1 = require('./rule-condition-component');
var ApiRoot_1 = require('../../../api/persistence/ApiRoot');
var ConditionGroup_1 = require("../../../api/rule-engine/ConditionGroup");
var Condition_1 = require("../../../api/rule-engine/Condition");
var ConditionGroupComponent = (function () {
    function ConditionGroupComponent(apiRoot, groupService, conditionService) {
        var _this = this;
        this.apiRoot = apiRoot;
        this.groupService = groupService;
        this.conditionService = conditionService;
        this.groupCollapsed = false;
        this.conditions = [];
        this.groupIndex = 0;
        this.conditionService.onAdd.subscribe(function (conditionModel) {
            if (conditionModel.owningGroup.key == _this._group.key) {
                _this.handleAddCondition(conditionModel);
            }
        });
        this.conditionService.onRemove.subscribe(function (conditionModel) {
            if (conditionModel.owningGroup.key == _this._group.key) {
                _this.handleRemoveCondition(conditionModel);
            }
        });
    }
    Object.defineProperty(ConditionGroupComponent.prototype, "group", {
        get: function () {
            return this._group;
        },
        set: function (group) {
            this._group = group;
            var groupKeys = Object.keys(group.conditions);
            if (groupKeys.length == 0) {
                this.addCondition();
            }
            else {
                this.conditionService.listForGroup(group);
            }
        },
        enumerable: true,
        configurable: true
    });
    ConditionGroupComponent.prototype.addCondition = function () {
        var _this = this;
        console.log('Adding condition to ConditionsGroup');
        var condition = new Condition_1.ConditionModel();
        condition.priority = 10;
        condition.name = "Condition. " + new Date().toISOString();
        condition.owningGroup = this._group;
        condition.comparison = 'is';
        condition.operator = 'AND';
        condition.setParameter('headerKeyValue', '');
        condition.setParameter('compareTo', '');
        condition.setParameter('isoCode', '');
        this.conditionStub = condition;
        //noinspection TypeScriptUnresolvedVariable
        this.conditionStubWatch = condition.onChange.subscribe(function (self) {
            if (condition.isValid()) {
                _this.conditionService.add(condition);
            }
        });
        this.conditions.push(this.conditionStub);
    };
    ConditionGroupComponent.prototype.toggleGroupOperator = function () {
        this.group.operator = this.group.operator === "AND" ? "OR" : "AND";
    };
    ConditionGroupComponent.prototype.handleRemoveCondition = function (conditionModel) {
        this.conditions = this.conditions.filter(function (aryModel) {
            return aryModel.key != conditionModel.key;
        });
        if (this.conditions.length === 0) {
            this.groupService.remove(this.group);
        }
    };
    ConditionGroupComponent.prototype.handleAddCondition = function (conditionModel) {
        if (this.conditionStub && this.conditionStub.key === conditionModel.key) {
            this.conditionStub = null;
            //noinspection TypeScriptUnresolvedFunction
            this.conditionStubWatch.unsubscribe();
        }
        else {
            this.conditions.push(conditionModel);
        }
    };
    ConditionGroupComponent = __decorate([
        angular2_1.Component({
            selector: 'condition-group',
            properties: [
                "rule",
                "group",
                "groupIndex"
            ]
        }),
        angular2_1.View({
            template: "<div flex=\"grow\" layout=\"column\" layout-align=\"center-start\" class=\"cw-rule-group\">\n  <div flex=\"grow\" layout=\"row\" layout-align=\"center-center\">\n    <div flex layout=\"row\" layout-align=\"start-center\" class=\"cw-header\" *ng-if=\"groupIndex === 0\">\n      This rule fires when the following conditions are met:\n    </div>\n    <div flex layout=\"row\" layout-align=\"center-center\" class=\"cw-header\" *ng-if=\"groupIndex !== 0\">\n      <div class=\"ui basic icon buttons\">\n        <button class=\"ui small button cw-group-operator\" (click)=\"toggleGroupOperator()\">\n          <div (click)=\"toggleGroupOperator()\">{{group.operator}}</div>\n        </button>\n      </div>\n      <span flex class=\"cw-header-text\">when the following condition(s) are met:</span>\n    </div>\n  </div>\n  <div flex layout=\"column\" layout-align=\"center-center\" class=\"cw-conditions\">\n    <div flex layout=\"row\" layout-align=\"center-center\" class=\"cw-conditions\" *ng-for=\"var condition of conditions; var i=index\">\n      <rule-condition flex layout=\"row\" [condition]=\"condition\" [index]=\"i\"></rule-condition>\n      <div class=\"cw-spacer cw-add-condition\" *ng-if=\"i !== (conditions.length - 1)\"></div>\n      <div class=\"cw-btn-group\" *ng-if=\"i === (conditions.length - 1)\">\n        <div class=\"ui basic icon buttons\">\n          <button class=\"cw-button-add-item ui small basic button\" arial-label=\"Add Condition\" (click)=\"addCondition();\" [disabled]=\"!condition.isPersisted()\">\n            <i class=\"plus icon\" aria-hidden=\"true\"></i>\n          </button>\n        </div>\n      </div>\n    </div>\n  </div>\n</div>\n\n",
            directives: [rule_condition_component_1.ConditionComponent, angular2_1.NgIf, angular2_1.NgFor]
        }),
        __param(0, angular2_1.Inject(ApiRoot_1.ApiRoot)),
        __param(1, angular2_1.Inject(ConditionGroup_1.ConditionGroupService)),
        __param(2, angular2_1.Inject(Condition_1.ConditionService)), 
        __metadata('design:paramtypes', [ApiRoot_1.ApiRoot, ConditionGroup_1.ConditionGroupService, Condition_1.ConditionService])
    ], ConditionGroupComponent);
    return ConditionGroupComponent;
})();
exports.ConditionGroupComponent = ConditionGroupComponent;
//# sourceMappingURL=rule-condition-group-component.js.map