var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") return Reflect.decorate(decorators, target, key, desc);
    switch (arguments.length) {
        case 2: return decorators.reduceRight(function(o, d) { return (d && d(o)) || o; }, target);
        case 3: return decorators.reduceRight(function(o, d) { return (d && d(target, key)), void 0; }, void 0);
        case 4: return decorators.reduceRight(function(o, d) { return (d && d(target, key, o)) || o; }, desc);
    }
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
var __param = (this && this.__param) || function (paramIndex, decorator) {
    return function (target, key) { decorator(target, key, paramIndex); }
};
var angular2_1 = require('angular2/angular2');
var dropdown_1 = require("../../../semantic/modules/dropdown/dropdown");
var dropdown_2 = require("../../../semantic/modules/dropdown/dropdown");
var I18NCountryProvider_1 = require("../../../../../api/system/locale/I18NCountryProvider");
var dropdown_3 = require("../../../semantic/modules/dropdown/dropdown");
var CountryConditionModel = (function () {
    function CountryConditionModel(comparatorValue, isoCode) {
        if (comparatorValue === void 0) { comparatorValue = null; }
        if (isoCode === void 0) { isoCode = null; }
        this.parameterKeys = ['isoCode'];
        this.comparatorValue = comparatorValue;
        this.isoCode = isoCode;
    }
    CountryConditionModel.prototype.clone = function () {
        return new CountryConditionModel(this.comparatorValue, this.isoCode);
    };
    return CountryConditionModel;
})();
exports.CountryConditionModel = CountryConditionModel;
var CountryCondition = (function () {
    function CountryCondition(countryProvider) {
        var _this = this;
        this.comparisonOptions = [
            new dropdown_2.DropdownOption("is", "is", "Is"),
            new dropdown_2.DropdownOption("isNot", "isNot", "Is Not")];
        this.countries = [];
        this.change = new angular2_1.EventEmitter();
        this.value = new CountryConditionModel();
        this.comparatorDropdown = new dropdown_3.DropdownModel("comparator", "Comparison", ["is"], this.comparisonOptions);
        this.countryDropdown = new dropdown_3.DropdownModel("country", "Country");
        countryProvider.promise.then(function () {
            var byNames = countryProvider.byName;
            var names = countryProvider.names;
            var tempCountries = [];
            var opts = [];
            names.forEach(function (name) {
                tempCountries.push({ id: byNames[name], label: name });
                var id = byNames[name];
                opts.push(new dropdown_2.DropdownOption(id, id, name, id.toLowerCase() + " flag"));
            });
            _this.countries = tempCountries;
            _this.countryDropdown.addOptions(opts);
            if (_this.value.isoCode === 'NoSelection') {
                _this.value.isoCode = _this.countries[0].id;
            }
        });
    }
    CountryCondition.prototype._modifyEventForForwarding = function (event, field, oldState) {
        Object.assign(event, { ngTarget: this, was: oldState, value: this.value, valueField: field });
        return event;
    };
    Object.defineProperty(CountryCondition.prototype, "isoCode", {
        set: function (isoCode) {
            var selected = [];
            this.value.isoCode = isoCode;
            if (this.value.isoCode) {
                selected.push(this.value.isoCode);
            }
            this.countryDropdown.selected = selected;
        },
        enumerable: true,
        configurable: true
    });
    Object.defineProperty(CountryCondition.prototype, "comparatorValue", {
        set: function (value) {
            this.value.comparatorValue = value;
            this.comparatorDropdown.selected = [value];
        },
        enumerable: true,
        configurable: true
    });
    Object.defineProperty(CountryCondition.prototype, "parameterValues", {
        set: function (value) {
            var _this = this;
            this.value.parameterKeys.forEach(function (paramKey) {
                var v = value[paramKey];
                v = v ? v.value : '';
                _this[paramKey] = v;
            });
        },
        enumerable: true,
        configurable: true
    });
    CountryCondition.prototype.getEventValue = function () {
        var _this = this;
        var eventValue = [];
        this.value.parameterKeys.forEach(function (key) {
            eventValue.push({ key: key, value: _this.value[key] });
        });
        return eventValue;
    };
    CountryCondition.prototype.handleComparatorChange = function (event) {
        var value = event.value;
        this.value.comparatorValue = value;
        this.change.next({ type: 'comparisonChange', target: this, value: value });
    };
    CountryCondition.prototype.handleCountryChange = function (event) {
        this.value.isoCode = event.value;
        this.change.next({ type: 'parameterValueChange', target: this, value: this.getEventValue() });
    };
    CountryCondition = __decorate([
        angular2_1.Component({
            selector: 'cw-country-condition',
            properties: [
                "comparatorValue", "parameterValues",
            ],
            events: [
                "change"
            ]
        }),
        angular2_1.View({
            directives: [angular2_1.NgFor, dropdown_1.Dropdown],
            template: "<div flex layout=\"row\" layout-align=\"start-center\" class=\"cw-condition-component-body\">\n  <!-- Spacer-->\n  <div flex=\"40\" class=\"cw-input-placeholder\">&nbsp;</div>\n  <cw-input-dropdown flex=\"initial\"\n                     class=\"cw-input cw-comparator-selector\"\n                     [model]=\"comparatorDropdown\"\n                     (change)=\"handleComparatorChange($event)\"></cw-input-dropdown>\n  <cw-input-dropdown flex\n                     layout-fill\n                     class=\"cw-input\"\n                     [model]=\"countryDropdown\"\n                     (change)=\"handleCountryChange($event)\"></cw-input-dropdown>\n\n</div>\n  "
        }),
        __param(0, angular2_1.Inject(I18NCountryProvider_1.I18NCountryProvider)), 
        __metadata('design:paramtypes', [I18NCountryProvider_1.I18NCountryProvider])
    ], CountryCondition);
    return CountryCondition;
})();
exports.CountryCondition = CountryCondition;
//# sourceMappingURL=country-condition.js.map