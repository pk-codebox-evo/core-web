/**
 * Check for the presence and value of a header on the user's request.
 *
 * Express a condition based on two fields: a Header, and a Header Comparison
 * @see https://en.wikipedia.org/wiki/List_of_HTTP_header_fields#Request_fields
 * @see https://tools.ietf.org/html/rfc7231#section-5
 * @see http://www.iana.org/assignments/message-headers/message-headers.xml#perm-headers
 *
 *
 * ## POSIX Utility Argument Syntax (http://pubs.opengroup.org/onlinepubs/9699919799/basedefs/V1_chap12.html)
 * ```
 * cw-request-header [-n][-h header_key] [-c comparator] [comparison_values...]
 *   -n                      Negate the match.
 *   -h                      The exact key to search for. Case sensitive.
 *   -e                      Exists. Only verify that the header exists on the Request. The value may be empty or nonsensical.
 *   -c                      The comparator id. One of [ exists, is, startsWith, endsWith, contains, regex]
 *   comparison_values       One or more values compare against the header value.
 * ```
 *
 * ## UI Layout
 *
 * Conceptually the conditionlet is made up of three fields:
 * ```
 * <div>
 *   <input-select-one name="header_key" required="true"/>
 *   <select-one name="comparator" />
 *   <input-select-many name="comparison_values" required="true" />
 * </div>
 * ```
 * ### Fields
 *
 * #### `header_key`
 * The `header_key` is a `select`, pre-populated with common Request header keys. See the Wikipedia.org or iana.org
 * links for more details. There is also an associated text input box that allows custom header keys to be specified.
 *
 * #### `comparator`
 * A standard `select` element containing the allowed comparator ids. One of [ exists, is, startsWith, endsWith, contains, regex].
 * When the selected value is 'exists' the `comparison_values` UI field will be hidden and its model value cleared.
 *
 * #### `comparison_values`
 * Multiple comparison values may be set. Each value shall be specified as per rfc7231#section-5. The UI will
 * **temporarily** add manually keyed inputs into the list of `select` options, negating the need to concern the
 * end user with character escape syntax etc.
 *
 *
 * ------------------------ Discussion ------------------------
 *
 * --------------------------
 */
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") return Reflect.decorate(decorators, target, key, desc);
    switch (arguments.length) {
        case 2: return decorators.reduceRight(function(o, d) { return (d && d(o)) || o; }, target);
        case 3: return decorators.reduceRight(function(o, d) { return (d && d(target, key)), void 0; }, void 0);
        case 4: return decorators.reduceRight(function(o, d) { return (d && d(target, key, o)) || o; }, desc);
    }
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
var __param = (this && this.__param) || function (paramIndex, decorator) {
    return function (target, key) { decorator(target, key, paramIndex); }
};
var angular2_1 = require('angular2/angular2');
var dropdown_1 = require('../../../../../view/components/semantic/modules/dropdown/dropdown');
var input_text_1 = require("../../../semantic/elements/input-text/input-text");
/**
 * @todo: Consider populating these from the server
 * @type {string[]}
 */
var commonRequestHeaders = [
    "Accept",
    "Accept-Charset",
    "Accept-Datetime",
    "Accept-Encoding",
    "Accept-Language",
    "Authorization",
    "Cache-Control",
    "Connection",
    "Content-Length",
    "Content-MD5",
    "Content-Type",
    "Cookie",
    "Date",
    "Expect",
    "From",
    "Host",
    "If-Match",
    "If-Modified-Since",
    "If-None-Match",
    "If-Range",
    "If-Unmodified-Since",
    "Max-Forwards",
    "Origin",
    "Pragma",
    "Proxy-Authorization",
    "Range",
    "Referer",
    "TE",
    "Upgrade",
    "User-Agent",
    "Via",
    "Warning"
];
var RequestHeaderConditionModel = (function () {
    function RequestHeaderConditionModel(headerKeyValue, comparatorValue, compareTo) {
        if (headerKeyValue === void 0) { headerKeyValue = null; }
        if (comparatorValue === void 0) { comparatorValue = null; }
        if (compareTo === void 0) { compareTo = ''; }
        this.parameterKeys = ['headerKeyValue', 'compareTo'];
        this.headerKeyValue = headerKeyValue || commonRequestHeaders[0];
        this.comparatorValue = comparatorValue;
        this.compareTo = compareTo;
    }
    RequestHeaderConditionModel.prototype.clone = function () {
        return new RequestHeaderConditionModel(this.headerKeyValue, this.comparatorValue, this.compareTo);
    };
    return RequestHeaderConditionModel;
})();
exports.RequestHeaderConditionModel = RequestHeaderConditionModel;
var RequestHeaderCondition = (function () {
    function RequestHeaderCondition(headerKeyValue, comparatorValue, parameterValues) {
        // @todo populate the comparisons options from the server.
        this.comparisonOptions = [
            new dropdown_1.DropdownOption("exists", "exists", "Exists"),
            new dropdown_1.DropdownOption("is", "is", "Is"),
            new dropdown_1.DropdownOption("is not", "is not", "Is Not"),
            new dropdown_1.DropdownOption("startsWith", "startsWith", "Starts With"),
            new dropdown_1.DropdownOption("endsWith", "endsWith", "Ends With"),
            new dropdown_1.DropdownOption("contains", "contains", "Contains"),
            new dropdown_1.DropdownOption("regex", "regex", "Regex")];
        this.value = new RequestHeaderConditionModel(headerKeyValue, comparatorValue);
        this.change = new angular2_1.EventEmitter();
        this.comparatorDropdown = new dropdown_1.DropdownModel("comparator", "Comparison", ["is"], this.comparisonOptions);
        var headerKeyOptions = [];
        commonRequestHeaders.forEach(function (name) {
            headerKeyOptions.push(new dropdown_1.DropdownOption(name, name, name));
        });
        this.headerKeyDropdown = new dropdown_1.DropdownModel("headerKey", "Header Key", [], headerKeyOptions);
        this.requestHeaderInputTextModel = new input_text_1.InputTextModel();
        this.requestHeaderInputTextModel.placeholder = "Enter a value";
    }
    Object.defineProperty(RequestHeaderCondition.prototype, "headerKeyValue", {
        set: function (value) {
            this.value.headerKeyValue = value;
            this.headerKeyDropdown.selected = [value];
        },
        enumerable: true,
        configurable: true
    });
    Object.defineProperty(RequestHeaderCondition.prototype, "compareTo", {
        set: function (value) {
            this.value.compareTo = value;
            this.requestHeaderInputTextModel.value = value;
        },
        enumerable: true,
        configurable: true
    });
    Object.defineProperty(RequestHeaderCondition.prototype, "comparatorValue", {
        set: function (value) {
            this.value.comparatorValue = value;
            this.comparatorDropdown.selected = [value];
        },
        enumerable: true,
        configurable: true
    });
    Object.defineProperty(RequestHeaderCondition.prototype, "parameterValues", {
        set: function (value) {
            var _this = this;
            this.value.parameterKeys.forEach(function (paramKey) {
                var v = value[paramKey];
                v = v ? v.value : '';
                _this[paramKey] = v;
            });
        },
        enumerable: true,
        configurable: true
    });
    RequestHeaderCondition.prototype.getEventValue = function () {
        var _this = this;
        var eventValue = [];
        this.value.parameterKeys.forEach(function (key) {
            eventValue.push({ key: key, value: _this.value[key] });
        });
        return eventValue;
    };
    RequestHeaderCondition.prototype.handleComparatorChange = function (event) {
        var value = event.value;
        this.value.comparatorValue = value;
        this.change.next({ type: 'comparisonChange', target: this, value: value });
    };
    RequestHeaderCondition.prototype.handleHeaderKeyChange = function (event) {
        this.value.headerKeyValue = event.value;
        this.change.next({ type: 'parameterValueChange', target: this, value: this.getEventValue() });
    };
    RequestHeaderCondition.prototype.handleCompareToChange = function (event) {
        this.value.compareTo = event.target.value;
        this.requestHeaderInputTextModel.value = event.target.value;
        this.change.next({ type: 'parameterValueChange', target: this, value: this.getEventValue() });
    };
    RequestHeaderCondition = __decorate([
        angular2_1.Component({
            selector: 'cw-request-header-condition',
            properties: [
                "headerKeyValue", "comparatorValue", "parameterValues"
            ],
            events: [
                "change"
            ]
        }),
        angular2_1.View({
            directives: [angular2_1.NgFor, dropdown_1.Dropdown, input_text_1.InputText],
            template: "<div flex layout=\"row\" layout-align=\"start-center\" class=\"cw-condition-component-body\">\n  <cw-input-dropdown flex=\"40\"\n                     class=\"cw-input\"\n                     [model]=\"headerKeyDropdown\"\n                     (change)=\"handleHeaderKeyChange($event)\"></cw-input-dropdown>\n  <cw-input-dropdown flex=\"initial\"\n                     class=\"cw-input cw-comparator-selector\"\n                     [model]=\"comparatorDropdown\"\n                     (change)=\"handleComparatorChange($event)\"></cw-input-dropdown>\n  <cw-input-text flex=\"grow\"\n                 layout-fill\n                 class=\"cw-input\"\n                 (change)=\"handleCompareToChange($event)\"\n                 [model]=\"requestHeaderInputTextModel\">\n  </cw-input-text>\n</div>"
        }),
        __param(0, angular2_1.Attribute('header-key-value')),
        __param(1, angular2_1.Attribute('comparatorValue')),
        __param(2, angular2_1.Attribute('parameterValues')), 
        __metadata('design:paramtypes', [String, String, Array])
    ], RequestHeaderCondition);
    return RequestHeaderCondition;
})();
exports.RequestHeaderCondition = RequestHeaderCondition;
//# sourceMappingURL=request-header-condition.js.map