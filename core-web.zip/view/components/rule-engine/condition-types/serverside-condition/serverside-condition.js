var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") return Reflect.decorate(decorators, target, key, desc);
    switch (arguments.length) {
        case 2: return decorators.reduceRight(function(o, d) { return (d && d(o)) || o; }, target);
        case 3: return decorators.reduceRight(function(o, d) { return (d && d(target, key)), void 0; }, void 0);
        case 4: return decorators.reduceRight(function(o, d) { return (d && d(target, key, o)) || o; }, desc);
    }
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
var angular2_1 = require('angular2/angular2');
var dropdown_1 = require('../../../../../view/components/semantic/modules/dropdown/dropdown');
var input_text_1 = require("../../../semantic/elements/input-text/input-text");
var ServersideCondition = (function () {
    function ServersideCondition() {
        this.comparisonOptions = [];
        this.change = new angular2_1.EventEmitter();
        this.comparisonDropdown = new dropdown_1.DropdownModel("comparison", "Comparison", ["is"], this.comparisonOptions);
        this.inputText = new input_text_1.InputTextModel();
        this.inputText.placeholder = "Enter a value";
    }
    Object.defineProperty(ServersideCondition.prototype, "model", {
        get: function () {
            return this._model;
        },
        set: function (model) {
            this._model = model;
            var opts = [];
            model.conditionType.comparisons.forEach(function (comparison) {
                opts.push(new dropdown_1.DropdownOption(comparison.id));
            });
            this.comparisonDropdown.options = opts;
            this.comparisonDropdown.selected = [model.comparison];
            this.inputText.value = this._model.getParameter("isoCode");
        },
        enumerable: true,
        configurable: true
    });
    ServersideCondition.prototype.handleComparisonChange = function (event) {
        this.model.comparison = event.value;
    };
    ServersideCondition.prototype.handleParamValueChange = function (event) {
        this.model.setParameter("isoCode", event.target.value);
    };
    ServersideCondition = __decorate([
        angular2_1.Component({
            selector: 'cw-serverside-condition',
            properties: [
                "model"
            ],
            events: [
                "change"
            ]
        }),
        angular2_1.View({
            directives: [angular2_1.NgFor, dropdown_1.Dropdown, input_text_1.InputText],
            template: "<div flex layout=\"row\" layout-align=\"start-center\" class=\"cw-condition-component-body\">\n  <!-- Spacer-->\n  <div flex=\"40\" class=\"cw-input\">&nbsp;</div>\n  <cw-input-dropdown flex=\"initial\"\n                     class=\"cw-input cw-comparator-selector\"\n                     [model]=\"comparisonDropdown\"\n                     (change)=\"handleComparisonChange($event)\"></cw-input-dropdown>\n  <cw-input-text flex\n                 layout-fill\n                 class=\"cw-input\"\n                 (change)=\"handleParamValueChange($event)\"\n                 [model]=\"inputText\">\n  </cw-input-text>\n</div>"
        }), 
        __metadata('design:paramtypes', [])
    ], ServersideCondition);
    return ServersideCondition;
})();
exports.ServersideCondition = ServersideCondition;
//# sourceMappingURL=serverside-condition.js.map